#include "qe/yahoo_endpoints.h"
#include <nlohmann/json.hpp>
#include <chrono>
#include <mutex>
#include <cmath>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <algorithm>

using json = nlohmann::json;

namespace qe {

std::vector<double> OhlcvSeries::closes() const {
    std::vector<double> v; v.reserve(bars.size());
    for (auto& b : bars) v.push_back(b.close);
    return v;
}
std::vector<double> OhlcvSeries::highs() const {
    std::vector<double> v; v.reserve(bars.size());
    for (auto& b : bars) v.push_back(b.high);
    return v;
}
std::vector<double> OhlcvSeries::lows() const {
    std::vector<double> v; v.reserve(bars.size());
    for (auto& b : bars) v.push_back(b.low);
    return v;
}
std::vector<double> OhlcvSeries::volumes() const {
    std::vector<double> v; v.reserve(bars.size());
    for (auto& b : bars) v.push_back(b.volume);
    return v;
}

namespace {

std::string urlEncodeSymbol(const std::string& sym) {
    // Yahoo tickers with special chars (^VIX, DX-Y.NYB, EURUSD=X, ZT=F)
    // need '^' and '=' percent-encoded in the path/query; '.' and '-'
    // are fine unescaped.
    std::string out;
    for (char c : sym) {
        if (c == '^') out += "%5E";
        else if (c == '=') out += "%3D";
        else out += c;
    }
    return out;
}

} // namespace

OhlcvSeries fetchChart(HttpClient& http, const std::string& symbol,
                       const std::string& period, const std::string& interval) {
    OhlcvSeries out;
    out.symbol = symbol;

    std::string url = "https://query1.finance.yahoo.com/v8/finance/chart/" +
                       urlEncodeSymbol(symbol) +
                       "?range=" + period + "&interval=" + interval +
                       "&includePrePost=false";

    json j;
    try {
        j = http.getYahooJson(url);
    } catch (const std::exception& e) {
        // Matches the Python version's broad try/except around
        // yf.download() — a failed fetch just means this symbol/engine
        // input is unavailable this cycle, not a crash.
        std::cerr << "[fetchChart] " << symbol << " failed: " << e.what() << "\n";
        return out;
    }

    try {
        auto& result = j.at("chart").at("result");
        if (!result.is_array() || result.empty()) return out;
        auto& r0 = result[0];
        auto& timestamps = r0.at("timestamp");
        auto& indicators = r0.at("indicators");
        auto& quote = indicators.at("quote")[0];

        bool have_adjclose = indicators.contains("adjclose") &&
                              indicators["adjclose"].is_array() &&
                              !indicators["adjclose"].empty();

        const auto& opens  = quote.at("open");
        const auto& highs  = quote.at("high");
        const auto& lows   = quote.at("low");
        const auto& closes = quote.at("close");
        const auto& vols   = quote.at("volume");

        out.bars.reserve(timestamps.size());
        for (size_t i = 0; i < timestamps.size(); ++i) {
            Bar b;
            b.timestamp = timestamps[i].is_null() ? 0 : timestamps[i].get<long long>();
            // Yahoo emits `null` for bars with no trade (common on 1m/5m
            // data around illiquid names/futures rolls) — skip them
            // entirely rather than letting a 0.0 corrupt averages/z-scores
            // downstream, mirroring the Python version's .dropna().
            if (closes[i].is_null() || opens[i].is_null() ||
                highs[i].is_null()  || lows[i].is_null()) {
                continue;
            }
            b.open  = opens[i].get<double>();
            b.high  = highs[i].get<double>();
            b.low   = lows[i].get<double>();
            b.close = closes[i].get<double>();
            b.volume = vols[i].is_null() ? 0.0 : vols[i].get<double>();
            b.adjclose = have_adjclose && !indicators["adjclose"][0]["adjclose"][i].is_null()
                         ? indicators["adjclose"][0]["adjclose"][i].get<double>()
                         : b.close;
            out.bars.push_back(b);
        }
        out.valid = !out.bars.empty();
    } catch (const std::exception& e) {
        std::cerr << "[fetchChart] " << symbol << " parse error: " << e.what() << "\n";
        out.valid = false;
    }
    return out;
}

OptionChain fetchOptionChain(HttpClient& http, const std::string& symbol,
                             int dte_limit, int max_expirations) {
    OptionChain out;
    out.symbol = symbol;

    // Step 1: base call (no date param) returns spot price + the list of
    // available expirationDates (unix epoch seconds, one per Friday/daily
    // expiry Yahoo has listed for this underlying).
    std::string base_url = "https://query1.finance.yahoo.com/v7/finance/options/" +
                            urlEncodeSymbol(symbol);
    json base;
    try {
        base = http.getYahooJson(base_url);
    } catch (const std::exception& e) {
        std::cerr << "[fetchOptionChain] " << symbol << " base call failed: " << e.what() << "\n";
        return out;
    }

    std::vector<long long> expirations;
    double spot = 0.0;
    try {
        auto& result = base.at("optionChain").at("result");
        if (!result.is_array() || result.empty()) return out;
        auto& r0 = result[0];
        spot = r0.at("quote").at("regularMarketPrice").get<double>();
        for (auto& e : r0.at("expirationDates")) expirations.push_back(e.get<long long>());
    } catch (const std::exception& e) {
        std::cerr << "[fetchOptionChain] " << symbol << " base parse error: " << e.what() << "\n";
        return out;
    }
    out.spot = spot;

    std::time_t now = std::time(nullptr);
    int calls_made = 0;
    for (long long exp_epoch : expirations) {
        if (calls_made >= max_expirations) break;
        double dte_days = std::difftime(exp_epoch, now) / 86400.0;
        int dte = (int)std::floor(dte_days);
        if (dte < 0 || dte > dte_limit) continue;

        std::string url = base_url + "?date=" + std::to_string(exp_epoch);
        json chain_j;
        try {
            chain_j = http.getYahooJson(url);
        } catch (const std::exception& e) {
            // One expiration failing (Yahoo occasionally 500s on a
            // specific date param) shouldn't kill the whole chain —
            // matches the Python version's per-expiration try/except.
            std::cerr << "[fetchOptionChain] " << symbol << " exp " << exp_epoch
                      << " failed: " << e.what() << "\n";
            ++calls_made;
            continue;
        }
        ++calls_made;

        try {
            auto& result = chain_j.at("optionChain").at("result");
            if (!result.is_array() || result.empty()) continue;
            auto& opts = result[0].at("options");
            if (!opts.is_array() || opts.empty()) continue;

            std::time_t exp_time = static_cast<std::time_t>(exp_epoch);
            std::tm* tm_exp = std::gmtime(&exp_time);
            std::ostringstream date_str;
            date_str << std::put_time(tm_exp, "%Y-%m-%d");

            auto parseLeg = [&](const json& leg, const char* type_str) {
                OptionRow row;
                row.strike = leg.value("strike", 0.0);
                row.lastPrice = leg.value("lastPrice", 0.0);
                row.impliedVolatility = leg.value("impliedVolatility", 0.2);
                row.openInterest = leg.value("openInterest", 0.0);
                row.volume = leg.value("volume", 0.0);
                row.notional = row.lastPrice * row.volume * 100.0; // 100 = contract multiplier
                row.type = type_str;
                row.expiration = date_str.str();
                row.dte = dte;
                out.rows.push_back(row);
            };

            if (opts[0].contains("calls"))
                for (auto& leg : opts[0]["calls"]) parseLeg(leg, "call");
            if (opts[0].contains("puts"))
                for (auto& leg : opts[0]["puts"]) parseLeg(leg, "put");
        } catch (const std::exception& e) {
            std::cerr << "[fetchOptionChain] " << symbol << " exp " << exp_epoch
                      << " parse error: " << e.what() << "\n";
            continue;
        }
    }

    // valid = "did we successfully reach Yahoo and parse a real options
    // chain for this symbol" — i.e. the base call above (spot + list of
    // expirationDates) succeeded. This is deliberately NOT the same as
    // "out.rows is non-empty": SPY has expirations on effectively every
    // trading day, so a narrow dte_limit (5-7 days) always finds *some*
    // rows for it, but most other optionable stocks only have weekly or
    // monthly expirations — if the nearest one happens to fall outside
    // dte_limit, out.rows legitimately ends up empty even though the
    // fetch worked perfectly. Conflating the two (as an earlier version
    // of this function did via `out.valid = !out.rows.empty()`) made
    // every non-SPY-like ticker with a narrow DTE window look like a
    // network/parse failure instead of "widen the DTE window." Callers
    // that need to distinguish "no options in this window" from "still
    // loading" should check `out.valid && out.rows.empty()` explicitly.
    out.valid = spot > 0.0;
    return out;
}

namespace {
std::mutex g_rfr_mtx;
double g_rfr_cached = -1.0;
std::chrono::steady_clock::time_point g_rfr_ts{};
} // namespace

double fetchRiskFreeRate(HttpClient& http) {
    std::lock_guard<std::mutex> lock(g_rfr_mtx);
    auto now = std::chrono::steady_clock::now();
    if (g_rfr_cached >= 0.0 &&
        (now - g_rfr_ts) < std::chrono::minutes(10)) {
        return g_rfr_cached;
    }
    OhlcvSeries s = fetchChart(http, "^IRX", "5d", "1d");
    double val = s.valid ? s.lastClose() / 100.0 : 0.05;
    if (!(val > 0.0 && val < 1.0)) val = 0.05; // sanity clamp, mirrors Python fallback
    g_rfr_cached = val;
    g_rfr_ts = now;
    return val;
}

} // namespace qe
