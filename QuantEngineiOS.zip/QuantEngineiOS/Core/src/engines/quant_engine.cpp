#include "qe/quant_engine.h"
#include "qe/option_greeks.h"
#include "qe/black_scholes.h"
#include <numeric>
#include <cmath>

namespace qe {

AnchoredVwap computeSessionVwap(const OhlcvSeries& intraday) {
    AnchoredVwap out;
    if (!intraday.valid || intraday.bars.size() < 5) return out;

    double wsum = 0.0, xw_sum = 0.0;
    std::vector<double> typical, weights;
    typical.reserve(intraday.bars.size());
    weights.reserve(intraday.bars.size());
    for (auto& b : intraday.bars) {
        double tp = (b.high + b.low + b.close) / 3.0;
        double w = b.volume;
        if (w <= 0) continue;
        typical.push_back(tp);
        weights.push_back(w);
        xw_sum += tp * w;
        wsum += w;
    }
    if (wsum < 1e-9 || typical.size() < 5) return out;

    double vwap = xw_sum / wsum;
    double var_acc = 0.0;
    for (size_t i = 0; i < typical.size(); ++i)
        var_acc += weights[i] * (typical[i] - vwap) * (typical[i] - vwap);
    double std_ = std::sqrt(var_acc / wsum);

    out.vwap = vwap;
    out.std = std_;
    out.upper_1 = vwap + 1.0 * std_;
    out.lower_1 = vwap - 1.0 * std_;
    out.upper_2 = vwap + 2.0 * std_;
    out.lower_2 = vwap - 2.0 * std_;
    out.valid = true;
    return out;
}

BreakoutProbability computeBreakoutProbability(double spot, const AnchoredVwap& vwap) {
    BreakoutProbability out;
    if (!vwap.valid || spot <= 0) { out.signal = "NO DATA"; return out; }

    double signed_dist = spot - vwap.vwap;
    double prob_up;
    if (vwap.std > 1e-9) {
        prob_up = normCdf(signed_dist / vwap.std);
    } else {
        prob_up = 0.5 + std::max(std::min(signed_dist / std::max(std::fabs(spot), 1.0), 0.25), -0.25);
    }
    prob_up = std::min(std::max(prob_up, 0.05), 0.95);

    out.prob_up = prob_up;
    out.prob_down = 1.0 - prob_up;
    out.signal = prob_up > 0.5 ? "BULLISH BIAS" : (prob_up < 0.5 ? "BEARISH BIAS" : "NEUTRAL");
    return out;
}

QuantEngineSnapshot computeQuantEngineSnapshot(HttpClient& http, const std::string& symbol) {
    QuantEngineSnapshot out;

    // 0DTE-priority chain: dte_limit=1 first (matches Python's fallback
    // pattern of preferring same-day/next-day gamma, since that's what
    // actually drives the 3:30 pin/flip dynamic), falling back to a wider
    // window if nothing is listed that close.
    OptionChain chain = fetchOptionChain(http, symbol, /*dte_limit=*/1, /*max_expirations=*/3);
    if (!chain.valid) chain = fetchOptionChain(http, symbol, /*dte_limit=*/5, /*max_expirations=*/5);
    if (!chain.valid) return out;

    populateOptionGammas(http, chain);
    out.spot = chain.spot;

    GammaWalls walls = computeGammaWalls(chain.rows, chain.spot);
    DealerPositioning dealer = computeDealerPositioning(chain.rows, chain.spot);
    out.dealer_gamma_exposure = dealer.gex;
    out.gamma_flip = walls.gamma_flip;

    // ATM implied vol + nearest DTE, for display context.
    double best_dist = 1e18; double iv_atm = 0.2; int dte_used = 0;
    for (auto& r : chain.rows) {
        double d = std::fabs(r.strike - chain.spot);
        if (d < best_dist) { best_dist = d; iv_atm = r.impliedVolatility; dte_used = r.dte; }
    }
    out.implied_volatility = std::max(iv_atm, 0.01);
    out.days_to_expiration = dte_used;

    // Intraday bars for the real price-based VWAP (see quant_engine.h for
    // why this must be price/volume, not the options chain).
    OhlcvSeries intraday = fetchChart(http, symbol, "5d", "5m");
    out.vwap = computeSessionVwap(intraday);
    out.breakout = computeBreakoutProbability(chain.spot, out.vwap);

    out.valid = true;
    return out;
}

} // namespace qe
