#include "qe/spy_ema_chart_engine.h"
#include "qe/session_clock.h"
#include "qe/stats.h"
#include <cmath>
#include <algorithm>
#include <utility>
#include <cstdio>

namespace qe {

namespace {

// recursiveEma() now lives in stats.h (shared with ma_ladder_engine.cpp)
// — see that header for why this plain/adjust=False form is deliberately
// kept distinct from mtf_engine's ewmMeanLastAdjustTrue.

bool isIntraday(const std::string& interval) {
    return interval == "1m" || interval == "5m" || interval == "15m" || interval == "1h" || interval == "60m";
}

// Mirrors the Python route's `max_bars = {"1m":390,"5m":150,"15m":120,
// "30m":150,"1h":120,"1d":180}` truncation, applied before any indicator
// is computed — this affects session_high/session_low (computed over
// whatever window remains) and gives the same effective lookback as the
// original for each interval.
size_t maxBarsForInterval(const std::string& interval) {
    if (interval == "1m") return 390;
    if (interval == "5m") return 150;
    if (interval == "15m") return 120;
    if (interval == "30m") return 150;
    if (interval == "1h" || interval == "60m") return 120;
    if (interval == "1d") return 180;
    return 150;
}

// ── Timeframe-aware entry-plan parameters ──────────────────────────────
// Drives everything below: how tight/wide the stop is allowed to be (in
// ATR multiples), what R-multiples the fallback targets use when no real
// structure is in range, and how far (in ATR) to search for confluence
// levels for the entry zone vs. for targets. Scalp timeframes need tight
// stops and nearby targets (a 3x-ATR stop on a 5m chart would rarely even
// get hit before the setup's thesis is stale); swing timeframes need the
// opposite, or normal intraday noise stops them out before the move
// they're actually positioned for.
struct TimeframeProfile {
    std::string style;
    double atr_stop_min, atr_stop_max;   // stop distance is clamped to this range
    double target_r1, target_r2;         // fallback R-multiples when no structure found
    double entry_search_atr;             // how far (in ATR) to look for an entry confluence zone
    double target_search_atr;            // how far (in ATR) to look for structural targets
    double cluster_tol_atr;              // levels within this many ATR of each other = one zone
};

TimeframeProfile timeframeProfileFor(const std::string& interval) {
    if (interval == "1m" || interval == "5m")
        return {"SCALP", 0.6, 1.5, 1.0, 2.0, 3.0, 6.0, 0.20};
    if (interval == "15m" || interval == "30m")
        return {"INTRADAY", 0.8, 2.0, 1.5, 2.5, 3.5, 7.0, 0.20};
    // 1h/60m/1d — SWING
    return {"SWING", 1.2, 3.0, 2.0, 3.5, 4.0, 9.0, 0.20};
}

// One candidate price level pulled from an existing indicator/structure
// read, tagged with a confluence weight (how much a confirming touch at
// this level should count for) and a human-readable label for the "why
// here" list shown in the UI.
struct LevelCandidate { double price; double weight; std::string label; };

// A cluster of nearby LevelCandidates treated as a single zone: total
// confluence weight, the touch-weighted price, and which labels went
// into it.
struct LevelCluster { double price; double weight; std::vector<std::string> labels; };

std::vector<LevelCluster> clusterLevels(std::vector<LevelCandidate> levels, double tol) {
    std::sort(levels.begin(), levels.end(),
              [](const LevelCandidate& a, const LevelCandidate& b) { return a.price < b.price; });
    std::vector<LevelCluster> out;
    for (auto& lv : levels) {
        if (!out.empty() && (lv.price - out.back().price) <= tol) {
            auto& c = out.back();
            double total_w = c.weight + lv.weight;
            c.price = (c.price * c.weight + lv.price * lv.weight) / total_w;
            c.weight = total_w;
            c.labels.push_back(lv.label);
        } else {
            out.push_back({lv.price, lv.weight, {lv.label}});
        }
    }
    return out;
}

} // namespace

SpyEmaChart computeSpyEmaChartFromSeries(OhlcvSeries s, const std::string& interval) {
    SpyEmaChart out;
    if (!s.valid || s.bars.empty()) return out;

    size_t max_bars = maxBarsForInterval(interval);
    if (s.bars.size() > max_bars) {
        s.bars.erase(s.bars.begin(), s.bars.end() - max_bars);
    }

    size_t n = s.bars.size();
    out.opens.reserve(n); out.highs.reserve(n); out.lows.reserve(n);
    out.closes.reserve(n); out.volumes.reserve(n); out.timestamps.reserve(n);
    out.interval = interval;
    for (auto& b : s.bars) {
        out.opens.push_back(b.open); out.highs.push_back(b.high);
        out.lows.push_back(b.low); out.closes.push_back(b.close);
        out.volumes.push_back(b.volume); out.timestamps.push_back(b.timestamp);
    }

    // ── VWAP: reset per calendar day for intraday, cumulative for daily ──
    bool intraday = isIntraday(interval);
    out.vwap.resize(n);
    double cum_tp_vol = 0.0, cum_vol = 0.0;
    std::string current_day;
    for (size_t i = 0; i < n; ++i) {
        double typical = (out.highs[i] + out.lows[i] + out.closes[i]) / 3.0;
        if (intraday) {
            std::string day = etDateKeyFromEpoch(s.bars[i].timestamp);
            if (day != current_day) { cum_tp_vol = 0.0; cum_vol = 0.0; current_day = day; }
        }
        cum_tp_vol += typical * out.volumes[i];
        cum_vol += out.volumes[i];
        out.vwap[i] = cum_vol > 0 ? cum_tp_vol / cum_vol : typical;
    }

    // ── EMA9/20/50 (plain recursive form, see header) ──
    out.ema9  = recursiveEma(out.closes, 9);
    out.ema20 = recursiveEma(out.closes, 20);
    out.ema50 = recursiveEma(out.closes, 50);

    // ── Bollinger Bands (20, 2) ──
    const int bb_period = 20;
    out.bb_upper.resize(n); out.bb_mid.resize(n); out.bb_lower.resize(n);
    for (size_t i = 0; i < n; ++i) {
        size_t start = (i + 1 >= (size_t)bb_period) ? i + 1 - bb_period : 0;
        size_t count = i - start + 1;
        double sum = 0.0;
        for (size_t k = start; k <= i; ++k) sum += out.closes[k];
        double m = sum / count;
        double var_acc = 0.0;
        for (size_t k = start; k <= i; ++k) var_acc += (out.closes[k] - m) * (out.closes[k] - m);
        double sd = std::sqrt(var_acc / count);
        out.bb_mid[i] = m;
        out.bb_upper[i] = m + 2.0 * sd;
        out.bb_lower[i] = m - 2.0 * sd;
    }

    // ── RSI(14) ──
    // FIX vs. the Python route's own inline RSI: that implementation
    // seeded avg_gain/avg_loss as the simple mean of the first 14 delta
    // values, then immediately re-applied delta[0] a second time in its
    // first Wilder-smoothing update step — double-counting the first
    // bar's delta and shifting the whole series slightly versus textbook
    // Wilder RSI. Reusing stats.h::wilderRsi() here instead (the same
    // corrected implementation already used for compute_rsi() elsewhere
    // in this port) avoids reproducing that bug a second time under a
    // different name.
    out.rsi = wilderRsi(out.closes, 14);

    // ── Heikin-Ashi OHLC (see header for the formula/rationale) ──
    out.ha_open.resize(n); out.ha_high.resize(n); out.ha_low.resize(n); out.ha_close.resize(n);
    for (size_t i = 0; i < n; ++i) {
        out.ha_close[i] = (out.opens[i] + out.highs[i] + out.lows[i] + out.closes[i]) / 4.0;
        out.ha_open[i] = (i == 0) ? (out.opens[0] + out.closes[0]) / 2.0
                                  : (out.ha_open[i - 1] + out.ha_close[i - 1]) / 2.0;
        out.ha_high[i] = std::max({out.highs[i], out.ha_open[i], out.ha_close[i]});
        out.ha_low[i]  = std::min({out.lows[i], out.ha_open[i], out.ha_close[i]});
    }

    // ── Keltner Channel(20, 2.0): basis = EMA20, bands = basis +/- 2*ATR20 ──
    std::vector<double> atr20 = wilderAtr(out.highs, out.lows, out.closes, 20);
    out.keltner_upper.resize(n); out.keltner_lower.resize(n); out.keltner_width.resize(n);
    for (size_t i = 0; i < n; ++i) {
        out.keltner_upper[i] = out.ema20[i] + 2.0 * atr20[i];
        out.keltner_lower[i] = out.ema20[i] - 2.0 * atr20[i];
        out.keltner_width[i] = out.keltner_upper[i] - out.keltner_lower[i];
    }
    if (n > 10 && out.keltner_width[n - 11] > 1e-9) {
        out.keltner_expanding = (out.keltner_width[n - 1] / out.keltner_width[n - 11]) > 1.10;
    }

    out.session_high = *std::max_element(out.highs.begin(), out.highs.end());
    out.session_low  = *std::min_element(out.lows.begin(), out.lows.end());
    out.last = out.closes.back();

    if (intraday) {
        std::string today = etDateKeyFromEpoch(s.bars.back().timestamp);
        size_t today_idx = 0;
        for (size_t i = 0; i < n; ++i) {
            if (etDateKeyFromEpoch(s.bars[i].timestamp) == today) { today_idx = i; break; }
        }
        out.open = out.opens[today_idx];
    } else {
        out.open = out.opens.front();
    }
    out.change = out.last - out.open;
    out.pct = out.open != 0 ? (out.change / out.open * 100.0) : 0.0;

    // ── MACD(12,26,9) ──
    {
        std::vector<double> ema12 = recursiveEma(out.closes, 12);
        std::vector<double> ema26 = recursiveEma(out.closes, 26);
        out.macd_line.resize(n);
        for (size_t i = 0; i < n; ++i) out.macd_line[i] = ema12[i] - ema26[i];
        out.macd_signal = recursiveEma(out.macd_line, 9);
        out.macd_hist.resize(n);
        for (size_t i = 0; i < n; ++i) out.macd_hist[i] = out.macd_line[i] - out.macd_signal[i];
    }

    // ── ADX(14) + DI+/DI- ──
    {
        AdxResult adx_r = wilderAdx(out.highs, out.lows, out.closes, 14);
        out.adx = std::move(adx_r.adx);
        out.di_plus = std::move(adx_r.di_plus);
        out.di_minus = std::move(adx_r.di_minus);
    }

    // ── OBV + simple divergence (recent price slope vs recent OBV slope) ──
    out.obv = onBalanceVolume(out.closes, out.volumes);
    {
        size_t div_window = std::min((size_t)20, n);
        if (div_window >= 5) {
            std::vector<double> recent_close(out.closes.end() - div_window, out.closes.end());
            std::vector<double> recent_obv(out.obv.end() - div_window, out.obv.end());
            LinRegChannel price_trend = linregChannel(recent_close);
            LinRegChannel obv_trend = linregChannel(recent_obv);
            if (price_trend.valid && obv_trend.valid) {
                // Normalize each slope by its own series' scale so a
                // "meaningfully rising/falling" threshold means the same
                // thing for price (tens/hundreds of dollars) and OBV
                // (raw share counts, orders of magnitude larger).
                double price_scale = std::max(1e-9, stddev(recent_close));
                double obv_scale = std::max(1e-9, stddev(recent_obv));
                double price_slope_n = price_trend.slope / price_scale;
                double obv_slope_n = obv_trend.slope / obv_scale;
                const double kFlat = 0.05; // ignore near-zero slopes on either side
                if (price_slope_n < -kFlat && obv_slope_n > kFlat) out.obv_bullish_divergence = true;
                if (price_slope_n > kFlat && obv_slope_n < -kFlat) out.obv_bearish_divergence = true;
            }
        }
    }

    // ── ATR(14) + volatility-regime percentile ──
    out.atr14 = wilderAtr(out.highs, out.lows, out.closes, 14);
    out.atr_percentile = percentileRankLast(out.atr14, std::min((size_t)100, n));

    // ── Linear regression channel over the trailing window ──
    {
        out.reg_window = (int)std::min((size_t)50, n);
        if (out.reg_window >= 3) {
            std::vector<double> recent(out.closes.end() - out.reg_window, out.closes.end());
            LinRegChannel reg = linregChannel(recent, 2.0);
            if (reg.valid) {
                out.reg_slope = reg.slope;
                out.reg_r2 = reg.r2;
                out.reg_mid = std::move(reg.mid);
                out.reg_upper = std::move(reg.upper);
                out.reg_lower = std::move(reg.lower);
            } else {
                out.reg_window = 0;
            }
        }
    }

    // ── Classic pivot points from the prior completed session ──
    {
        double prior_high = 0, prior_low = 0, prior_close = 0;
        bool found = false;
        if (intraday) {
            // Walk backward collecting distinct day keys until we have
            // the most recent day that's fully *before* the last bar's
            // day (i.e. not today-in-progress).
            std::string last_day = etDateKeyFromEpoch(s.bars.back().timestamp);
            std::string prior_day;
            for (size_t i = n; i-- > 0; ) {
                std::string d = etDateKeyFromEpoch(s.bars[i].timestamp);
                if (d != last_day) { prior_day = d; break; }
            }
            if (!prior_day.empty()) {
                bool first = true;
                for (size_t i = 0; i < n; ++i) {
                    if (etDateKeyFromEpoch(s.bars[i].timestamp) != prior_day) continue;
                    if (first) { prior_high = out.highs[i]; prior_low = out.lows[i]; first = false; }
                    else { prior_high = std::max(prior_high, out.highs[i]); prior_low = std::min(prior_low, out.lows[i]); }
                    prior_close = out.closes[i]; // last bar of that day wins
                }
                found = !first;
            }
        } else if (n >= 2) {
            prior_high = out.highs[n - 2];
            prior_low = out.lows[n - 2];
            prior_close = out.closes[n - 2];
            found = true;
        }
        if (found) {
            out.pivot_valid = true;
            out.pivot_pp = (prior_high + prior_low + prior_close) / 3.0;
            out.pivot_r1 = 2.0 * out.pivot_pp - prior_low;
            out.pivot_s1 = 2.0 * out.pivot_pp - prior_high;
            out.pivot_r2 = out.pivot_pp + (prior_high - prior_low);
            out.pivot_s2 = out.pivot_pp - (prior_high - prior_low);
        }
    }

    // ── Fractal support/resistance levels ──
    {
        struct RawLevel { double price; bool is_resistance; };
        std::vector<RawLevel> raw;
        for (size_t i = 2; i + 2 < n; ++i) {
            bool is_high = out.highs[i] > out.highs[i-1] && out.highs[i] > out.highs[i-2] &&
                           out.highs[i] > out.highs[i+1] && out.highs[i] > out.highs[i+2];
            bool is_low = out.lows[i] < out.lows[i-1] && out.lows[i] < out.lows[i-2] &&
                          out.lows[i] < out.lows[i+1] && out.lows[i] < out.lows[i+2];
            if (is_high) raw.push_back({out.highs[i], true});
            if (is_low) raw.push_back({out.lows[i], false});
        }
        // Cluster by proximity (~0.15% of last price) within each
        // resistance/support group separately, summing touch counts.
        double cluster_tol = std::max(1e-6, out.last * 0.0015);
        auto cluster = [&](bool want_resistance) {
            std::vector<RawLevel> group;
            for (auto& r : raw) if (r.is_resistance == want_resistance) group.push_back(r);
            std::sort(group.begin(), group.end(), [](const RawLevel& a, const RawLevel& b) { return a.price < b.price; });
            std::vector<SpyEmaChart::SrLevel> clustered;
            for (auto& r : group) {
                if (!clustered.empty() && (r.price - clustered.back().price) <= cluster_tol) {
                    // Merge into the existing cluster: touch-weighted average price.
                    auto& last = clustered.back();
                    last.price = (last.price * last.touches + r.price) / (last.touches + 1);
                    last.touches += 1;
                } else {
                    clustered.push_back({r.price, 1, want_resistance});
                }
            }
            return clustered;
        };
        std::vector<SpyEmaChart::SrLevel> res = cluster(true);
        std::vector<SpyEmaChart::SrLevel> sup = cluster(false);
        out.sr_levels.insert(out.sr_levels.end(), res.begin(), res.end());
        out.sr_levels.insert(out.sr_levels.end(), sup.begin(), sup.end());
        std::sort(out.sr_levels.begin(), out.sr_levels.end(),
                  [](const SpyEmaChart::SrLevel& a, const SpyEmaChart::SrLevel& b) { return a.touches > b.touches; });
        if (out.sr_levels.size() > 6) out.sr_levels.resize(6);
    }

    // ── Auto Fibonacci retracement ──
    // Swing window: same trailing-lookback idea as the regression channel
    // above (recent structure, not the whole possibly-180-bar series),
    // capped at 80 bars so a 1h chart's swing doesn't stretch back
    // several trading days.
    {
        size_t fib_window = std::min((size_t)80, n);
        if (fib_window >= 5) {
            size_t start = n - fib_window;
            size_t hi_idx = start, lo_idx = start;
            for (size_t i = start; i < n; ++i) {
                if (out.highs[i] > out.highs[hi_idx]) hi_idx = i;
                if (out.lows[i] < out.lows[lo_idx]) lo_idx = i;
            }
            double swing_high = out.highs[hi_idx];
            double swing_low = out.lows[lo_idx];
            if (swing_high > swing_low && hi_idx != lo_idx) {
                out.fib_valid = true;
                out.fib_swing_high = swing_high;
                out.fib_swing_low = swing_low;
                out.fib_uptrend = hi_idx > lo_idx; // high printed after low => retrace down from high
                const double range = swing_high - swing_low;
                static const double kRatios[7] = {0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0};
                for (double r : kRatios) {
                    double price = out.fib_uptrend ? (swing_high - r * range)
                                                    : (swing_low + r * range);
                    char label[16];
                    std::snprintf(label, sizeof(label), "%.1f%%", r * 100.0);
                    out.fib_levels.push_back({r, price, std::string(label)});
                }
            }
        }
    }

    // ── Volume profile (POC / Value Area) ──
    {
        double lo = out.session_low, hi = out.session_high;
        if (hi > lo) {
            const int kBins = 24;
            std::vector<double> bin_vol(kBins, 0.0);
            double bin_w = (hi - lo) / kBins;
            double total_vol = 0.0;
            for (size_t i = 0; i < n; ++i) {
                double typical = (out.highs[i] + out.lows[i] + out.closes[i]) / 3.0;
                int b = (int)((typical - lo) / bin_w);
                b = std::clamp(b, 0, kBins - 1);
                bin_vol[b] += out.volumes[i];
                total_vol += out.volumes[i];
            }
            if (total_vol > 0.0) {
                int poc_bin = (int)(std::max_element(bin_vol.begin(), bin_vol.end()) - bin_vol.begin());
                out.vp_poc = lo + (poc_bin + 0.5) * bin_w;

                // Expand outward from the POC bin until >=70% of volume covered.
                int lo_bin = poc_bin, hi_bin = poc_bin;
                double covered = bin_vol[poc_bin];
                while (covered / total_vol < 0.70 && (lo_bin > 0 || hi_bin < kBins - 1)) {
                    double expand_down = (lo_bin > 0) ? bin_vol[lo_bin - 1] : -1.0;
                    double expand_up = (hi_bin < kBins - 1) ? bin_vol[hi_bin + 1] : -1.0;
                    if (expand_up >= expand_down) { ++hi_bin; covered += bin_vol[hi_bin]; }
                    else { --lo_bin; covered += bin_vol[lo_bin]; }
                }
                out.vp_val = lo + lo_bin * bin_w;
                out.vp_vah = lo + (hi_bin + 1) * bin_w;

                out.vp_bin_price.resize(kBins);
                out.vp_bin_volume_frac.resize(kBins);
                for (int b = 0; b < kBins; ++b) {
                    out.vp_bin_price[b] = lo + (b + 0.5) * bin_w;
                    out.vp_bin_volume_frac[b] = bin_vol[b] / total_vol;
                }
                out.volume_profile_valid = true;
            }
        }
    }

    // ── Candlestick pattern tags (last ~15 bars, real OHLC) ──
    {
        size_t scan_start = n > 15 ? n - 15 : 0;
        for (size_t i = std::max(scan_start, (size_t)1); i < n; ++i) {
            double body = std::fabs(out.closes[i] - out.opens[i]);
            double range = out.highs[i] - out.lows[i];
            if (range < 1e-9) continue;
            double upper_wick = out.highs[i] - std::max(out.opens[i], out.closes[i]);
            double lower_wick = std::min(out.opens[i], out.closes[i]) - out.lows[i];
            bool green = out.closes[i] > out.opens[i];
            bool prior_green = out.closes[i-1] > out.opens[i-1];

            // Engulfing (two-candle)
            if (green && !prior_green && out.closes[i] >= out.opens[i-1] && out.opens[i] <= out.closes[i-1])
                out.patterns.push_back({i, "Bullish Engulfing", true});
            else if (!green && prior_green && out.opens[i] >= out.closes[i-1] && out.closes[i] <= out.opens[i-1])
                out.patterns.push_back({i, "Bearish Engulfing", false});

            // Doji: body is a tiny fraction of the bar's range.
            if (body <= range * 0.10)
                out.patterns.push_back({i, "Doji", green});

            // Hammer / Shooting Star: small body, one wick >= 2x the body,
            // the other wick small — classified by which end the wick is on.
            if (body > 1e-9 && lower_wick >= 2.0 * body && upper_wick <= body * 0.5)
                out.patterns.push_back({i, "Hammer", true});
            if (body > 1e-9 && upper_wick >= 2.0 * body && lower_wick <= body * 0.5)
                out.patterns.push_back({i, "Shooting Star", false});
        }
    }

    // ── Composite setup score + entry/stop/target plan ──
    {
        double score = 0.0;
        std::vector<std::string>& reasons = out.setup_reasons;

        // EMA stack (9 vs 20 vs 50): +/-25
        bool bull_stack = out.ema9.back() > out.ema20.back() && out.ema20.back() > out.ema50.back();
        bool bear_stack = out.ema9.back() < out.ema20.back() && out.ema20.back() < out.ema50.back();
        if (bull_stack) { score += 25.0; reasons.push_back("EMA9 > EMA20 > EMA50 (bullish stack)"); }
        else if (bear_stack) { score -= 25.0; reasons.push_back("EMA9 < EMA20 < EMA50 (bearish stack)"); }
        else reasons.push_back("EMAs not cleanly stacked (mixed trend)");

        // ADX/DI: direction from DI+/DI-, weight from ADX strength (0-30 pts).
        double adx_last = out.adx.back(), dip = out.di_plus.back(), dim = out.di_minus.back();
        double adx_weight = std::clamp(adx_last / 40.0, 0.0, 1.0) * 30.0;
        if (dip > dim) { score += adx_weight; reasons.push_back("DI+ > DI-, ADX " + std::to_string((int)adx_last) + " (trend strength)"); }
        else { score -= adx_weight; reasons.push_back("DI- > DI+, ADX " + std::to_string((int)adx_last) + " (trend strength)"); }

        // RSI positioning: +/-15
        double rsi_last = out.rsi.back();
        if (rsi_last > 55) { double w = std::clamp((rsi_last - 55) / 25.0, 0.0, 1.0) * 15.0; score += w; reasons.push_back("RSI " + std::to_string((int)rsi_last) + " (bullish momentum)"); }
        else if (rsi_last < 45) { double w = std::clamp((45 - rsi_last) / 25.0, 0.0, 1.0) * 15.0; score -= w; reasons.push_back("RSI " + std::to_string((int)rsi_last) + " (bearish momentum)"); }
        else reasons.push_back("RSI " + std::to_string((int)rsi_last) + " (neutral zone)");

        // MACD histogram: +/-15, scaled by recent histogram range so it's unit-free.
        double hist_last = out.macd_hist.back();
        double hist_scale = std::max(1e-9, stddev(std::vector<double>(out.macd_hist.end() - std::min((size_t)30, n), out.macd_hist.end())));
        double hist_w = std::clamp(std::fabs(hist_last) / (2.0 * hist_scale), 0.0, 1.0) * 15.0;
        if (hist_last > 0) { score += hist_w; reasons.push_back("MACD histogram positive"); }
        else if (hist_last < 0) { score -= hist_w; reasons.push_back("MACD histogram negative"); }

        // Price vs VWAP: +/-15
        double vwap_last = out.vwap.back();
        if (vwap_last > 1e-9) {
            double dist_pct = (out.last - vwap_last) / vwap_last * 100.0;
            double vwap_w = std::clamp(std::fabs(dist_pct) / 0.5, 0.0, 1.0) * 15.0;
            if (dist_pct > 0) { score += vwap_w; reasons.push_back("Price above VWAP"); }
            else if (dist_pct < 0) { score -= vwap_w; reasons.push_back("Price below VWAP"); }
        }

        out.setup_score = std::clamp(score, -100.0, 100.0);
        double mag = std::fabs(out.setup_score);
        std::string strength = mag >= 60 ? "STRONG" : mag >= 30 ? "MODERATE" : "WEAK/CHOPPY";
        std::string dir = out.setup_score > 5 ? "BULLISH" : out.setup_score < -5 ? "BEARISH" : "NEUTRAL";
        out.setup_label = strength + " " + dir + " SETUP";

        // Entry/Stop/Target — confluence-based and timeframe-aware, only
        // produced outside a +/-15 neutral band (direction from the
        // score's sign, same threshold as before).
        double atr_last = out.atr14.back();
        if (std::fabs(out.setup_score) >= 15.0 && atr_last > 1e-9) {
            bool is_long = out.setup_score > 0;
            TimeframeProfile tf = timeframeProfileFor(interval);
            out.trade_plan.style = tf.style;

            // ── Build every candidate level this engine already knows
            // about, weighted by how much a confirming touch there
            // should count for. VWAP and volume POC are the strongest
            // (both are literally "where the volume actually traded",
            // not a derived line); pivots and fractal S/R next; moving
            // averages and bands last, since price crosses those far
            // more casually.
            std::vector<LevelCandidate> levels;
            double vwap_last = out.vwap.back();
            if (vwap_last > 1e-9) levels.push_back({vwap_last, 1.0, "VWAP"});
            levels.push_back({out.ema9.back(),  0.5, "EMA9"});
            levels.push_back({out.ema20.back(), 0.8, "EMA20"});
            levels.push_back({out.ema50.back(), 0.6, "EMA50"});
            levels.push_back({out.keltner_lower.back(), 0.6, "Keltner Lower"});
            levels.push_back({out.keltner_upper.back(), 0.6, "Keltner Upper"});
            levels.push_back({out.bb_lower.back(), 0.5, "BB Lower"});
            levels.push_back({out.bb_upper.back(), 0.5, "BB Upper"});
            if (out.pivot_valid) {
                levels.push_back({out.pivot_pp, 0.9, "Pivot PP"});
                levels.push_back({out.pivot_r1, 0.8, "Pivot R1"});
                levels.push_back({out.pivot_r2, 0.6, "Pivot R2"});
                levels.push_back({out.pivot_s1, 0.8, "Pivot S1"});
                levels.push_back({out.pivot_s2, 0.6, "Pivot S2"});
            }
            for (auto& lvl : out.sr_levels) {
                double w = std::clamp(0.4 + 0.25 * lvl.touches, 0.4, 1.5);
                std::string label = "Fractal " + std::string(lvl.is_resistance ? "resistance" : "support") +
                                     " (" + std::to_string(lvl.touches) + "x touch)";
                levels.push_back({lvl.price, w, label});
            }
            if (out.volume_profile_valid) {
                levels.push_back({out.vp_poc, 1.0, "Volume POC"});
                levels.push_back({out.vp_val, 0.7, "Value Area Low"});
                levels.push_back({out.vp_vah, 0.7, "Value Area High"});
            }
            if (out.fib_valid) {
                // Only the "inner" retracement ratios (23.6/38.2/50/61.8/
                // 78.6) count as confluence candidates — 0%/100% are just
                // the swing high/low themselves, already redundant with
                // fractal S/R above.
                for (auto& fl : out.fib_levels) {
                    if (fl.ratio <= 0.0 || fl.ratio >= 1.0) continue;
                    levels.push_back({fl.price, 0.7, "Fib " + fl.label});
                }
            }

            // ── Entry: cluster whichever of those levels sit on the
            // "pullback side" of price (below for LONG, above for
            // SHORT) within entry_search_atr, then pick the cluster
            // that best balances confluence strength against distance
            // — close-and-strong beats far-and-strong or close-and-weak.
            double entry_range = tf.entry_search_atr * atr_last;
            double cluster_tol = tf.cluster_tol_atr * atr_last;
            std::vector<LevelCandidate> entry_side;
            for (auto& lv : levels) {
                bool on_side = is_long ? (lv.price <= out.last) : (lv.price >= out.last);
                if (on_side && std::fabs(lv.price - out.last) <= entry_range) entry_side.push_back(lv);
            }
            std::vector<LevelCluster> entry_clusters = clusterLevels(entry_side, cluster_tol);

            const LevelCluster* best = nullptr;
            double best_attractiveness = -1.0;
            for (auto& c : entry_clusters) {
                double dist_atr = std::fabs(c.price - out.last) / atr_last;
                double attractiveness = c.weight / (1.0 + dist_atr);
                if (attractiveness > best_attractiveness) { best_attractiveness = attractiveness; best = &c; }
            }

            double entry_price; double entry_zone_weight; std::vector<std::string> entry_labels;
            bool zone_at_market;
            if (best) {
                entry_price = best->price;
                entry_zone_weight = best->weight;
                entry_labels = best->labels;
                zone_at_market = std::fabs(entry_price - out.last) <= 0.15 * atr_last;
            } else {
                // No structure in range at all (thin history, or price
                // sitting well clear of every known level) — fall back
                // to the original "enter at market" behavior rather
                // than producing no plan.
                entry_price = out.last;
                entry_zone_weight = 0.0;
                entry_labels = {"Momentum only — no structure in range"};
                zone_at_market = true;
            }
            if (zone_at_market) entry_price = out.last; // don't quote a limit a few cents from market

            out.trade_plan.valid = true;
            out.trade_plan.direction = is_long ? "LONG" : "SHORT";
            out.trade_plan.entry = entry_price;
            out.trade_plan.entry_type = zone_at_market ? "MARKET" : "LIMIT";
            out.trade_plan.entry_quality = entry_zone_weight >= 2.2 ? "A+ HIGH CONFLUENCE" :
                                            entry_zone_weight >= 1.3 ? "B MODERATE CONFLUENCE" :
                                                                       "C LOW CONFLUENCE / single factor";
            out.trade_plan.confluence_factors = entry_labels;

            // ── Stop: anchored to the entry zone's outer (most
            // conservative) edge when a real cluster was found, then
            // clamped into this timeframe's [atr_stop_min, atr_stop_max]
            // band so a stop is never so tight that ordinary noise
            // takes it out, nor so wide it stops meaning anything for
            // the timeframe being traded.
            double structural_edge = best
                ? (is_long ? std::min(entry_price, out.last) : std::max(entry_price, out.last))
                : entry_price;
            double raw_stop_dist = std::fabs(structural_edge - entry_price) + 0.25 * atr_last;
            double stop_dist = std::clamp(raw_stop_dist, tf.atr_stop_min * atr_last, tf.atr_stop_max * atr_last);
            out.trade_plan.stop = is_long ? entry_price - stop_dist : entry_price + stop_dist;
            out.trade_plan.risk_per_share = stop_dist;

            // ── Targets: prefer the nearest real structure beyond the
            // entry in the trade's direction (next opposing S/R, pivot,
            // or volume-profile level) as long as it clears at least
            // 1R of reward; otherwise fall back to this timeframe's
            // plain R-multiple. Target 2 must be strictly farther than
            // target 1, structural or not.
            double target_range = tf.target_search_atr * atr_last;
            std::vector<LevelCandidate> target_side;
            for (auto& lv : levels) {
                bool beyond = is_long ? (lv.price > entry_price) : (lv.price < entry_price);
                if (beyond && std::fabs(lv.price - entry_price) <= target_range) target_side.push_back(lv);
            }
            std::sort(target_side.begin(), target_side.end(), [&](const LevelCandidate& a, const LevelCandidate& b) {
                return is_long ? (a.price < b.price) : (a.price > b.price);
            });

            double fallback_t1 = is_long ? entry_price + tf.target_r1 * stop_dist : entry_price - tf.target_r1 * stop_dist;
            double fallback_t2 = is_long ? entry_price + tf.target_r2 * stop_dist : entry_price - tf.target_r2 * stop_dist;

            double t1 = fallback_t1; bool t1_struct = false;
            for (auto& lv : target_side) {
                double reward = std::fabs(lv.price - entry_price);
                if (reward >= stop_dist) { t1 = lv.price; t1_struct = true; break; } // first level clearing >=1R
            }
            double t2 = fallback_t2; bool t2_struct = false;
            for (auto& lv : target_side) {
                bool farther_than_t1 = is_long ? (lv.price > t1) : (lv.price < t1);
                if (!farther_than_t1) continue;
                double reward = std::fabs(lv.price - entry_price);
                if (reward >= tf.target_r1 * stop_dist) { t2 = lv.price; t2_struct = true; break; }
            }
            // Guarantee target_2r stays meaningfully beyond target_1r
            // even when t1 was structural but no further structural
            // level qualified for t2 (mechanically already true in the
            // all-fallback case, since target_r2 > target_r1 above).
            if (!t2_struct) {
                double min_gap = 0.5 * stop_dist;
                double min_t2 = is_long ? t1 + min_gap : t1 - min_gap;
                t2 = is_long ? std::max({t2, fallback_t2, min_t2})
                             : std::min({t2, fallback_t2, min_t2});
            }

            out.trade_plan.target_1r = t1;
            out.trade_plan.target_2r = t2;
            out.trade_plan.target_1r_structural = t1_struct;
            out.trade_plan.target_2r_structural = t2_struct;
            out.trade_plan.reward_risk_1r = std::fabs(t1 - entry_price) / stop_dist;
            out.trade_plan.reward_risk_2r = std::fabs(t2 - entry_price) / stop_dist;

            char stop_buf[32];
            std::snprintf(stop_buf, sizeof(stop_buf), "%.2f", out.trade_plan.stop);
            out.trade_plan.invalidation = is_long
                ? "Setup invalidated if price closes back below " + std::string(stop_buf) +
                  ", or if the EMA9/20/50 stack flips bearish before the stop is hit."
                : "Setup invalidated if price closes back above " + std::string(stop_buf) +
                  ", or if the EMA9/20/50 stack flips bullish before the stop is hit.";
        } else {
            out.trade_plan.direction = "NONE";
        }
    }

    out.valid = true;
    return out;
}

SpyEmaChart computeSpyEmaChart(HttpClient& http, const std::string& symbol,
                                const std::string& period, const std::string& interval) {
    OhlcvSeries s = fetchChart(http, symbol, period, interval);
    return computeSpyEmaChartFromSeries(std::move(s), interval);
}

} // namespace qe
