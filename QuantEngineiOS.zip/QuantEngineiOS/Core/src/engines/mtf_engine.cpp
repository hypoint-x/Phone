#include "qe/mtf_engine.h"
#include "qe/stats.h"
#include <algorithm>
#include <cmath>

namespace qe {

std::vector<MtfTimeframeResult> computeMtfBias(HttpClient& http, const std::string& symbol) {
    std::vector<MtfTimeframeResult> results;

    // label -> {yahoo interval, period}. Mirrors the Python version's
    // tfs dict + its period choice per interval (1d gets 3mo of daily
    // bars; everything else gets 5d of intraday bars).
    struct TfSpec { std::string label, interval, period; };
    std::vector<TfSpec> specs = {
        {"1m", "1m", "5d"}, {"5m", "5m", "5d"}, {"15m", "15m", "5d"},
        {"1h", "60m", "5d"}, {"1d", "1d", "3mo"},
    };

    for (auto& spec : specs) {
        OhlcvSeries s = fetchChart(http, symbol, spec.period, spec.interval);
        if (!s.valid || s.bars.size() < 20) continue; // matches Python's `len(df) < 20: continue`

        auto closes = s.closes();
        auto highs  = s.highs();
        auto lows   = s.lows();
        double curr_ema = ewmMeanLastAdjustTrue(closes, 50.0);

        size_t n = s.bars.size();
        double prev_h = highs[n - 2], prev_l = lows[n - 2];
        double curr_h = highs[n - 1], curr_l = lows[n - 1];
        double curr_c = closes[n - 1], curr_o = s.bars[n - 1].open;

        std::string bias = (curr_h > prev_h && curr_l >= prev_l) ? "BULL"
                          : (curr_l < prev_l && curr_h <= prev_h) ? "BEAR"
                          : "NEUTRAL";
        std::string candle = (curr_c >= curr_o) ? "BULL" : "BEAR";
        std::string trend = (curr_c >= curr_ema) ? "ABOVE EMA" : "BELOW EMA";

        int score = 0;
        if (bias != "NEUTRAL") {
            if (candle == bias) score += 1;
            if ((bias == "BULL" && curr_c > curr_ema) || (bias == "BEAR" && curr_c < curr_ema)) score += 1;
        }

        results.push_back({spec.label, bias, candle, trend, score});
    }
    return results;
}

MtfSummary summarizeMtf(const std::vector<MtfTimeframeResult>& mtf) {
    MtfSummary out;
    if (mtf.empty()) { out.signal = "NO DATA"; out.confidence = 0; return out; }

    int bull = 0, bear = 0, total_score = 0;
    for (auto& x : mtf) {
        if (x.bias == "BULL") bull++;
        else if (x.bias == "BEAR") bear++;
        total_score += x.score;
    }
    out.signal = bull > bear ? "BULLISH" : bear > bull ? "BEARISH" : "NEUTRAL";
    out.confidence = std::min(100, (int)((double)total_score / (mtf.size() * 2) * 100));
    return out;
}

std::string computeBuySignal(const std::vector<MtfTimeframeResult>& mtf) {
    if (mtf.empty()) return "WAIT";
    int bull = 0, bear = 0;
    for (auto& x : mtf) {
        if (x.bias == "BULL") bull++;
        else if (x.bias == "BEAR") bear++;
    }
    return bull > bear ? "BUY" : bear > bull ? "SELL" : "WAIT";
}

std::string computeEarlySignal(const std::vector<MtfTimeframeResult>& mtf) {
    if (mtf.empty()) return "NO SIGNAL";
    auto best = std::max_element(mtf.begin(), mtf.end(),
        [](const MtfTimeframeResult& a, const MtfTimeframeResult& b) { return a.score < b.score; });
    return "BEST TF: " + best->tf + " (" + best->bias + ")";
}

int computeConfidence(const std::vector<MtfTimeframeResult>& mtf, double breakout_prob_up) {
    if (mtf.empty()) return 50;
    double mean_score = 0.0;
    for (auto& x : mtf) mean_score += x.score;
    mean_score /= mtf.size();
    double val = 40.0 + mean_score * 12.0 + std::fabs(breakout_prob_up - 0.5) * 100.0;
    return (int)std::round(std::max(1.0, std::min(99.0, val)));
}

} // namespace qe
