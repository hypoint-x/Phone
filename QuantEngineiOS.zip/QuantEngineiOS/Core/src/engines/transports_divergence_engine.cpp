#include "qe/transports_divergence_engine.h"
#include <algorithm>

namespace qe {

TransportsDivergenceResult computeTransportsDivergence(HttpClient& http, int anchor_tf_idx) {
    TransportsDivergenceResult out;
    out.djt = computeMaLadderConfluence(http, "^DJT", anchor_tf_idx);
    out.oil = computeMaLadderConfluence(http, "CL=F", anchor_tf_idx);
    out.valid = out.djt.valid && out.oil.valid; // a divergence read is meaningless with only one side

    if (!out.djt.valid || !out.oil.valid) {
        out.relationship = "NEUTRAL";
        out.trade_direction = "FLAT";
        out.confidence = 0;
        out.reasoning = "Missing data for ^DJT and/or CL=F (Yahoo rate-limit or endpoint change) — nothing to compare yet.";
        return out;
    }

    const bool djt_bull = out.djt.macro_bias == "BULL", djt_bear = out.djt.macro_bias == "BEAR";
    const bool oil_bull = out.oil.macro_bias == "BULL", oil_bear = out.oil.macro_bias == "BEAR";

    char buf[512];

    if (oil_bull && djt_bull) {
        out.relationship = "ANOMALOUS (same-direction)";
        out.trade_direction = "SHORT DJT";
        std::snprintf(buf, sizeof(buf),
            "Both Crude Oil and Dow Jones Transports are showing a BULL macro bias at the same time. "
            "Rising oil should be pressuring Transports' fuel costs, not lifting the sector — Transports "
            "hasn't corrected down to reflect that yet. Betting the market is wrong here means Transports "
            "corrects lower as the cost pressure catches up: SHORT ^DJT.");
        out.reasoning = buf;
    } else if (oil_bear && djt_bear) {
        out.relationship = "ANOMALOUS (same-direction)";
        out.trade_direction = "LONG DJT";
        std::snprintf(buf, sizeof(buf),
            "Both Crude Oil and Dow Jones Transports are showing a BEAR macro bias at the same time. "
            "Falling oil should be relieving Transports' fuel costs, not dragging the sector down with it — "
            "Transports hasn't corrected up to reflect that yet. Betting the market is wrong here means "
            "Transports corrects higher as the margin relief catches up: LONG ^DJT.");
        out.reasoning = buf;
    } else if ((oil_bull && djt_bear) || (oil_bear && djt_bull)) {
        out.relationship = "NORMAL (inverse)";
        out.trade_direction = "FLAT";
        std::snprintf(buf, sizeof(buf),
            "Oil (%s) and Transports (%s) are moving opposite each other, exactly as the fuel-cost "
            "relationship would predict. No mispricing to bet against right now.",
            out.oil.macro_bias.c_str(), out.djt.macro_bias.c_str());
        out.reasoning = buf;
    } else {
        out.relationship = "NEUTRAL";
        out.trade_direction = "FLAT";
        std::snprintf(buf, sizeof(buf),
            "Oil is %s and Transports is %s — at least one lacks a clear directional Macro Bias, so there's "
            "no clean divergence signal to read right now.",
            out.oil.macro_bias.c_str(), out.djt.macro_bias.c_str());
        out.reasoning = buf;
    }

    if (out.trade_direction != "FLAT") {
        // Confidence: average of each side's own ladder confidence (already
        // 0-100, already folding in Hard/Soft Alignment, Pullback Zone,
        // Structural Support, VWAP Floor, OBV Confirm, StochRSI Confirm,
        // and Keltner Expansion — see ma_ladder_engine.h), plus a bonus
        // when BOTH sides independently show a fully-stacked Hard
        // Alignment, since that's the case where each instrument's own
        // trend read is least ambiguous on its own terms.
        int base = (out.djt.confidence + out.oil.confidence) / 2;
        int align_bonus = 0;
        if (out.djt.hard_alignment == "FULL") align_bonus += 10;
        if (out.oil.hard_alignment == "FULL") align_bonus += 10;
        out.confidence = std::min(100, base + align_bonus);
    } else {
        out.confidence = 0;
    }

    return out;
}

} // namespace qe
