#include "qe/sp500_liquidity_engine.h"

namespace qe {

Sp500LiquidityResult computeSp500LiquidityEngine(HttpClient& http,
                                                  const std::string& period,
                                                  const std::string& interval) {
    Sp500LiquidityResult out;

    std::vector<TickerCandidates> wanted = {
        {"DXY",     {"DX-Y.NYB"}},
        {"USDJPY",  {"JPY=X"}},
        {"EURUSD",  {"EURUSD=X"}},
        {"GBPUSD",  {"GBPUSD=X"}},
        {"AUDUSD",  {"AUDUSD=X"}},
        {"NZDUSD",  {"NZDUSD=X"}},
        {"USDCNH",  {"CNH=X"}},
        {"USDCHF",  {"CHF=X"}},
        {"US10Y",   {"^TNX"}},
        {"BRENT",   {"BZ=F"}},
        {"COPPER",  {"HG=F"}},
        {"GOLD",    {"GC=F"}},
        {"VIX",     {"^VIX"}},
        {"SHY",     {"SHY"}},
        {"HYG",     {"HYG"}},
        // MOVE has no free Yahoo source — intentionally omitted, same
        // disclosed-exclusion policy as the Python version, rather than
        // silently retrying forever or faking a value.
    };
    auto data = fetchLabeledSeries(http, wanted, period, interval);
    if (data.count("US10Y"))
        for (auto& b : data.at("US10Y").bars) b.close /= 10.0; // ^TNX is yield*10

    out.usd_funding = computeSubindex(data, {
        {"SHY", 0.4, false}, {"HYG", 0.3, true}, {"US10Y", 0.3, false},
    });
    out.commodity_liquidity = computeSubindex(data, {
        {"COPPER", 0.4, false}, {"BRENT", 0.3, false}, {"GOLD", 0.3, true},
    });
    out.risk_appetite = computeSubindex(data, {
        {"VIX", 0.5, true}, {"HYG", 0.3, false}, {"SHY", 0.2, true},
    });
    out.dollar_engine = computeSubindex(data, {
        {"DXY", 0.35, false}, {"USDJPY", 0.15, false}, {"EURUSD", 0.15, true},
        {"GBPUSD", 0.1, true}, {"AUDUSD", 0.1, true}, {"NZDUSD", 0.05, true},
        {"USDCNH", 0.05, false}, {"USDCHF", 0.05, false},
    });

    struct { SubindexResult* r; double w; } parts[] = {
        {&out.usd_funding, 0.3}, {&out.commodity_liquidity, 0.2},
        {&out.risk_appetite, 0.25}, {&out.dollar_engine, 0.25},
    };
    double sum = 0, wsum = 0;
    for (auto& p : parts) if (p.r->valid) { sum += p.r->value * p.w; wsum += p.w; }
    if (wsum > 1e-9) { out.composite = sum / wsum; out.valid = true; }
    return out;
}

} // namespace qe
