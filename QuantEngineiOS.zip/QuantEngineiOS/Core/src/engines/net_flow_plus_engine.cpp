#include "qe/net_flow_plus_engine.h"
#include "qe/black_scholes.h"
#include <algorithm>
#include <cmath>
#include <sstream>

namespace qe {

namespace {
std::string rowKey(const OptionRow& r) {
    std::ostringstream oss;
    oss << r.strike << '|' << r.type << '|' << r.expiration;
    return oss.str();
}

// Fixed risk-free-rate approximation for the vega estimate shown on Net
// Flow+ particles. The rest of the app fetches a real ^IRX-derived rate
// (fetchRiskFreeRate) for gamma-wall math where basis points matter; here
// vega only drives a secondary visual (particle glow trim), so a fixed
// ~4.5% avoids an extra network round-trip per synthesized event.
constexpr double kApproxRiskFreeRate = 0.045;

double timeToExpiryYears(int dte) {
    return std::max(dte, 0) / 365.0 + (dte == 0 ? (1.0 / (365.0 * 24.0)) : 0.0);
}
} // namespace

void NetFlowPlusTracker::reset() {
    last_seen_.clear();
    history_.clear();
    last_new_.clear();
    premium_samples_.clear();
    premium_p99_ = 0;
    next_id_ = 1;
    have_baseline_ = false;
}

const std::vector<FlowEvent>& NetFlowPlusTracker::update(const OptionChain& chain, double now_seconds) {
    last_new_.clear();
    if (!chain.valid || chain.rows.empty()) return last_new_;

    // First snapshot ever seen for this chain just establishes baselines —
    // otherwise the very first frame would emit one giant "trade" per
    // contract equal to its entire session volume, which isn't a flow
    // event, it's just "the market opened."
    bool first_pass = !have_baseline_;
    have_baseline_ = true;

    struct Candidate { FlowEvent ev; double score; };
    std::vector<Candidate> batch;
    batch.reserve(32);

    for (const auto& row : chain.rows) {
        const std::string key = rowKey(row);
        auto it = last_seen_.find(key);
        double prev_vol = (it != last_seen_.end()) ? it->second.volume : 0.0;
        double prev_oi  = (it != last_seen_.end()) ? it->second.open_interest : row.openInterest;

        last_seen_[key] = LastSeen{ row.volume, row.openInterest };
        if (first_pass) continue;

        double delta = row.volume - prev_vol;
        if (delta <= 0.0) continue; // no new prints inferred on this contract

        FlowEvent ev;
        ev.id = next_id_++;
        ev.symbol = chain.symbol;
        ev.timestamp = now_seconds;
        ev.strike = row.strike;
        ev.expiration = row.expiration;
        ev.dte = row.dte;
        ev.is_call = (row.type == "call");
        ev.volume_delta = delta;
        ev.open_interest = row.openInterest;
        ev.last_price = row.lastPrice;
        ev.net_premium = delta * row.lastPrice * 100.0;
        ev.gamma = row.gamma;
        ev.iv = row.impliedVolatility;
        double T = timeToExpiryYears(row.dte);
        ev.vega = bsVega(chain.spot, row.strike, T, kApproxRiskFreeRate,
                          row.impliedVolatility > 0 ? row.impliedVolatility : 0.2);

        // "Aggressive" heuristic: volume added relative to the contract's
        // *own* prior open interest — a print that adds a large fraction
        // of existing OI in one snapshot gap reads as aggressive
        // positioning rather than routine two-sided trading noise.
        double oi_ratio = prev_oi > 0 ? (delta / prev_oi) : (delta > 0 ? 1.0 : 0.0);
        bool aggressive = oi_ratio > 0.05 || ev.net_premium > 25000.0;

        // "Block" heuristic: one very large single-contract print (big
        // absolute premium AND a big chunk of OI at once) — the classic
        // single-print block-trade signature vs. many-strikes sweep below.
        bool block_like = ev.net_premium > 150000.0 && oi_ratio > 0.15;

        FlowClass cls = FlowClass::Neutral;
        if (block_like) cls = FlowClass::Block;
        else if (aggressive) cls = ev.is_call ? FlowClass::AggressiveCall : FlowClass::AggressivePut;
        ev.cls = cls;

        batch.push_back({ ev, ev.net_premium });
    }

    if (batch.empty()) return last_new_;

    // "Sweep" heuristic: several distinct strikes/expirations on the same
    // side lighting up within the same snapshot gap reads as a sweep
    // (liquidity taken across multiple contracts near-simultaneously)
    // rather than a single-strike print — reclassify same-side events in
    // an over-threshold batch as sweeps (unless already flagged Block,
    // which is the more specific/rarer read).
    int call_hits = 0, put_hits = 0;
    for (auto& c : batch) (c.ev.is_call ? call_hits : put_hits)++;
    for (auto& c : batch) {
        bool side_swept = (c.ev.is_call ? call_hits : put_hits) >= 3;
        if (side_swept && c.ev.cls != FlowClass::Block) c.ev.cls = FlowClass::Sweep;
    }

    // Extreme (white): premium above the running 99th percentile of this
    // session's samples so far, recomputed from a bounded rolling sample
    // set (kMaxPremiumSamples) rather than the full history, so this
    // threshold adapts as the session's typical print size changes.
    for (auto& c : batch) {
        premium_samples_.push_back(c.ev.net_premium);
        if (premium_samples_.size() > kMaxPremiumSamples)
            premium_samples_.erase(premium_samples_.begin(),
                                    premium_samples_.begin() + (premium_samples_.size() - kMaxPremiumSamples));
    }
    if (premium_samples_.size() >= 20) {
        std::vector<double> sorted_samples(premium_samples_);
        std::sort(sorted_samples.begin(), sorted_samples.end());
        size_t idx = static_cast<size_t>(0.99 * (sorted_samples.size() - 1));
        premium_p99_ = sorted_samples[idx];
    }
    if (premium_p99_ > 0) {
        for (auto& c : batch)
            if (c.ev.net_premium >= premium_p99_) c.ev.cls = FlowClass::Extreme;
    }

    for (auto& c : batch) {
        last_new_.push_back(c.ev);
        history_.push_back(c.ev);
    }
    if (history_.size() > kMaxHistory)
        history_.erase(history_.begin(), history_.begin() + (history_.size() - kMaxHistory));

    return last_new_;
}

} // namespace qe
