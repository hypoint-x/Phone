#include "qe/spy_ema_signal.h"
#include "qe/stats.h"

namespace qe {

SpyEmaSignal computeSpyEmaSignal(const OhlcvSeries& intraday) {
    SpyEmaSignal out;
    if (!intraday.valid || intraday.bars.size() < 3) return out;

    auto closes = intraday.closes();
    // pandas .ewm(span=X).mean() default (adjust=True) — matches the
    // Python route's `close_series.ewm(span=9/21).mean()` exactly.
    auto e9 = ewmMeanAdjustTrue(closes, 9.0);
    auto e21 = ewmMeanAdjustTrue(closes, 21.0);

    size_t n = e9.size();
    out.ema9 = e9[n - 1];
    out.ema21 = e21[n - 1];

    bool now_above = e9[n - 1] > e21[n - 1];
    bool prev_above = e9[n - 2] > e21[n - 2];
    if (now_above && !prev_above) out.state = "BULL CROSS";
    else if (!now_above && prev_above) out.state = "BEAR CROSS";
    else out.state = now_above ? "ABOVE" : "BELOW";

    out.valid = true;
    return out;
}

} // namespace qe
