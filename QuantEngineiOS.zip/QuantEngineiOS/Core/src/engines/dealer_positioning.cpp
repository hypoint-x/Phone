#include "qe/dealer_positioning.h"
#include <map>
#include <set>
#include <algorithm>
#include <cmath>
#include <limits>

namespace qe {

GammaWalls computeGammaWalls(const std::vector<OptionRow>& rows, double spot) {
    GammaWalls out;
    if (rows.empty()) return out;

    // call_wall / put_wall: OI-weighted |gamma| concentration per
    // strike, take the strike with the highest score, separately for
    // calls/puts -- but restricted to the directionally-correct side of
    // spot, same fix already applied to gex_by_strike.cpp's
    // computeGexByStrike: a call wall is real resistance ABOVE current
    // price, a put wall is real support BELOW it. Without this
    // constraint, a single strike with the largest score on both sides
    // globally could be labeled as both walls simultaneously -- not a
    // real "wall" in the sense either label is supposed to mean.
    std::map<double, double> call_score, put_score;
    for (auto& r : rows) {
        double score = std::fabs(r.gamma) * r.openInterest;
        if (r.type == "call") call_score[r.strike] += score;
        else                  put_score[r.strike]  += score;
    }
    double best_call_score = -1.0;
    for (auto& kv : call_score) {
        if (kv.first < spot) continue;
        if (kv.second > best_call_score) { best_call_score = kv.second; out.call_wall = kv.first; }
    }
    double best_put_score = -1.0;
    for (auto& kv : put_score) {
        if (kv.first > spot) continue;
        if (kv.second > best_put_score) { best_put_score = kv.second; out.put_wall = kv.first; }
    }

    // gamma_flip: find where net dealer GEX (call_gamma*call_OI -
    // put_gamma*put_OI, dollar-scaled) actually CROSSES zero between
    // two adjacent strikes, then linearly interpolate the real
    // crossing point -- same proven approach as gex_by_strike.cpp and
    // zero_dte_engine.cpp (hand-verified there against a symmetric test
    // case). Fixed from an earlier "strike minimizing |net|" approach,
    // which had two real problems: it could report a flip even when net
    // GEX never actually changes sign anywhere in the strike range
    // (whichever strike happened to have the smallest positive-or-
    // negative value would "win," a fabricated flip where none exists),
    // and even when a real sign change existed, it only picked the
    // nearest discrete strike rather than the true interpolated
    // crossing point between strikes.
    std::map<double, double> call_gamma_oi, put_gamma_oi;
    for (auto& r : rows) {
        double g_oi = r.gamma * r.openInterest;
        if (r.type == "call") call_gamma_oi[r.strike] += g_oi;
        else                  put_gamma_oi[r.strike]  += g_oi;
    }
    std::set<double> all_strikes_set;
    for (auto& kv : call_gamma_oi) all_strikes_set.insert(kv.first);
    for (auto& kv : put_gamma_oi) all_strikes_set.insert(kv.first);

    double gex_scale = spot * spot * 0.01 * 100.0; // *100 real contract multiplier, see gex_by_strike.h's header note
    std::vector<std::pair<double,double>> net_by_strike; // (strike, net) sorted ascending by strike
    for (double s : all_strikes_set) {
        double cg = call_gamma_oi.count(s) ? call_gamma_oi[s] : 0.0;
        double pg = put_gamma_oi.count(s) ? put_gamma_oi[s] : 0.0;
        net_by_strike.push_back({s, (cg - pg) * gex_scale});
    }
    for (size_t i = 1; i < net_by_strike.size(); ++i) {
        double s0 = net_by_strike[i-1].first, v0 = net_by_strike[i-1].second;
        double s1 = net_by_strike[i].first, v1 = net_by_strike[i].second;
        if ((v0 <= 0 && v1 > 0) || (v0 >= 0 && v1 < 0)) {
            double t = (v1 != v0) ? (0 - v0) / (v1 - v0) : 0.5;
            out.gamma_flip = s0 + t * (s1 - s0);
            break;
        }
    }
    // No sign change found anywhere in the strike range -- gamma_flip
    // stays unset (std::optional with no value), not fabricated.
    return out;
}

DealerPositioning computeDealerPositioning(const std::vector<OptionRow>& rows, double spot) {
    DealerPositioning out;
    if (rows.empty()) return out;

    double gex = 0.0;
    for (auto& r : rows) {
        double sign = (r.type == "call") ? 1.0 : -1.0;
        gex += r.gamma * r.openInterest * sign;
    }
    gex *= spot * spot * 0.01 * 100.0; // *100 real contract multiplier, was missing -- see gex_by_strike.h's header note

    out.gex = gex;
    out.regime = gex > 0 ? "LONG GAMMA" : (gex < 0 ? "SHORT GAMMA" : "NEUTRAL");
    return out;
}

} // namespace qe
