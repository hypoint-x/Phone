#include "qe/option_greeks.h"
#include "qe/black_scholes.h"
#include "qe/session_clock.h"

namespace qe {

void populateOptionGammas(HttpClient& http, OptionChain& chain) {
    double r = fetchRiskFreeRate(http);
    double minutes_to_close = minutesToCloseET();
    for (auto& row : chain.rows) {
        double T = timeToExpiry(row.dte, minutes_to_close);
        row.gamma = bsGamma(chain.spot, row.strike, T, r, row.impliedVolatility);
    }
}

} // namespace qe
