#include "qe/net_flow_engine.h"
#include <cmath>
#include <algorithm>

namespace qe {

namespace {
int bucketIndex(int dte) {
    if (dte == 0) return 0;
    if (dte <= 5) return 1;
    return 2;
}
} // namespace

NetFlowResult computeNetFlow(const std::vector<OptionRow>& rows) {
    NetFlowResult out;
    if (rows.empty()) return out;

    out.buckets = {
        {"0DTE", 0, 0, 0, 0, 0, 0.5},
        {"1-5DTE", 0, 0, 0, 0, 0, 0.5},
        {"6+DTE", 0, 0, 0, 0, 0, 0.5},
    };

    for (auto& r : rows) {
        auto& b = out.buckets[bucketIndex(r.dte)];
        if (r.type == "call") { b.call_notional += r.notional; b.call_volume += r.volume; }
        else                  { b.put_notional  += r.notional; b.put_volume  += r.volume; }
    }

    for (auto& b : out.buckets) {
        b.net_notional = b.call_notional - b.put_notional;
        double total_vol = b.call_volume + b.put_volume;
        b.call_put_ratio = total_vol > 0 ? b.call_volume / total_vol : 0.5;
        out.total_call_notional += b.call_notional;
        out.total_put_notional += b.put_notional;
    }

    out.total_net_notional = out.total_call_notional - out.total_put_notional;
    double total_vol_all = 0;
    for (auto& b : out.buckets) total_vol_all += b.call_volume + b.put_volume;
    double total_call_vol = 0;
    for (auto& b : out.buckets) total_call_vol += b.call_volume;
    out.total_call_put_ratio = total_vol_all > 0 ? total_call_vol / total_vol_all : 0.5;

    // Bias threshold: >55% of dollar flow on one side to call it dominant,
    // otherwise NEUTRAL — an arbitrary but reasonable band (avoids
    // flip-flopping the label on every $1 of notional near 50/50).
    double total_abs = std::fabs(out.total_call_notional) + std::fabs(out.total_put_notional);
    double call_share = total_abs > 0 ? out.total_call_notional / total_abs : 0.5;
    out.bias = call_share > 0.55 ? "CALL-DOMINANT" : call_share < 0.45 ? "PUT-DOMINANT" : "NEUTRAL";

    out.valid = true;
    return out;
}

// ── NetFlowTracker ──────────────────────────────────────────────────────

void NetFlowTracker::reset() {
    last_volume_.clear();
    history_.clear();
    call_cum_ = 0;
    put_cum_ = 0;
    t0_ = -1;
    last_sample_t_ = -1e18;
    have_baseline_ = false;
}

void NetFlowTracker::update(const OptionChain& chain, double now_seconds) {
    if (!chain.valid || chain.rows.empty()) return;

    if (t0_ < 0) t0_ = now_seconds;
    double elapsed = now_seconds - t0_;

    double call_delta_notional = 0, put_delta_notional = 0;
    std::map<ContractKey, double> current_volume;

    for (auto& r : chain.rows) {
        ContractKey key{r.strike, r.type, r.expiration};
        current_volume[key] = r.volume;

        auto it = last_volume_.find(key);
        if (it == last_volume_.end()) {
            // New contract we haven't seen before — no prior baseline to
            // diff against, so it contributes no flow this tick (avoids
            // attributing a strike's *entire* day-session volume to the
            // single moment it first appears in the loaded chain window).
            continue;
        }
        double delta_vol = r.volume - it->second;
        if (delta_vol <= 0) continue; // volume never decreases intra-session;
                                       // <=0 means no new prints (or a session
                                       // rollover, in which case skip rather
                                       // than record a bogus negative flow)

        double delta_notional = delta_vol * r.lastPrice * 100.0; // contract multiplier
        if (r.type == "call") call_delta_notional += delta_notional;
        else                  put_delta_notional  += delta_notional;
    }

    last_volume_.swap(current_volume);

    if (!have_baseline_) {
        // First snapshot only seeds the per-contract volume map; nothing
        // to diff against yet, so record a zero-flow origin sample rather
        // than skipping entirely (gives the chart a t=0 anchor point at
        // the current spot price).
        have_baseline_ = true;
        history_.push_back({elapsed, 0, 0, 0, chain.spot});
        last_sample_t_ = elapsed;
        return;
    }

    call_cum_ += call_delta_notional;
    put_cum_  += put_delta_notional;

    if (elapsed - last_sample_t_ < kMinSampleGapSeconds && !history_.empty()) {
        // Too soon since the last sample (e.g. called again this frame
        // with an unchanged cache snapshot) — update the most recent
        // point in place instead of appending a duplicate.
        auto& last = history_.back();
        last.t_seconds = elapsed;
        last.call_premium = call_cum_;
        last.put_premium = put_cum_;
        last.net_premium = call_cum_ - put_cum_;
        last.spot = chain.spot;
        return;
    }

    history_.push_back({elapsed, call_cum_, put_cum_, call_cum_ - put_cum_, chain.spot});
    last_sample_t_ = elapsed;

    if (history_.size() > kMaxSamples) {
        history_.erase(history_.begin(), history_.begin() + (history_.size() - kMaxSamples));
    }
}

} // namespace qe
