#include "qe/gex_levels_pro.h"
#include "qe/option_greeks.h"
#include <algorithm>
#include <cmath>
#include <sstream>
#include <chrono>
#include <set>

namespace qe {

const char* gexZoneLabel(GexZone z) {
    switch (z) {
        case GexZone::Buy: return "BUY (support)";
        case GexZone::Sell: return "SELL (resistance)";
        case GexZone::AccelerationUp: return "ACCELERATION UP";
        case GexZone::AccelerationDown: return "ACCELERATION DOWN";
        case GexZone::Pivot: return "PIVOT";
        default: return "NEUTRAL";
    }
}

double computeMaxPain(const std::vector<OptionRow>& rows) {
    if (rows.empty()) return 0;
    // Candidate settlement prices: every real strike present, not an
    // arbitrary grid -- max pain is only ever meaningfully defined at
    // an actual strike.
    std::set<double> strikes;
    for (auto& r : rows) strikes.insert(r.strike);
    if (strikes.empty()) return 0;

    double best_strike = *strikes.begin();
    double best_loss = -1;
    for (double candidate : strikes) {
        double total_loss = 0;
        for (auto& r : rows) {
            if (r.type == "call" && r.strike < candidate) {
                total_loss += (candidate - r.strike) * r.openInterest * 100.0;
            } else if (r.type == "put" && r.strike > candidate) {
                total_loss += (r.strike - candidate) * r.openInterest * 100.0;
            }
        }
        if (best_loss < 0 || total_loss < best_loss) {
            best_loss = total_loss;
            best_strike = candidate;
        }
    }
    return best_strike;
}

double computeExpectedMoveOneSigma(const std::vector<OptionRow>& rows, double spot) {
    if (rows.empty() || spot <= 0) return 0;
    // Nearest-to-spot strike, preferring the smallest DTE among ties
    // (a genuinely ATM near-term option is the standard basis for this
    // approximation, not an arbitrary pick).
    const OptionRow* atm = nullptr;
    double best_diff = -1;
    for (auto& r : rows) {
        double diff = std::fabs(r.strike - spot);
        if (best_diff < 0 || diff < best_diff || (diff == best_diff && atm && r.dte < atm->dte)) {
            best_diff = diff;
            atm = &r;
        }
    }
    if (!atm) return 0;
    // A 0DTE option still has real hours of trading left in the session,
    // not literally zero time value -- floored at 1 day for this
    // approximation rather than collapsing the whole expected-move
    // calculation to zero, which is what happened whenever the nearest-
    // to-spot, nearest-dte option was same-day (routine for SPY, which
    // lists daily expirations).
    int effective_dte = std::max(atm->dte, 1);
    double years = effective_dte / 365.0;
    return atm->impliedVolatility * spot * std::sqrt(years);
}

GexLevelsProResult computeGexLevelsPro(const std::string& symbol, const std::vector<OptionRow>& rows, double spot,
                                        double day_high, double day_low) {
    GexLevelsProResult out;
    out.symbol = symbol;
    out.spot = spot;
    out.generated_at = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    if (rows.empty() || spot <= 0) return out;

    // NOTE: an earlier pass here filtered `rows` to the single nearest
    // expiration before this call, reasoning that computeGexByStrike's
    // own header requires pre-DTE-filtered input. That diagnosis was
    // wrong -- the actual bug was that gamma was never being populated
    // at all (see the populateOptionGammas() call added above), making
    // every GEX value zero regardless of how many expirations were
    // mixed together. The expiration filter has been reverted since it
    // wasn't the real fix and needlessly reduced the number of strikes
    // available to the heatmap strip and price ladder.
    out.nearest_expiry_rows = rows;

    GexByStrikeResult gex = computeGexByStrike(rows, spot);
    if (!gex.valid) return out;
    out.dealer_regime = gex.edge;
    out.net_gex_strikes = gex.net_gex_strikes;
    out.net_gex_values = gex.net_gex_values;
    out.call_gex_strikes = gex.calls.strikes;
    out.call_gex_values = gex.calls.gex;
    out.call_gex_oi = gex.calls.oi;
    out.put_gex_strikes = gex.puts.strikes;
    out.put_gex_values = gex.puts.gex;
    out.put_gex_oi = gex.puts.oi;

    // Also computed once here so every GEX-concentration level below
    // can carry a real, un-netted call/put breakdown plus the
    // volume-weighted net figure, not just the single OI-weighted net
    // number gamma_flip/call_wall/put_wall are keyed to.
    GexByStrikeResult vol_gex = computeGexByStrike(rows, spot, GexWeighting::Volume);
    auto findSide = [](const GexByStrikeSide& side, double strike, double& gex_out, double& oi_out) {
        for (size_t i = 0; i < side.strikes.size(); ++i) if (side.strikes[i] == strike) { gex_out = side.gex[i]; oi_out = side.oi[i]; return; }
    };
    auto populateBreakdown = [&](GexLevel& lvl, double strike) {
        findSide(gex.calls, strike, lvl.call_gex, lvl.call_oi);
        findSide(gex.puts, strike, lvl.put_gex, lvl.put_oi);
        for (size_t i = 0; i < vol_gex.net_gex_strikes.size(); ++i)
            if (vol_gex.net_gex_strikes[i] == strike) lvl.net_gex_by_volume = vol_gex.net_gex_values[i];
    };

    // Zone classification -- real, deterministic rule based on
    // established dealer-hedging theory: net long gamma (positive)
    // above spot means dealers sell into rallies there (resistance);
    // below spot means dealers buy dips there (support). Net short
    // gamma (negative) means dealers hedge in the SAME direction price
    // is already moving, amplifying rather than dampening it.
    auto classifyByNetGex = [&](double price, double net_gex) {
        if (price > spot) return net_gex >= 0 ? GexZone::Sell : GexZone::AccelerationUp;
        else return net_gex >= 0 ? GexZone::Buy : GexZone::AccelerationDown;
    };

    std::set<double> used_strikes; // avoid double-labeling a strike as both a wall and a ranked GEX level

    if (gex.call_wall) {
        GexLevel lvl; lvl.label = "Call Wall"; lvl.price = *gex.call_wall; lvl.zone = GexZone::Sell;
        for (size_t i = 0; i < gex.net_gex_strikes.size(); ++i) if (gex.net_gex_strikes[i] == *gex.call_wall) lvl.net_gex = gex.net_gex_values[i];
        populateBreakdown(lvl, *gex.call_wall);
        out.levels.push_back(lvl);
        used_strikes.insert(*gex.call_wall);
    }
    if (gex.put_wall) {
        GexLevel lvl; lvl.label = "Put Wall"; lvl.price = *gex.put_wall; lvl.zone = GexZone::Buy;
        for (size_t i = 0; i < gex.net_gex_strikes.size(); ++i) if (gex.net_gex_strikes[i] == *gex.put_wall) lvl.net_gex = gex.net_gex_values[i];
        populateBreakdown(lvl, *gex.put_wall);
        out.levels.push_back(lvl);
        used_strikes.insert(*gex.put_wall);
    }
    if (gex.gamma_flip) {
        GexLevel lvl; lvl.label = "Gamma Flip (Zero Gamma)"; lvl.price = *gex.gamma_flip; lvl.zone = GexZone::Pivot;
        populateBreakdown(lvl, *gex.gamma_flip);
        out.levels.push_back(lvl);
    }

    // Rank remaining strikes by |net GEX|, top 5, excluding walls
    // already labeled above.
    std::vector<std::pair<double,double>> ranked; // (|net_gex|, strike) via net_gex_strikes/values
    for (size_t i = 0; i < gex.net_gex_strikes.size(); ++i) {
        double strike = gex.net_gex_strikes[i];
        if (used_strikes.count(strike)) continue;
        ranked.push_back({std::fabs(gex.net_gex_values[i]), strike});
    }
    std::sort(ranked.begin(), ranked.end(), [](auto& a, auto& b) { return a.first > b.first; });
    int gex_n = 1;
    for (size_t i = 0; i < ranked.size() && gex_n <= 5; ++i, ++gex_n) {
        double strike = ranked[i].second;
        double net_gex = 0;
        for (size_t j = 0; j < gex.net_gex_strikes.size(); ++j) if (gex.net_gex_strikes[j] == strike) net_gex = gex.net_gex_values[j];
        GexLevel lvl;
        lvl.label = "GEX " + std::to_string(gex_n);
        lvl.price = strike;
        lvl.net_gex = net_gex;
        lvl.zone = classifyByNetGex(strike, net_gex);
        populateBreakdown(lvl, strike);
        out.levels.push_back(lvl);
    }

    // Normalize call/put intensity across every GEX-concentration level
    // just populated (walls, flip, GEX 1-5) -- each side's own share of
    // the max |gex| among all of them, for bar-width scaling in the UI.
    {
        double max_abs = 1.0;
        for (auto& lvl : out.levels) { max_abs = std::max({max_abs, std::fabs(lvl.call_gex), std::fabs(lvl.put_gex)}); }
        for (auto& lvl : out.levels) {
            if (lvl.call_gex == 0 && lvl.put_gex == 0) continue; // not a GEX-concentration level (Max Pain etc. added below) -- leave at 0
            lvl.call_intensity = std::fabs(lvl.call_gex) / max_abs;
            lvl.put_intensity = std::fabs(lvl.put_gex) / max_abs;
        }
    }

    // Max Pain and Expected Move are both conceptually tied to a SINGLE
    // expiration's settlement date -- unlike Call Wall/Put Wall/the
    // heatmap strip above, which work correctly on the full multi-
    // expiration chain now that gamma is populated and the directional
    // constraint is in place. Summing open interest for Max Pain across
    // several different, incompatible expirations produces a number
    // that isn't the max-pain strike for any real settlement date, and
    // Expected Move's sqrt(years) term can land on a 0DTE ATM row
    // (zero time value) when multiple expirations are mixed, giving an
    // expected move of essentially zero regardless of real volatility.
    // Filtered to the nearest real expiration only, for these two
    // specifically.
    std::vector<OptionRow> nearest_expiry_for_max_pain;
    {
        int min_dte = -1;
        for (auto& r : rows) if (min_dte < 0 || r.dte < min_dte) min_dte = r.dte;
        for (auto& r : rows) if (r.dte == min_dte) nearest_expiry_for_max_pain.push_back(r);
    }
    double max_pain = computeMaxPain(nearest_expiry_for_max_pain);
    if (max_pain > 0) {
        GexLevel lvl; lvl.label = "Max Pain"; lvl.price = max_pain; lvl.zone = GexZone::Neutral;
        out.levels.push_back(lvl);
    }

    double em = computeExpectedMoveOneSigma(nearest_expiry_for_max_pain, spot);
    if (em > 0) {
        GexLevel up; up.label = "Expected Move (Upper)"; up.price = spot + em; up.zone = GexZone::Neutral;
        GexLevel dn; dn.label = "Expected Move (Lower)"; dn.price = spot - em; dn.zone = GexZone::Neutral;
        out.levels.push_back(up);
        out.levels.push_back(dn);
    }

    if (day_high > 0) { GexLevel lvl; lvl.label = "Day High"; lvl.price = day_high; lvl.zone = GexZone::Neutral; out.levels.push_back(lvl); }
    if (day_low > 0) { GexLevel lvl; lvl.label = "Day Low"; lvl.price = day_low; lvl.zone = GexZone::Neutral; out.levels.push_back(lvl); }

    out.valid = true;
    return out;
}

} // namespace qe
