#include "qe/ma_ladder_engine.h"
#include "qe/spy_ema_chart_engine.h"
#include "qe/stats.h"
#include <algorithm>
#include <cmath>

namespace qe {

namespace {

struct TfSpec { std::string label, interval, period; };

// period choices: 5m/15m get 5d of intraday bars (Yahoo's usual intraday
// lookback window, same choice mtf_engine.cpp makes for its own 5m/15m
// reads). 1h gets 3mo instead of 5d specifically so EMA200 has enough
// bars to mean something (3mo of hourly bars is roughly 400+ bars vs.
// ~30-40 in 5d — EMA200 on only 30-40 bars would barely be seeded).
MaLadderTimeframe buildLadderTf(const std::string& label, const OhlcvSeries& s) {
    MaLadderTimeframe out;
    out.tf = label;
    if (!s.valid || s.bars.size() < 20) return out;

    auto closes = s.closes();
    auto e5   = recursiveEma(closes, 5);
    auto e9   = recursiveEma(closes, 9);
    auto e22  = recursiveEma(closes, 22);
    auto e50  = recursiveEma(closes, 50);
    auto e200 = recursiveEma(closes, 200);

    out.price = closes.back();
    out.ema5 = e5.back(); out.ema9 = e9.back(); out.ema22 = e22.back();
    out.ema50 = e50.back(); out.ema200 = e200.back();

    out.full_stack_bull = (out.ema5 > out.ema9 && out.ema9 > out.ema22 &&
                           out.ema22 > out.ema50 && out.ema50 > out.ema200);
    out.full_stack_bear = (out.ema5 < out.ema9 && out.ema9 < out.ema22 &&
                           out.ema22 < out.ema50 && out.ema50 < out.ema200);
    out.valid = true;

    // Retain the full series for charting — everything below was already
    // computed above (closes/EMA vectors) or is a trivial per-bar extract
    // (opens/highs/lows/timestamps), just not thrown away this time.
    out.series.timestamps.reserve(s.bars.size());
    out.series.opens.reserve(s.bars.size());
    for (auto& bar : s.bars) {
        out.series.timestamps.push_back(bar.timestamp);
        out.series.opens.push_back(bar.open);
    }
    out.series.highs = s.highs();
    out.series.lows = s.lows();
    out.series.closes = closes;
    out.series.ema5 = std::move(e5); out.series.ema9 = std::move(e9); out.series.ema22 = std::move(e22);
    out.series.ema50 = std::move(e50); out.series.ema200 = std::move(e200);
    out.series.valid = true;

    return out;
}

// Soft Alignment's per-timeframe check — see ma_ladder_engine.h header
// for the exact definition ("price on the bias side of >=3 of 5 EMAs").
bool softAlignedOneTf(const MaLadderTimeframe& t, const std::string& bias) {
    if (!t.valid || bias == "NEUTRAL") return false;
    int agree = 0;
    double emas[5] = {t.ema5, t.ema9, t.ema22, t.ema50, t.ema200};
    for (double e : emas) {
        if (bias == "BULL" && t.price > e) agree++;
        if (bias == "BEAR" && t.price < e) agree++;
    }
    return agree >= 3;
}

} // namespace

MaLadderConfluence computeMaLadderConfluence(HttpClient& http, const std::string& symbol,
                                              int anchor_tf_idx) {
    MaLadderConfluence out;
    anchor_tf_idx = std::clamp(anchor_tf_idx, 0, 2);

    std::vector<TfSpec> specs = {
        {"5m", "5m", "5d"}, {"15m", "15m", "5d"}, {"1h", "60m", "3mo"},
    };

    std::vector<OhlcvSeries> raw;
    raw.reserve(specs.size());
    for (auto& spec : specs) {
        OhlcvSeries s = fetchChart(http, symbol, spec.period, spec.interval);
        out.timeframes.push_back(buildLadderTf(spec.label, s));
        raw.push_back(std::move(s));
    }

    out.anchor_tf = specs[anchor_tf_idx].label;
    const MaLadderTimeframe& anchor = out.timeframes[anchor_tf_idx];
    const MaLadderTimeframe& other_a = out.timeframes[(anchor_tf_idx + 1) % 3];
    const MaLadderTimeframe& other_b = out.timeframes[(anchor_tf_idx + 2) % 3];
    const OhlcvSeries& anchor_raw = raw[anchor_tf_idx];

    if (!out.timeframes[0].valid && !out.timeframes[1].valid && !out.timeframes[2].valid) {
        out.valid = false;
        return out;
    }

    // ── Macro Bias — read off the anchor timeframe (see header) ──
    if (anchor.valid) {
        if (anchor.price > anchor.ema50 && anchor.ema50 > anchor.ema200) out.macro_bias = "BULL";
        else if (anchor.price < anchor.ema50 && anchor.ema50 < anchor.ema200) out.macro_bias = "BEAR";
        else out.macro_bias = "NEUTRAL";
    }

    // ── Hard Alignment ──
    int agree_count = 0;
    if (out.macro_bias != "NEUTRAL") {
        for (auto& t : out.timeframes) {
            if (!t.valid) continue;
            if (out.macro_bias == "BULL" && t.full_stack_bull) agree_count++;
            if (out.macro_bias == "BEAR" && t.full_stack_bear) agree_count++;
        }
    }
    out.hard_alignment = (out.macro_bias == "NEUTRAL") ? "NONE"
                        : (agree_count >= 3) ? "FULL"
                        : (agree_count >= 1) ? "PARTIAL" : "NONE";

    // ── Soft Alignment — the two NON-anchor timeframes must agree ──
    out.soft_alignment = softAlignedOneTf(other_a, out.macro_bias) &&
                          softAlignedOneTf(other_b, out.macro_bias);

    // ── Pullback Zone — anchor TF price within 0.15% of EMA9 or EMA22 ──
    if (anchor.valid && out.macro_bias != "NEUTRAL" && anchor.price != 0.0) {
        double d9  = std::fabs(anchor.price - anchor.ema9)  / anchor.price;
        double d22 = std::fabs(anchor.price - anchor.ema22) / anchor.price;
        out.pullback_zone = (std::min(d9, d22) <= 0.0015);
    }

    // ── Structural Support — anchor TF swing structure, last 2 bars ──
    if (anchor_raw.valid && anchor_raw.bars.size() >= 2 && out.macro_bias != "NEUTRAL") {
        auto highs = anchor_raw.highs();
        auto lows  = anchor_raw.lows();
        size_t n = anchor_raw.bars.size();
        double prev_l = lows[n - 2], curr_l = lows[n - 1];
        double prev_h = highs[n - 2], curr_h = highs[n - 1];
        out.structural_support = (out.macro_bias == "BULL") ? (curr_l >= prev_l) : (curr_h <= prev_h);
    }

    // ── VWAP Floor + Keltner Expansion — reuse spy_ema_chart_engine's
    // read, on the anchor TF's own period/interval ──
    SpyEmaChart chart_anchor = computeSpyEmaChart(http, symbol, specs[anchor_tf_idx].period,
                                                   specs[anchor_tf_idx].interval);
    if (chart_anchor.valid && !chart_anchor.vwap.empty() && out.macro_bias != "NEUTRAL") {
        double p = chart_anchor.last, v = chart_anchor.vwap.back();
        out.vwap_floor = (out.macro_bias == "BULL") ? (p >= v) : (p <= v);
    }
    out.keltner_expansion = chart_anchor.valid && chart_anchor.keltner_expanding;
    out.anchor_chart = std::move(chart_anchor); // retained for charting — was discarded here before

    // ── OBV Confirm — anchor TF OBV's own 20-EMA slope over last 5 bars ──
    if (anchor_raw.valid && anchor_raw.bars.size() >= 26 && out.macro_bias != "NEUTRAL") {
        auto obv = onBalanceVolume(anchor_raw.closes(), anchor_raw.volumes());
        auto obv_ema = recursiveEma(obv, 20);
        size_t n = obv_ema.size();
        if (n >= 6) {
            double slope = obv_ema[n - 1] - obv_ema[n - 6];
            out.obv_confirm = (out.macro_bias == "BULL") ? (slope > 0) : (slope < 0);
        }
    }

    // ── StochRSI Confirm — anchor TF %K cross through 20/80, last 3 bars ──
    if (anchor_raw.valid && anchor_raw.bars.size() >= 30 && out.macro_bias != "NEUTRAL") {
        StochRsiResult sr = computeStochRsi(anchor_raw.closes());
        size_t n = sr.k.size();
        if (n >= 4) {
            for (size_t i = n - 3; i < n && !out.stochrsi_confirm; ++i) {
                if (out.macro_bias == "BULL" && sr.k[i - 1] < 20.0 && sr.k[i] >= 20.0) out.stochrsi_confirm = true;
                if (out.macro_bias == "BEAR" && sr.k[i - 1] > 80.0 && sr.k[i] <= 80.0) out.stochrsi_confirm = true;
            }
        }
    }

    // ── Long Trigger (see header — long side only, by spec) ──
    out.long_trigger = (out.macro_bias == "BULL") && (out.hard_alignment != "NONE") &&
                        out.soft_alignment && (out.pullback_zone || out.structural_support) &&
                        out.vwap_floor && out.obv_confirm && out.stochrsi_confirm &&
                        out.keltner_expansion;

    // ── Confidence ──
    int score = 30;
    score += (out.hard_alignment == "FULL") ? 25 : (out.hard_alignment == "PARTIAL") ? 12 : 0;
    int confirms = (out.soft_alignment ? 1 : 0) + (out.pullback_zone ? 1 : 0) +
                   (out.structural_support ? 1 : 0) + (out.vwap_floor ? 1 : 0) +
                   (out.obv_confirm ? 1 : 0) + (out.stochrsi_confirm ? 1 : 0) +
                   (out.keltner_expansion ? 1 : 0);
    score += confirms * 6;
    if (out.macro_bias == "NEUTRAL") score /= 2;
    out.confidence = std::max(0, std::min(100, score));

    out.valid = true;
    return out;
}

} // namespace qe
