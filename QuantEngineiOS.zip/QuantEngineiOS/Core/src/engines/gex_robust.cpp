#include "qe/gex_robust.h"
#include "qe/black_scholes.h"
#include <algorithm>
#include <cmath>
#include <map>

namespace qe {
namespace {
struct R { double K, w, sq, sgn; };   // strike, weight, sigma*sqrt(T), +1 call / -1 put

double total(const std::vector<R>& v, double S, double sc) {
    double t = 0;
    for (const R& r : v) {
        double d1 = (std::log(S / r.K) + 0.5 * r.sq * r.sq) / r.sq;           // r folded in as ~0 over days
        double g = 0.3989422804014327 * std::exp(-0.5 * d1 * d1) / (S * r.sq);
        t += r.sgn * g * r.w;
    }
    return t * S * S * sc;
}
std::optional<double> flipNear(const std::vector<R>& v, double spot, int n, double span, double sc, std::vector<double>* xs = nullptr, std::vector<double>* ys = nullptr) {
    std::optional<double> best; double bd = 1e300, px = 0, py = 0; bool have = false;
    for (int i = 0; i <= n; ++i) {
        double S = spot * (1 - span + 2 * span * i / n), y = total(v, S, sc);
        if (xs) { xs->push_back(S); ys->push_back(y); }
        if (have && ((py <= 0 && y > 0) || (py >= 0 && y < 0))) {
            double f = (y != py) ? -py / (y - py) : 0.5, c = px + f * (S - px);
            if (std::fabs(c - spot) < bd) { bd = std::fabs(c - spot); best = c; }
        }
        px = S; py = y; have = true;
    }
    return best;
}
double pct(std::vector<double> v, double p) { std::sort(v.begin(), v.end()); return v[(size_t)std::min<double>(v.size() - 1, std::floor(p * (v.size() - 1) + 0.5))]; }
} // namespace

GexRobustResult computeGexRobust(const std::vector<OptionRow>& rows, double spot, double rf) {
    (void)rf;
    GexRobustResult o; o.spot = spot; o.rows_in = (int)rows.size();
    if (rows.empty() || spot <= 0) return o;
    const double sc = 0.01 * 100.0;
    std::vector<R> v; std::vector<double> ws; double conf_sum = 0;
    struct Keep { const OptionRow* r; double w; double conf; };
    std::vector<Keep> keep;
    for (const OptionRow& r : rows) {
        if (r.strike < spot * 0.88 || r.strike > spot * 1.12) continue;
        if (r.openInterest <= 0) continue;
        if (r.volume <= 0 && r.lastPrice <= 0) { ++o.dropped_stale; continue; }
        if (r.impliedVolatility < 0.02 || r.impliedVolatility > 2.5) { ++o.dropped_iv; continue; }
        double conf = 0.35 + 0.65 * std::min(1.0, r.volume / (0.10 * r.openInterest));
        keep.push_back({&r, r.openInterest * conf, conf});
        ws.push_back(r.openInterest * conf);
    }
    if (keep.empty()) return o;
    double cap = pct(ws, 0.975);
    std::map<double, double> cg, pg;
    for (const Keep& k : keep) {
        double w = k.w; if (w > cap) { w = cap; ++o.clipped; }
        double T = timeToExpiry(k.r->dte, 120.0), sq = k.r->impliedVolatility * std::sqrt(T);
        v.push_back({k.r->strike, w, sq, k.r->type == "call" ? 1.0 : -1.0});
        conf_sum += k.conf;
        double g = bsGamma(spot, k.r->strike, T, 0.0, k.r->impliedVolatility) * w * spot * spot * sc;
        (k.r->type == "call" ? cg : pg)[k.r->strike] += g;
    }
    o.rows_used = (int)v.size(); o.mean_conf = conf_sum / keep.size();
    // per-strike robust arrays
    std::map<double, double> all; for (auto& x : cg) all[x.first]; for (auto& x : pg) all[x.first];
    for (auto& s : all) {
        double c = cg.count(s.first) ? cg[s.first] : 0, p = pg.count(s.first) ? pg[s.first] : 0;
        o.strikes.push_back(s.first); o.call_gex.push_back(c); o.put_gex.push_back(p); o.net.push_back(c - p);
    }
    double bc = -1e300, bp = -1e300;
    for (size_t i = 0; i < o.strikes.size(); ++i) {
        if (o.strikes[i] >= spot && o.call_gex[i] > bc) { bc = o.call_gex[i]; o.call_wall = o.strikes[i]; }
        if (o.strikes[i] <= spot && o.put_gex[i] > bp) { bp = o.put_gex[i]; o.put_wall = o.strikes[i]; }
    }
    // smoothed per-strike crossing nearest spot
    { std::vector<double> sm(o.net.size());
      for (size_t i = 0; i < o.net.size(); ++i) { double a = o.net[i > 0 ? i - 1 : i], b = o.net[i], c = o.net[i + 1 < o.net.size() ? i + 1 : i]; sm[i] = .25 * a + .5 * b + .25 * c; }
      double bd = 1e300;
      for (size_t i = 1; i < sm.size(); ++i) if ((sm[i - 1] <= 0 && sm[i] > 0) || (sm[i - 1] >= 0 && sm[i] < 0)) {
          double f = sm[i] != sm[i - 1] ? -sm[i - 1] / (sm[i] - sm[i - 1]) : .5, c = o.strikes[i - 1] + f * (o.strikes[i] - o.strikes[i - 1]);
          if (std::fabs(c - spot) < bd) { bd = std::fabs(c - spot); o.flip_strike = c; } } }
    // sweep flip + profile
    std::vector<double> xs, ys;
    o.flip = flipNear(v, spot, 120, 0.10, sc, &xs, &ys);
    for (size_t i = 0; i < xs.size(); i += 3) { o.sweep_spot.push_back(xs[i]); o.sweep_total.push_back(ys[i]); }
    // stability under random weight perturbation (deterministic LCG)
    unsigned long long st = 88172645463325252ULL;
    auto rnd = [&]() { st ^= st << 13; st ^= st >> 7; st ^= st << 17; return (st >> 11) * (1.0 / 9007199254740992.0); };
    std::vector<double> fl;
    for (int t = 0; t < 40; ++t) {
        std::vector<R> p = v;
        for (R& r : p) r.w *= std::exp(0.25 * (rnd() + rnd() + rnd() - 1.5) * 2.0);
        auto f = flipNear(p, spot, 60, 0.10, sc);
        if (f) fl.push_back(*f);
    }
    if (fl.size() >= 8) { o.flip_lo = pct(fl, 0.10); o.flip_hi = pct(fl, 0.90);
        o.stability = std::max(0.0, std::min(1.0, 1.0 - (*o.flip_hi - *o.flip_lo) / spot * 100.0 / 2.0)); }
    o.valid = true;
    return o;
}

} // namespace qe
