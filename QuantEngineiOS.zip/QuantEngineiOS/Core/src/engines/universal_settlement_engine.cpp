#include "qe/universal_settlement_engine.h"
#include "qe/yahoo_endpoints.h"
#include "qe/option_greeks.h"
#include "qe/black_scholes.h"
#include "qe/session_clock.h"
#include "qe/stats.h"
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include <limits>
#include <ctime>

namespace qe {

namespace {

struct IntradaySnapshot {
    double p_900 = 0, p_930 = 0, p_1030 = 0, p_current = 0;
    double morning_high = 0, morning_low = 0;
    double minutes_now = 90;
    std::string as_of;
    bool is_live = false;
    bool valid = false;
};

double nearestClose(const std::vector<Bar>& day_bars, int hh, int mm) {
    double last_exact = std::numeric_limits<double>::quiet_NaN();
    for (auto& b : day_bars) {
        std::tm et = toEasternTm(b.timestamp);
        if (et.tm_hour == hh && et.tm_min == mm) last_exact = b.close;
    }
    if (!std::isnan(last_exact)) return last_exact;

    std::tm target = toEasternTm(day_bars.front().timestamp);
    target.tm_hour = hh; target.tm_min = mm; target.tm_sec = 0;
    long long target_epoch = etWallTimeToEpoch(target);

    double best_diff = std::numeric_limits<double>::max();
    double best_close = day_bars.front().close;
    for (auto& b : day_bars) {
        double diff = std::fabs((double)(b.timestamp - target_epoch));
        if (diff < best_diff) { best_diff = diff; best_close = b.close; }
    }
    return best_close;
}

// Same structure as SpySettlementEngine's fetchSpySnapshot(), parameterized by symbol.
IntradaySnapshot fetchIntradaySnapshot(HttpClient& http, const std::string& symbol) {
    IntradaySnapshot out;
    OhlcvSeries hist = fetchChart(http, symbol, "1d", "1m");
    if (!hist.valid || hist.bars.empty()) hist = fetchChart(http, symbol, "5d", "1m");
    if (!hist.valid || hist.bars.empty()) return out;

    std::string last_date = etDateKeyFromEpoch(hist.bars.back().timestamp);
    std::vector<Bar> day_bars;
    for (auto& b : hist.bars) if (etDateKeyFromEpoch(b.timestamp) == last_date) day_bars.push_back(b);
    if (day_bars.empty()) day_bars = hist.bars;

    out.p_900 = nearestClose(day_bars, 9, 0);
    out.p_930 = nearestClose(day_bars, 9, 30);
    out.p_1030 = nearestClose(day_bars, 10, 30);
    out.p_current = day_bars.back().close;

    double hi = -1e18, lo = 1e18;
    bool found_window = false;
    for (auto& b : day_bars) {
        std::tm et = toEasternTm(b.timestamp);
        int mins = et.tm_hour * 60 + et.tm_min;
        if (mins >= 9 * 60 && mins <= 10 * 60 + 30) {
            hi = std::max(hi, b.high); lo = std::min(lo, b.low); found_window = true;
        }
    }
    if (!found_window) {
        for (auto& b : day_bars) { hi = std::max(hi, b.high); lo = std::min(lo, b.low); }
    }
    out.morning_high = hi; out.morning_low = lo;

    std::tm last_et = toEasternTm(day_bars.back().timestamp);
    double minutes = (last_et.tm_hour * 60 + last_et.tm_min) - 9 * 60;
    out.minutes_now = std::min(std::max(minutes, 90.0), 390.0);

    std::time_t now = std::time(nullptr);
    std::tm now_et = toEasternTm((long long)now);
    char now_date[32];
    std::snprintf(now_date, sizeof(now_date), "%04d-%02d-%02d", now_et.tm_year + 1900, now_et.tm_mon + 1, now_et.tm_mday);
    out.is_live = (last_date == std::string(now_date));

    char buf[64];
    std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d ET",
                  last_et.tm_year + 1900, last_et.tm_mon + 1, last_et.tm_mday,
                  last_et.tm_hour, last_et.tm_min, last_et.tm_sec);
    out.as_of = buf;
    out.valid = true;
    return out;
}

struct GammaSnapshot {
    double spot = 0, dealer_gamma_exposure = 0, gamma_flip = 0, implied_volatility = 0.18;
    int days_to_expiration = 0;
    bool valid = false;
};

// Same structure as SpySettlementEngine's qeGammaSnapshot(), parameterized
// by symbol, with the gamma-flip sign-change-interpolation fix applied
// from the start (see dealer_positioning.cpp's own fix for the full
// reasoning -- the old "strike minimizing |net|" approach could
// fabricate a flip even when net GEX never actually changes sign).
GammaSnapshot gammaSnapshot(HttpClient& http, const std::string& symbol) {
    GammaSnapshot out;
    OptionChain chain = fetchOptionChain(http, symbol, 1, 3);
    if (!chain.valid) chain = fetchOptionChain(http, symbol, 5, 6);
    if (!chain.valid) return out;
    populateOptionGammas(http, chain);

    double spot = chain.spot;
    double lo = spot * 0.9, hi = spot * 1.1;
    std::vector<OptionRow> d;
    for (auto& r : chain.rows) if (r.strike >= lo && r.strike <= hi) d.push_back(r);
    if (d.empty()) return out;

    std::map<double, double> call_gamma, call_oi, put_gamma, put_oi;
    for (auto& r : d) {
        if (r.type == "call") { call_gamma[r.strike] += r.gamma; call_oi[r.strike] += r.openInterest; }
        else                  { put_gamma[r.strike]  += r.gamma; put_oi[r.strike]  += r.openInterest; }
    }
    double spot2 = spot * spot * 0.01 * 100.0; // real options contract multiplier, see gex_by_strike.h's header note
    double total_call_gex = 0, total_put_gex = 0;
    std::map<double, double> call_gex, put_gex;
    for (auto& kv : call_gamma) { double g = kv.second * call_oi[kv.first] * spot2; call_gex[kv.first] = g; total_call_gex += g; }
    for (auto& kv : put_gamma)  { double g = kv.second * put_oi[kv.first]  * spot2; put_gex[kv.first]  = g; total_put_gex  += g; }
    out.dealer_gamma_exposure = total_call_gex - total_put_gex;

    std::set<double> strikes;
    for (auto& kv : call_gex) strikes.insert(kv.first);
    for (auto& kv : put_gex) strikes.insert(kv.first);
    std::vector<std::pair<double,double>> net_by_strike;
    for (double s : strikes) {
        double cg = call_gex.count(s) ? call_gex[s] : 0.0;
        double pg = put_gex.count(s) ? put_gex[s] : 0.0;
        net_by_strike.push_back({s, cg - pg});
    }
    std::sort(net_by_strike.begin(), net_by_strike.end());
    double flip = spot;
    for (size_t i = 1; i < net_by_strike.size(); ++i) {
        double s0 = net_by_strike[i-1].first, v0 = net_by_strike[i-1].second;
        double s1 = net_by_strike[i].first, v1 = net_by_strike[i].second;
        if ((v0 <= 0 && v1 > 0) || (v0 >= 0 && v1 < 0)) {
            double t = (v1 != v0) ? (0 - v0) / (v1 - v0) : 0.5;
            flip = s0 + t * (s1 - s0);
            break;
        }
    }
    out.gamma_flip = strikes.empty() ? spot : flip;

    std::vector<OptionRow> sorted_by_dist = d;
    std::sort(sorted_by_dist.begin(), sorted_by_dist.end(),
              [spot](const OptionRow& a, const OptionRow& b) {
                  return std::fabs(a.strike - spot) < std::fabs(b.strike - spot);
              });
    size_t n_atm = std::min<size_t>(6, sorted_by_dist.size());
    double iv_sum = 0;
    for (size_t i = 0; i < n_atm; ++i) iv_sum += sorted_by_dist[i].impliedVolatility;
    double iv_atm = n_atm > 0 ? iv_sum / n_atm : 0.18;

    int dte_min = d.front().dte;
    for (auto& r : d) dte_min = std::min(dte_min, r.dte);

    out.spot = spot;
    out.implied_volatility = std::max(iv_atm, 0.01);
    out.days_to_expiration = dte_min;
    out.valid = true;
    return out;
}

struct LinReg { double slope, intercept, r_squared; };
LinReg linearRegression(const std::vector<double>& xs, const std::vector<double>& ys) {
    size_t n = xs.size();
    double sum_x = 0, sum_y = 0, sum_xy = 0, sum_xx = 0;
    for (size_t i = 0; i < n; ++i) { sum_x += xs[i]; sum_y += ys[i]; sum_xy += xs[i] * ys[i]; sum_xx += xs[i] * xs[i]; }
    double denom = n * sum_xx - sum_x * sum_x;
    double slope = denom != 0 ? (n * sum_xy - sum_x * sum_y) / denom : 0.0;
    double intercept = (sum_y - slope * sum_x) / n;

    double mean_y = sum_y / n;
    double ss_res = 0, ss_tot = 0;
    for (size_t i = 0; i < n; ++i) {
        double y_hat = slope * xs[i] + intercept;
        ss_res += (ys[i] - y_hat) * (ys[i] - y_hat);
        ss_tot += (ys[i] - mean_y) * (ys[i] - mean_y);
    }
    if (ss_tot == 0) ss_tot = 1e-9;
    return {slope, intercept, 1.0 - ss_res / ss_tot};
}

} // namespace

UniversalSettlementEngine::UniversalSettlementEngine() {
    weights_ = {1.0/6, 1.0/6, 1.0/6, 1.0/6, 1.0/6, 1.0/6};
}

SettlementForecast UniversalSettlementEngine::computeForecast(HttpClient& http, const std::string& symbol) {
    SettlementForecast out;
    last_symbol_ = symbol;

    IntradaySnapshot snap = fetchIntradaySnapshot(http, symbol);
    if (!snap.valid || snap.p_900 <= 0 || snap.p_1030 <= 0) {
        out.available = false;
        out.error = "no intraday data available for " + symbol + " (market may be closed, or this symbol may not trade regular US session hours)";
        return out;
    }

    double p_900 = snap.p_900, p_930 = snap.p_930, p_1030 = snap.p_1030, p_current = snap.p_current;
    double morning_high = snap.morning_high, morning_low = snap.morning_low, minutes_now = snap.minutes_now;

    GammaSnapshot gsnap = gammaSnapshot(http, symbol);
    double r = fetchRiskFreeRate(http);
    double iv, dealer_gex, gamma_flip_val;
    int dte;
    if (gsnap.valid) {
        iv = gsnap.implied_volatility; dte = gsnap.days_to_expiration;
        dealer_gex = gsnap.dealer_gamma_exposure; gamma_flip_val = gsnap.gamma_flip;
    } else {
        // Honest fallback -- same as SpySettlementEngine's own behavior
        // when its options fetch fails (e.g. a symbol with no listed
        // options chain): momentum/regression/Fibonacci components
        // still compute from real price data, Black-Scholes/dealer-GEX
        // components fall back to neutral rather than fabricating a
        // number for data that doesn't exist.
        iv = 0.18; dte = 0; dealer_gex = 0.0; gamma_flip_val = p_current;
    }

    const double state_threshold_up = 0.0015, state_threshold_down = -0.0015;
    double morning_change = p_900 != 0 ? (p_1030 - p_900) / p_900 : 0.0;
    MarkovState cur_state = morning_change > state_threshold_up ? MarkovState::Up
                           : morning_change < state_threshold_down ? MarkovState::Down
                           : MarkovState::Neutral;

    MarkovForecast mf = markov_.forecast(cur_state);

    double morning_vol = std::fabs(p_1030 - p_900);
    if (morning_vol == 0.0) morning_vol = 1e-6;
    double reward_up = morning_vol, reward_neutral = 0.0, reward_down = -morning_vol;
    double EV = mf.probability_up * reward_up + mf.probability_neutral * reward_neutral + mf.probability_down * reward_down;

    double T = dte > 0 ? (double)dte / 365.0 : (30.0 / (60.0 * 6.5)) / 252.0;
    double K = gamma_flip_val != 0 ? gamma_flip_val : p_current;
    double bs_delta = bsDelta(p_current, K, T, r, iv, true);
    double bs_gamma_val = bsGamma(p_current, K, T, r, iv);
    double bs_vega = bsVega(p_current, K, T, r, iv);
    double bs_theta = bsTheta(p_current, K, T, r, iv, true);
    bool long_gamma = dealer_gex > 0;
    std::string gamma_bias_label = long_gamma ? "Long Gamma" : "Short Gamma";
    double continuation_sign = p_current >= p_900 ? 1.0 : -1.0;
    double gamma_bias_component = continuation_sign * (long_gamma ? -0.5 : 0.5);

    double rng = morning_high - morning_low;
    if (rng == 0.0) rng = 1e-6;
    std::vector<std::pair<std::string, double>> fib_levels = {
        {"0.236", morning_high - 0.236 * rng}, {"0.382", morning_high - 0.382 * rng},
        {"0.500", morning_high - 0.500 * rng}, {"0.618", morning_high - 0.618 * rng},
        {"0.786", morning_high - 0.786 * rng}, {"1.272", morning_high - 1.272 * rng},
        {"1.618", morning_high - 1.618 * rng}, {"2.618", morning_high - 2.618 * rng},
    };
    std::string nearest_label = fib_levels.front().first;
    double best_dist = std::numeric_limits<double>::max();
    double nearest_level = fib_levels.front().second;
    double fib_500 = 0;
    for (auto& kv : fib_levels) {
        if (kv.first == "0.500") fib_500 = kv.second;
        double d = std::fabs(kv.second - p_current);
        if (d < best_dist) { best_dist = d; nearest_label = kv.first; nearest_level = kv.second; }
    }
    double fib_distance_pct = p_current != 0 ? (p_current - nearest_level) / p_current * 100.0 : 0.0;
    double fib_score = zClip(p_current - fib_500, rng / 2.0);

    std::vector<double> xs = {0.0, 30.0, 90.0, minutes_now};
    std::vector<double> ys = {p_900, p_930, p_1030, p_current};
    LinReg reg = linearRegression(xs, ys);
    double projected_330_price = reg.intercept + reg.slope * 390.0;

    double settlement_score = morning_change;
    std::string settlement_bias_label = settlement_score > 0 ? "Long Settlement Bias"
                                       : settlement_score < 0 ? "Short Settlement Bias" : "Neutral";

    int trend_adjustment_pct = reg.slope > 0 ? 10 : -10;
    std::string dealer_adjustment = dealer_gex > 0 ? "reduce projected volatility" : "increase projected volatility";
    std::string ev_adjustment = EV > 0 ? "increase bullish probability" : "increase bearish probability";

    double settlement_component = zClip(settlement_score, state_threshold_up);
    double markov_component = mf.probability_up - mf.probability_down;
    double ev_component = zClip(EV, morning_vol);
    double slope_component = zClip(reg.slope * 390.0, rng);
    std::array<double, 6> components = {
        settlement_component, markov_component, ev_component,
        slope_component, gamma_bias_component, fib_score,
    };
    double final_score = 0;
    for (int i = 0; i < 6; ++i) final_score += weights_[i] * components[i];
    final_score = std::max(-1.0, std::min(1.0, final_score));
    std::string direction = final_score > 0.08 ? "BULLISH" : final_score < -0.08 ? "BEARISH" : "NEUTRAL";
    double max_prob = std::max({mf.probability_up, mf.probability_neutral, mf.probability_down});
    double confidence_score = max_prob * std::fabs(reg.r_squared) * std::min(std::fabs(EV) / morning_vol, 1.0);

    history_.push_back({cur_state, mf.predicted_state, p_current, components});
    if (history_.size() > 30) history_.erase(history_.begin());

    out.available = true;
    out.as_of = snap.as_of; out.is_live = snap.is_live;
    out.spy_900 = p_900; out.spy_930 = p_930; out.spy_1030 = p_1030; out.spy_current = p_current;
    out.morning_high = morning_high; out.morning_low = morning_low;
    out.implied_volatility = iv; out.risk_free_rate = r; out.dealer_gamma_exposure = dealer_gex;
    out.days_to_expiration = dte;
    out.gamma_flip = gamma_flip_val;
    out.current_state = cur_state; out.predicted_state = mf.predicted_state;
    out.morning_change_pct = morning_change * 100.0;
    out.probability_up = mf.probability_up; out.probability_neutral = mf.probability_neutral;
    out.probability_down = mf.probability_down; out.transition_row = mf.transition_row;
    out.ev_value = EV; out.reward_up = reward_up; out.reward_neutral = reward_neutral; out.reward_down = reward_down;
    out.ev_interpretation = EV > 0 ? "Bullish expectation" : EV < 0 ? "Bearish expectation" : "Neutral";
    out.bs_delta = bs_delta; out.bs_gamma = bs_gamma_val; out.bs_vega = bs_vega; out.bs_theta = bs_theta;
    out.gamma_bias_label = gamma_bias_label;
    out.bs_interpretation = long_gamma ? "Dealers dampen volatility" : "Dealers amplify movement";
    out.fib_levels = fib_levels; out.fib_nearest_label = nearest_label;
    out.fib_nearest_level = nearest_level; out.fib_distance_pct = fib_distance_pct;
    out.slope = reg.slope; out.intercept = reg.intercept; out.r_squared = reg.r_squared;
    out.projected_330_price = projected_330_price;
    out.settlement_score = settlement_score; out.settlement_bias_label = settlement_bias_label;
    out.trend_adjustment_pct = trend_adjustment_pct;
    out.dealer_adjustment = dealer_adjustment; out.ev_adjustment = ev_adjustment;
    out.final_score = final_score; out.direction = direction; out.confidence_score = confidence_score;
    out.weights = weights_;
    out.chart_times = {"09:00", "09:30", "10:30", "now", "15:30 (proj.)"};
    out.chart_values = {p_900, p_930, p_1030, p_current, projected_330_price};
    return out;
}

AdaptiveLearningResult UniversalSettlementEngine::recordActual(double actual_price) {
    AdaptiveLearningResult out;
    if (history_.empty()) {
        out.ok = false;
        out.error = "no prior forecast to score yet -- run computeForecast() first";
        return out;
    }
    HistoryEntry& last = history_.back();
    double actual_change = last.price_current != 0 ? (actual_price - last.price_current) / last.price_current : 0.0;
    MarkovState actual_state = actual_change > 0.0015 ? MarkovState::Up
                              : actual_change < -0.0015 ? MarkovState::Down : MarkovState::Neutral;
    bool correct = actual_state == last.predicted_state;

    markov_.nudge(last.current_state, actual_state, 0.08);

    int direction_actual = actual_state == MarkovState::Up ? 1 : actual_state == MarkovState::Down ? -1 : 0;
    if (direction_actual != 0) {
        for (int i = 0; i < 6; ++i) {
            double v = last.components[i];
            bool agree = (v > 0 && direction_actual > 0) || (v < 0 && direction_actual < 0);
            weights_[i] = std::max(0.02, weights_[i] + (agree ? 0.01 : -0.01));
        }
        double wsum = 0; for (double w : weights_) wsum += w;
        if (wsum <= 0.0) wsum = 1.0;
        for (auto& w : weights_) w /= wsum;
    }

    out.ok = true;
    out.correct = correct;
    out.predicted_state = markovStateToString(last.predicted_state);
    out.actual_state = markovStateToString(actual_state);
    out.updated_weights = weights_;
    out.updated_transition_row = markov_.forecast(last.current_state).transition_row;
    return out;
}

void UniversalSettlementEngine::setWeights(std::array<double, 6> w) {
    for (auto& v : w) v = std::max(0.0, v);
    double sum = 0; for (double v : w) sum += v;
    if (sum <= 0.0) { weights_ = {1.0/6, 1.0/6, 1.0/6, 1.0/6, 1.0/6, 1.0/6}; return; }
    for (auto& v : w) v /= sum;
    weights_ = w;
}

} // namespace qe
