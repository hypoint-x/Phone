#include "qe/strike_heatmap.h"
#include <map>
#include <cmath>
#include <algorithm>
#include <limits>

namespace qe {

StrikeHeatmap computeStrikeHeatmap(const std::vector<OptionRow>& rows, IntensityMetric metric, double spot) {
    StrikeHeatmap out;
    if (rows.empty()) return out;

    // groupby(["strike","type"])[metric].sum(), then pivot to call/put
    // columns per strike (fillna 0) — mirrors the Python version, now
    // generalized from always-notional to whichever metric is selected.
    std::map<double, double> call_value, put_value;
    for (auto& r : rows) {
        double v = optionMetricValue(r, metric, spot);
        if (r.type == "call") call_value[r.strike] += v;
        else                  put_value[r.strike]  += v;
    }

    std::vector<double> strikes;
    for (auto& kv : call_value) strikes.push_back(kv.first);
    for (auto& kv : put_value)
        if (call_value.find(kv.first) == call_value.end()) strikes.push_back(kv.first);
    if (strikes.empty()) return out;

    std::vector<StrikeHeatmapRow> built;
    built.reserve(strikes.size());
    double max_abs_net = 1.0; // "or 1" in the Python version, guards div-by-zero
    double best_total = 0.0;
    size_t peak_idx = std::numeric_limits<size_t>::max();

    for (double s : strikes) {
        StrikeHeatmapRow row;
        row.strike = s;
        row.call_notional = call_value.count(s) ? call_value[s] : 0.0;
        row.put_notional  = put_value.count(s)  ? put_value[s]  : 0.0;
        row.net   = row.call_notional - row.put_notional;
        row.total = row.call_notional + row.put_notional;
        row.call_dominant = row.call_notional > row.put_notional;
        built.push_back(row);
        max_abs_net = std::max(max_abs_net, std::fabs(row.net));
    }

    // peak_strike = pivot["total"].idxmax() if pivot["total"].max() > 0 else None
    double runner_up_total = 0.0;
    size_t runner_up_idx = std::numeric_limits<size_t>::max();
    for (size_t i = 0; i < built.size(); ++i) {
        if (built[i].total > best_total) {
            runner_up_total = best_total;
            runner_up_idx = peak_idx;
            best_total = built[i].total;
            peak_idx = i;
        } else if (built[i].total > runner_up_total) {
            runner_up_total = built[i].total;
            runner_up_idx = i;
        }
    }
    bool has_peak = best_total > 0.0 && peak_idx != std::numeric_limits<size_t>::max();
    bool has_runner_up = has_peak && runner_up_total > 0.0 && runner_up_idx != std::numeric_limits<size_t>::max();

    for (size_t i = 0; i < built.size(); ++i) {
        built[i].intensity = (float)std::min(std::fabs(built[i].net) / max_abs_net, 1.0);
        built[i].is_peak = has_peak && i == peak_idx;
        built[i].is_runner_up = has_runner_up && i == runner_up_idx;
    }

    // ENHANCEMENT — peak_dominance (see header): how far ahead the peak
    // strike is of the next-busiest one, as a fraction of the peak's own
    // total. Guards div-by-zero via has_peak (best_total > 0 already).
    out.peak_dominance = has_peak
        ? (float)std::clamp((best_total - runner_up_total) / best_total, 0.0, 1.0)
        : 0.0f;
    out.runner_up_strike = has_runner_up ? built[runner_up_idx].strike
                                          : std::numeric_limits<double>::quiet_NaN();

    // sort_index(ascending=False) — highest strike first, matches the
    // ladder convention (top of the visual list = highest strike).
    std::sort(built.begin(), built.end(),
              [](const StrikeHeatmapRow& a, const StrikeHeatmapRow& b) { return a.strike > b.strike; });

    out.rows = std::move(built);
    out.valid = true;
    return out;
}

} // namespace qe
