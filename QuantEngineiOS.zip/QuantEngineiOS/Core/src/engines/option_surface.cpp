#include "qe/option_surface.h"
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include <limits>

namespace qe {

namespace {

double metricValue(const OptionRow& r, SurfaceMetric m, double spot) {
    switch (m) {
        case SurfaceMetric::Volume: return r.volume;
        case SurfaceMetric::OpenInterest: return r.openInterest;
        case SurfaceMetric::Notional: return r.notional;
        case SurfaceMetric::Gamma: return r.gamma;
        case SurfaceMetric::Gex: return r.gamma * r.openInterest * 100.0 * (spot != 0 ? spot * spot * 0.01 : 1.0); // unified to the same gamma*OI*100*spot^2*0.01 formula as every other GEX calculation in this codebase -- see gex_by_strike.h's header note
    }
    return r.volume;
}

// Groups `rows` by (dte, strike), summing `metric` — mirrors the Python
// version's `df.groupby([dte_col, "strike"])[metric].sum()`.
std::map<std::pair<int, double>, double> groupByDteStrike(
    const std::vector<OptionRow>& rows, SurfaceMetric metric, double spot) {
    std::map<std::pair<int, double>, double> grouped;
    for (auto& r : rows) grouped[{r.dte, r.strike}] += metricValue(r, metric, spot);
    return grouped;
}

} // namespace

SurfaceGrid buildOptionSurface(const std::vector<OptionRow>& rows, double spot,
                                SurfaceMetric metric, int res) {
    SurfaceGrid out;
    if (rows.empty() || spot <= 0) return out;

    std::vector<OptionRow> filtered;
    filtered.reserve(rows.size());
    double window = surfaceStrikeWindow(spot);
    for (auto& r : rows)
        if (r.strike >= spot - window && r.strike <= spot + window) filtered.push_back(r);
    if (filtered.empty()) return out;

    auto grouped = groupByDteStrike(filtered, metric, spot);

    std::set<int> dte_set;
    std::set<double> strike_set;
    for (auto& kv : grouped) { dte_set.insert(kv.first.first); strike_set.insert(kv.first.second); }
    if (dte_set.empty() || strike_set.empty()) return out;

    std::vector<int> y_raw(dte_set.begin(), dte_set.end());       // sorted DTEs
    std::vector<double> x_raw(strike_set.begin(), strike_set.end()); // sorted strikes

    // Dense z_raw grid, zero-filled for (dte,strike) combos with no rows —
    // mirrors pandas pivot(...).fillna(0).
    std::vector<std::vector<double>> z_raw(y_raw.size(), std::vector<double>(x_raw.size(), 0.0));
    for (size_t iy = 0; iy < y_raw.size(); ++iy)
        for (size_t ix = 0; ix < x_raw.size(); ++ix) {
            auto it = grouped.find({y_raw[iy], x_raw[ix]});
            if (it != grouped.end()) z_raw[iy][ix] = it->second;
        }

    // Resample onto a regular res x res grid via nearest-neighbor lookup
    // (not interpolation) — matches the Python version exactly, including
    // the resulting "stepped" look before smoothing.
    std::vector<double> xi(res), yi(res);
    double x_min = x_raw.front(), x_max = x_raw.back();
    double y_min = (double)y_raw.front(), y_max = (double)y_raw.back();
    for (int i = 0; i < res; ++i) {
        xi[i] = (res == 1) ? x_min : x_min + (x_max - x_min) * i / (res - 1);
        yi[i] = (res == 1) ? y_min : y_min + (y_max - y_min) * i / (res - 1);
    }

    std::vector<double> zi(res * res, 0.0);
    for (int iy = 0; iy < res; ++iy) {
        // nearest DTE row
        size_t ny = 0; double best_dy = std::numeric_limits<double>::max();
        for (size_t k = 0; k < y_raw.size(); ++k) {
            double d = std::fabs((double)y_raw[k] - yi[iy]);
            if (d < best_dy) { best_dy = d; ny = k; }
        }
        for (int ix = 0; ix < res; ++ix) {
            size_t nx = 0; double best_dx = std::numeric_limits<double>::max();
            for (size_t k = 0; k < x_raw.size(); ++k) {
                double d = std::fabs(x_raw[k] - xi[ix]);
                if (d < best_dx) { best_dx = d; nx = k; }
            }
            zi[iy * res + ix] = z_raw[ny][nx];
        }
    }

    // 3-pass 5-point box blur WITH wraparound (np.roll semantics) at the
    // grid edges -- see option_surface.h header comment for why the
    // wraparound itself is kept faithful to the Python original. The
    // PASS COUNT was originally 15, also to match that original, but
    // real options activity data is typically sparse (volume/OI
    // concentrated at a handful of strikes/expiries, near-zero
    // elsewhere) -- 15 passes of this diffusion-style blur significantly
    // dilutes real peaks into their zero surroundings, which is what
    // made the surface look flat in practice rather than showing real
    // structure. Reduced based on that direct feedback; still enough
    // passes to soften the nearest-neighbor "steps" from the resampling
    // above without washing out genuine peaks.
    auto idxWrap = [res](int i) { return ((i % res) + res) % res; };
    for (int pass = 0; pass < 3; ++pass) {
        std::vector<double> next(res * res, 0.0);
        for (int iy = 0; iy < res; ++iy) {
            for (int ix = 0; ix < res; ++ix) {
                double center = zi[iy * res + ix];
                double up     = zi[idxWrap(iy - 1) * res + ix];
                double down   = zi[idxWrap(iy + 1) * res + ix];
                double left   = zi[iy * res + idxWrap(ix - 1)];
                double right  = zi[iy * res + idxWrap(ix + 1)];
                next[iy * res + ix] = (center + up + down + left + right) / 5.0;
            }
        }
        zi.swap(next);
    }

    out.x_strikes = xi;
    out.y_dte.resize(res);
    for (int i = 0; i < res; ++i) out.y_dte[i] = yi[i];
    out.z = zi;
    out.res = res;
    out.valid = true;
    return out;
}

double exactMetricAt(const std::vector<OptionRow>& rows, double strike, int dte,
                      SurfaceMetric metric, double spot) {
    auto grouped = groupByDteStrike(rows, metric, spot);
    auto it = grouped.find({dte, strike});
    if (it != grouped.end()) return it->second;
    if (grouped.empty()) return 0.0;

    // Closest available (dte,strike) if exact key not found — mirrors the
    // Python version's KeyError fallback using |Δdte| + |Δstrike|.
    double best_dist = std::numeric_limits<double>::max();
    double best_val = 0.0;
    for (auto& kv : grouped) {
        double d = std::fabs((double)kv.first.first - dte) + std::fabs(kv.first.second - strike);
        if (d < best_dist) { best_dist = d; best_val = kv.second; }
    }
    return best_val;
}

SurfaceMarkers findSurfaceMarkers(const std::vector<OptionRow>& rows, double spot,
                                    SurfaceMetric metric) {
    SurfaceMarkers out;
    if (rows.empty() || spot <= 0) return out;

    std::vector<OptionRow> calls, puts;
    for (auto& r : rows) {
        double window = surfaceStrikeWindow(spot);
        if (r.strike < spot - window || r.strike > spot + window) continue;
        if (r.type == "call") calls.push_back(r);
        else puts.push_back(r);
    }

    auto pickBest = [](const std::vector<OptionRow>& v, double OptionRow::*field) {
        const OptionRow* best = nullptr;
        for (auto& r : v) if (!best || r.*field > best->*field) best = &r;
        return best;
    };

    if (!calls.empty()) {
        if (auto* bc = pickBest(calls, &OptionRow::volume)) {
            out.max_call.x = bc->strike; out.max_call.y = bc->dte;
            out.max_call.z = exactMetricAt(calls, bc->strike, bc->dte, metric, spot);
            out.max_call.strike = (int)bc->strike;
            out.max_call.volume = bc->volume; out.max_call.open_interest = bc->openInterest;
            out.max_call.valid = true;
        }
        if (auto* bc2 = pickBest(calls, &OptionRow::openInterest)) {
            out.oi_call.x = bc2->strike; out.oi_call.y = bc2->dte;
            out.oi_call.z = exactMetricAt(calls, bc2->strike, bc2->dte, metric, spot);
            out.oi_call.strike = (int)bc2->strike;
            out.oi_call.volume = bc2->volume; out.oi_call.open_interest = bc2->openInterest;
            out.oi_call.valid = true;
        }
    }
    if (!puts.empty()) {
        if (auto* bp = pickBest(puts, &OptionRow::volume)) {
            out.max_put.x = bp->strike; out.max_put.y = bp->dte;
            out.max_put.z = exactMetricAt(puts, bp->strike, bp->dte, metric, spot);
            out.max_put.strike = (int)bp->strike;
            out.max_put.volume = bp->volume; out.max_put.open_interest = bp->openInterest;
            out.max_put.valid = true;
        }
        if (auto* bp2 = pickBest(puts, &OptionRow::openInterest)) {
            out.oi_put.x = bp2->strike; out.oi_put.y = bp2->dte;
            out.oi_put.z = exactMetricAt(puts, bp2->strike, bp2->dte, metric, spot);
            out.oi_put.strike = (int)bp2->strike;
            out.oi_put.volume = bp2->volume; out.oi_put.open_interest = bp2->openInterest;
            out.oi_put.valid = true;
        }
    }
    return out;
}

} // namespace qe
