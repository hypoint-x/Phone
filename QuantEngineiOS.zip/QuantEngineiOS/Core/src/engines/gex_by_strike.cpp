#include "qe/gex_by_strike.h"
#include <map>
#include <set>
#include <algorithm>
#include <cmath>
#include <limits>

namespace qe {

GexByStrikeResult computeGexByStrike(const std::vector<OptionRow>& rows, double spot, GexWeighting weighting) {
    GexByStrikeResult out;
    out.spot = spot;
    if (rows.empty() || spot <= 0) return out;

    // Narrower near-the-money window than the surface/heatmap/gamma-walls
    // engines — see header comment.
    double lo = spot * 0.92, hi = spot * 1.08;

    std::map<double, double> call_gamma_sum, call_oi_sum, call_weight_sum, put_gamma_sum, put_oi_sum, put_weight_sum;
    for (auto& r : rows) {
        if (r.strike < lo || r.strike > hi) continue;
        double weight_contribution = (weighting == GexWeighting::Volume) ? r.volume : r.openInterest;
        if (r.type == "call") {
            call_gamma_sum[r.strike] += r.gamma;
            call_oi_sum[r.strike] += r.openInterest; // always accumulated for display, regardless of weighting choice
            call_weight_sum[r.strike] += weight_contribution;
        } else {
            put_gamma_sum[r.strike]  += r.gamma;
            put_oi_sum[r.strike]  += r.openInterest;
            put_weight_sum[r.strike] += weight_contribution;
        }
    }
    if (call_gamma_sum.empty() && put_gamma_sum.empty()) return out;

    double spot2 = spot * spot * 0.01 * 100.0; // *100 is the real options contract multiplier (each contract = 100 shares) -- this was missing before, understating every GEX value here by 100x. See gex_by_strike.h's own header note for the full derivation and the other locations in this codebase that had the same gap, now fixed together.
    for (auto& kv : call_gamma_sum) {
        double gex = kv.second * call_weight_sum[kv.first] * spot2;
        out.calls.strikes.push_back(kv.first);
        out.calls.gex.push_back(gex);
        out.calls.oi.push_back(call_oi_sum[kv.first]);
    }
    for (auto& kv : put_gamma_sum) {
        double gex = kv.second * put_weight_sum[kv.first] * spot2;
        out.puts.strikes.push_back(kv.first);
        out.puts.gex.push_back(gex);
        out.puts.oi.push_back(put_oi_sum[kv.first]);
    }

    // Wall = single highest GEX value on that side (signed, not |gamma|*OI
    // — see header for why this differs from computeGammaWalls), but
    // restricted to the directionally-correct side of spot: a call wall
    // is real resistance ABOVE current price, a put wall is real support
    // BELOW it. Without this constraint, a single strike on either side
    // of spot could be labeled as both simultaneously whenever it had
    // the largest GEX on both sides globally -- not a real "wall" in
    // the sense either label is supposed to mean, just an artifact of
    // searching the whole window with no directional restriction.
    double best_call_gex = -1e300;
    for (size_t i = 0; i < out.calls.gex.size(); ++i) {
        if (out.calls.strikes[i] < spot) continue;
        if (out.calls.gex[i] > best_call_gex) { best_call_gex = out.calls.gex[i]; out.call_wall = out.calls.strikes[i]; }
    }
    double best_put_gex = -1e300;
    for (size_t i = 0; i < out.puts.gex.size(); ++i) {
        if (out.puts.strikes[i] > spot) continue;
        if (out.puts.gex[i] > best_put_gex) { best_put_gex = out.puts.gex[i]; out.put_wall = out.puts.strikes[i]; }
    }

    std::set<double> all_strikes;
    for (double s : out.calls.strikes) all_strikes.insert(s);
    for (double s : out.puts.strikes) all_strikes.insert(s);

    auto findGex = [](const std::vector<double>& strikes, const std::vector<double>& gex, double s) {
        for (size_t i = 0; i < strikes.size(); ++i) if (strikes[i] == s) return gex[i];
        return 0.0;
    };

    // gamma_flip: real sign-change crossing point via linear
    // interpolation between adjacent strikes, sorted ascending -- same
    // fix already applied to dealer_positioning.cpp and
    // spy_settlement_engine.cpp after being found there (see
    // dealer_positioning.cpp's own comment for the full reasoning).
    // Missed here originally: this function's flip used "strike
    // minimizing |net|" instead, which could pick a strike where net
    // GEX never actually crosses zero -- and in a sparse near-the-money
    // window (few strikes with meaningful OI on both sides), that
    // degenerate selection can coincide with call_wall/put_wall landing
    // on the same edge strike, producing exactly the "all three
    // identical" result this was reported against.
    std::vector<std::pair<double,double>> sorted_net;
    for (double s : all_strikes) {
        double cg = findGex(out.calls.strikes, out.calls.gex, s);
        double pg = findGex(out.puts.strikes, out.puts.gex, s);
        double net = cg - pg;
        out.net_gex_strikes.push_back(s);
        out.net_gex_values.push_back(net);
        sorted_net.push_back({s, net});
    }
    std::sort(sorted_net.begin(), sorted_net.end());
    for (size_t i = 1; i < sorted_net.size(); ++i) {
        double s0 = sorted_net[i-1].first, v0 = sorted_net[i-1].second;
        double s1 = sorted_net[i].first, v1 = sorted_net[i].second;
        if ((v0 <= 0 && v1 > 0) || (v0 >= 0 && v1 < 0)) {
            double t = (v1 != v0) ? (0 - v0) / (v1 - v0) : 0.5;
            out.gamma_flip = s0 + t * (s1 - s0);
            break;
        }
    }
    // No sign change anywhere in the window -- gamma_flip stays unset
    // (std::optional with no value), not fabricated to spot or any
    // other placeholder.
    out.edge = out.gamma_flip ? ((spot > *out.gamma_flip) ? "LONG GAMMA" : "SHORT GAMMA") : "NEUTRAL";
    out.valid = true;
    return out;
}

} // namespace qe
