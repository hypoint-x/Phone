#include "qe/gamma_node_sequencer.h"
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include <limits>
#include <utility>

namespace qe {

namespace {

double dteWeight(int dte, const NodeSequenceConfig& cfg) {
    double d = std::max(1, dte); // 0DTE treated as 1 to avoid div/0 or a weight spike
    if (cfg.dte_weight_mode == NodeSequenceConfig::DteWeightMode::ExponentialDecay)
        return std::exp(-cfg.decay_rate * d);
    return 1.0 / std::sqrt(d);
}

// §18/19 direction of travel: short-window slope of recent closes, with
// a small dead zone so noise doesn't flip the sequence direction every
// frame.
TravelDirection directionFromCloses(const std::vector<double>& closes) {
    if (closes.size() < 2) return TravelDirection::Flat;
    size_t look = std::min(closes.size(), (size_t)6);
    double from = closes[closes.size() - look];
    double to = closes.back();
    double thresh = std::max(std::fabs(to) * 0.0008, 1e-6);
    if (to - from > thresh) return TravelDirection::Up;
    if (from - to > thresh) return TravelDirection::Down;
    return TravelDirection::Flat;
}

// §20/21 node failure: has price closed beyond `strike` (in the
// direction that would invalidate a node sitting there) for
// `failure_acceptance_bars` CONSECUTIVE closes — a break with no
// acceptance doesn't count as failure, matching §20's
// PriceBreak + TimeAcceptance definition.
bool nodeFailed(const std::vector<double>& closes, double strike, TravelDirection dir,
                 const NodeSequenceConfig& cfg) {
    if (dir == TravelDirection::Flat || closes.empty()) return false;
    double tol = strike * cfg.failure_close_beyond_pct;
    int streak = 0;
    for (double c : closes) {
        bool beyond = (dir == TravelDirection::Down) ? (c < strike - tol) : (c > strike + tol);
        streak = beyond ? streak + 1 : 0;
        if (streak >= cfg.failure_acceptance_bars) return true;
    }
    return false;
}

// §26 path-segment classification between two consecutive nodes.
SequenceType classifyTransition(const GammaCell& a, const GammaCell& b) {
    bool same_strike = std::fabs(a.strike - b.strike) < 1e-9;
    bool same_dte = a.dte_column == b.dte_column;
    if (same_dte && !same_strike) return SequenceType::Vertical;   // same DTE column, price moved through strikes
    if (same_strike && !same_dte) return SequenceType::Horizontal; // same strike, persisted/evolved across DTE
    return SequenceType::Diagonal;                                 // both changed
}

} // namespace

const GammaCell* GammaSurface::getNode(double strike, int dte_column) const {
    for (auto& c : cells)
        if (c.dte_column == dte_column && std::fabs(c.strike - strike) < 1e-9) return &c;
    return nullptr;
}

std::vector<const GammaCell*> GammaSurface::getCrossDteNodes(double strike) const {
    std::vector<const GammaCell*> out;
    for (auto& c : cells) if (std::fabs(c.strike - strike) < 1e-9) out.push_back(&c);
    std::sort(out.begin(), out.end(),
              [](const GammaCell* a, const GammaCell* b) { return a->dte_column < b->dte_column; });
    return out;
}

std::vector<const GammaCell*> GammaSurface::getPersistentNodes(double min_persistence) const {
    std::vector<const GammaCell*> out;
    for (auto& c : cells)
        if (c.node_type != NodeType::None && c.persistence_score >= min_persistence) out.push_back(&c);
    return out;
}

GammaSurface computeGammaSurface(const std::vector<OptionRow>& rows, double spot,
                                  const std::vector<double>& recent_closes,
                                  double atr, const NodeSequenceConfig& cfg) {
    GammaSurface out;
    out.spot = spot;
    if (rows.empty() || spot <= 0) return out;

    double band_lo = spot * (1.0 - cfg.proximity_band_pct);
    double band_hi = spot * (1.0 + cfg.proximity_band_pct);
    double spot2 = spot * spot * 0.01 * 100.0; // *100 is the real options contract multiplier -- was missing here too, see gex_by_strike.h's header note for the full derivation; fixed together across every GEX-computing location in this codebase

    // §1-3: bucket every row into a (strike, expiration) surface cell.
    // Gamma and OI are summed SEPARATELY then multiplied at the end
    // (rather than summing gamma*OI per-row) to match the existing
    // gex_by_strike.cpp convention exactly.
    struct Acc {
        double call_gamma = 0, put_gamma = 0;
        double call_oi = 0, put_oi = 0;
        double call_vol = 0, put_vol = 0;
        int dte = 0;
    };
    std::map<std::pair<double, std::string>, Acc> buckets;
    std::set<int> dte_set;
    for (auto& r : rows) {
        if (r.strike < band_lo || r.strike > band_hi) continue;
        Acc& a = buckets[{r.strike, r.expiration}];
        a.dte = r.dte;
        if (r.type == "call") { a.call_gamma += r.gamma; a.call_oi += r.openInterest; a.call_vol += r.volume; }
        else                  { a.put_gamma  += r.gamma; a.put_oi  += r.openInterest; a.put_vol  += r.volume; }
        dte_set.insert(r.dte);
    }
    if (buckets.empty()) return out;

    out.dte_columns.assign(dte_set.begin(), dte_set.end());
    std::sort(out.dte_columns.begin(), out.dte_columns.end());
    auto dteColumnOf = [&](int dte) -> int {
        auto it = std::lower_bound(out.dte_columns.begin(), out.dte_columns.end(), dte);
        return (int)(it - out.dte_columns.begin());
    };

    std::vector<GammaCell> built;
    built.reserve(buckets.size());
    for (auto& kv : buckets) {
        GammaCell c;
        c.strike = kv.first.first;
        c.expiration = kv.first.second;
        c.dte = kv.second.dte;
        c.dte_column = dteColumnOf(c.dte);
        c.call_gex = kv.second.call_gamma * kv.second.call_oi * spot2;
        c.put_gex  = kv.second.put_gamma  * kv.second.put_oi  * spot2;
        c.net_gex  = c.call_gex - c.put_gex;
        c.call_oi = kv.second.call_oi; c.put_oi = kv.second.put_oi; c.total_oi = c.call_oi + c.put_oi;
        c.call_volume = kv.second.call_vol; c.put_volume = kv.second.put_vol; c.total_volume = c.call_volume + c.put_volume;
        built.push_back(c);
    }

    // Normalization maxes for the §13 score components.
    double max_abs_net_gex = 1.0, max_total_oi = 1.0, max_total_volume = 1.0;
    for (auto& c : built) {
        max_abs_net_gex = std::max(max_abs_net_gex, std::fabs(c.net_gex));
        max_total_oi = std::max(max_total_oi, c.total_oi);
        max_total_volume = std::max(max_total_volume, c.total_volume);
    }
    double max_dte_weight = dteWeight(out.dte_columns.empty() ? 1 : out.dte_columns.front(), cfg);

    // Preliminary node presence (by raw GEX magnitude alone, independent
    // of the full composite score) — used only to compute §11
    // persistence without a chicken/egg dependency on node_score, which
    // itself depends on persistence.
    const double prelim_threshold_frac = 0.15;
    for (auto& c : built) {
        bool prelim = std::fabs(c.net_gex) >= prelim_threshold_frac * max_abs_net_gex;
        c.node_type = prelim ? (c.net_gex >= 0 ? NodeType::Plus : NodeType::Minus) : NodeType::None;
    }

    // §11 persistence — literal formula: NumberOfDTEColumnsContainingNode
    // / TotalDTEColumns (the surface's total column count, not just
    // columns where this strike happens to have data — a strike missing
    // from a far-dated expiration's chain is, per the spec's own
    // definition, less persistent, not "not applicable").
    std::map<double, int> strike_node_count;
    std::map<double, std::pair<int,int>> strike_sign_counts; // {plus_count, minus_count}
    for (auto& c : built) {
        if (c.node_type == NodeType::Plus)  { strike_node_count[c.strike]++; strike_sign_counts[c.strike].first++; }
        if (c.node_type == NodeType::Minus) { strike_node_count[c.strike]++; strike_sign_counts[c.strike].second++; }
    }
    double total_columns = std::max((size_t)1, out.dte_columns.size());
    for (auto& c : built) {
        int cnt = strike_node_count.count(c.strike) ? strike_node_count[c.strike] : 0;
        c.persistence_score = std::clamp((double)cnt / total_columns, 0.0, 1.0);
    }

    // §14 cross-DTE confirmation: persists across enough columns AND the
    // sign at this cell matches the majority sign among that strike's
    // qualifying columns (so a strike that flips +NODE/-NODE across
    // expirations doesn't get falsely "confirmed" on either side).
    for (auto& c : built) {
        if (c.node_type == NodeType::None) continue;
        if (c.persistence_score < cfg.cross_dte_persistence_min) continue;
        auto& sc = strike_sign_counts[c.strike];
        c.cross_dte_confirmed = (c.node_type == NodeType::Plus) ? (sc.first >= sc.second) : (sc.second >= sc.first);
    }

    // §13 composite NodeScore, then §4's floor demotes any cell that
    // doesn't clear it back to NodeType::None regardless of what the
    // preliminary GEX-only pass thought.
    for (auto& c : built) {
        double gex_score = std::fabs(c.net_gex) / max_abs_net_gex;
        double dte_score = dteWeight(c.dte, cfg) / max_dte_weight;
        double oi_score = c.total_oi / max_total_oi;
        double vol_score = c.total_volume / max_total_volume;
        double proximity_score = std::clamp(
            1.0 - std::fabs(c.strike - spot) / (spot * cfg.proximity_band_pct), 0.0, 1.0);
        c.node_score = cfg.w_gex * gex_score + cfg.w_dte * dte_score + cfg.w_oi * oi_score
                     + cfg.w_volume * vol_score + cfg.w_persistence * c.persistence_score
                     + cfg.w_proximity * proximity_score;
        if (c.node_score < cfg.node_score_min) c.node_type = NodeType::None;
    }

    out.cells = std::move(built);

    // §15/16 KING NODE / KING STRIKE / KING DTE.
    {
        const GammaCell* best = nullptr;
        for (auto& c : out.cells)
            if (c.node_type != NodeType::None && (!best || c.node_score > best->node_score)) best = &c;
        if (best) {
            out.king = *best;
            for (auto& c : out.cells)
                if (c.dte_column == best->dte_column && std::fabs(c.strike - best->strike) < 1e-9) { c.is_king = true; break; }
        }
        std::map<double, double> strike_agg;
        std::map<int, double> dte_agg;
        for (auto& c : out.cells)
            if (c.node_type != NodeType::None) { strike_agg[c.strike] += c.node_score; dte_agg[c.dte_column] += c.node_score; }
        if (!strike_agg.empty())
            out.king_strike = std::max_element(strike_agg.begin(), strike_agg.end(),
                [](auto& a, auto& b) { return a.second < b.second; })->first;
        if (!dte_agg.empty())
            out.king_dte_column = std::max_element(dte_agg.begin(), dte_agg.end(),
                [](auto& a, auto& b) { return a.second < b.second; })->first;
    }

    // §17-22, §27-30: build the current WAIT/WAIT/ENTER candidate path
    // and walk the state machine against price history.
    TravelDirection dir = directionFromCloses(recent_closes);
    NodeSequence& seq = out.active_sequence;
    seq.direction = dir;

    if (dir != TravelDirection::Flat) {
        // §18/19: qualifying nodes on the correct side of spot, ordered
        // by distance from spot ascending — this ordering IS "first/
        // second/third encountered" in the direction of travel.
        std::vector<const GammaCell*> candidates;
        for (auto& c : out.cells) {
            if (c.node_type == NodeType::None) continue;
            bool on_path = (dir == TravelDirection::Down) ? (c.strike < spot) : (c.strike > spot);
            if (on_path) candidates.push_back(&c);
        }
        std::sort(candidates.begin(), candidates.end(), [&](const GammaCell* a, const GammaCell* b) {
            return std::fabs(a->strike - spot) < std::fabs(b->strike - spot);
        });

        // Collapse same-strike candidates from different DTE columns
        // down to their strongest cell, so the 3-node path reads as
        // three distinct PRICE LEVELS rather than the same strike
        // encountered three times via three different expirations.
        std::vector<const GammaCell*> path;
        for (auto* c : candidates) {
            if (!path.empty() && std::fabs(path.back()->strike - c->strike) < 1e-9) {
                if (c->node_score > path.back()->node_score) path.back() = c;
                continue;
            }
            path.push_back(c);
            if (path.size() >= 3) break;
        }

        if (path.size() >= 1) { seq.first_node  = *path[0]; seq.has_first = true; }
        if (path.size() >= 2) { seq.second_node = *path[1]; seq.has_second = true; }
        if (path.size() >= 3) { seq.entry_node  = *path[2]; seq.has_entry  = true; }

        if (seq.has_first && seq.has_second) {
            SequenceType t1 = classifyTransition(seq.first_node, seq.second_node);
            SequenceType t2 = seq.has_entry ? classifyTransition(seq.second_node, seq.entry_node) : t1;
            seq.sequence_type = (t1 == t2) ? t1 : SequenceType::Mixed;
        }

        // §30 state machine — only walks forward as far as the evidence
        // (price history) supports; never skips ahead.
        seq.state = EntryState::NoSetup;
        if (seq.has_first) {
            seq.state = EntryState::FirstNodeTested;
            if (nodeFailed(recent_closes, seq.first_node.strike, dir, cfg)) {
                seq.state = EntryState::FirstNodeFailed;
                if (seq.has_second) {
                    seq.state = EntryState::SecondNodeTested;
                    if (nodeFailed(recent_closes, seq.second_node.strike, dir, cfg)) {
                        seq.state = EntryState::SecondNodeFailed;
                        if (seq.has_entry) {
                            double eff_atr = atr > 0 ? atr : spot * 0.005;
                            double reach_tol = std::max(eff_atr, spot * 0.001);
                            bool reached = std::fabs(spot - seq.entry_node.strike) <= reach_tol;
                            if (reached) {
                                seq.state = EntryState::EntryNodeReached;
                                seq.entry_price = spot;
                                double risk_dist = eff_atr * cfg.invalidation_atr_mult;
                                seq.invalidation_price = (dir == TravelDirection::Down)
                                    ? seq.entry_node.strike - risk_dist
                                    : seq.entry_node.strike + risk_dist;

                                // §28 target: the next qualifying node
                                // further along the same path beyond the
                                // entry node, if the surface has one;
                                // otherwise fall back to a flat
                                // min_risk_reward multiple of the risk
                                // distance.
                                const GammaCell* beyond = nullptr;
                                for (auto* c : candidates) {
                                    bool further = (dir == TravelDirection::Down)
                                        ? (c->strike < seq.entry_node.strike - 1e-9)
                                        : (c->strike > seq.entry_node.strike + 1e-9);
                                    if (further && (!beyond || std::fabs(c->strike - spot) < std::fabs(beyond->strike - spot)))
                                        beyond = c;
                                }
                                seq.target_price = beyond ? beyond->strike
                                    : (dir == TravelDirection::Down
                                        ? seq.entry_price - risk_dist * cfg.min_risk_reward
                                        : seq.entry_price + risk_dist * cfg.min_risk_reward);

                                double risk = std::fabs(seq.entry_price - seq.invalidation_price);
                                double reward = std::fabs(seq.target_price - seq.entry_price);
                                seq.risk_reward = risk > 1e-9 ? reward / risk : 0.0;
                                seq.confidence = (seq.first_node.node_score + seq.second_node.node_score + seq.entry_node.node_score) / 3.0;

                                // §29: the sequence completing does NOT
                                // automatically mean ENTER — the risk
                                // engine still has to approve it.
                                seq.state = EntryState::RiskValidation;
                                if (seq.risk_reward >= cfg.min_risk_reward) seq.state = EntryState::Entered;
                            }
                        }
                    }
                }
            }
        }
    }

    out.valid = true;
    return out;
}

const char* nodeTypeLabel(NodeType t) {
    switch (t) {
        case NodeType::Plus:  return "+NODE";
        case NodeType::Minus: return "-NODE";
        default:              return "\xE2\x80\x94"; // em dash
    }
}

const char* sequenceTypeLabel(SequenceType t) {
    switch (t) {
        case SequenceType::Vertical:   return "Vertical";
        case SequenceType::Horizontal: return "Horizontal";
        case SequenceType::Diagonal:   return "Diagonal";
        case SequenceType::Mixed:      return "Mixed";
        default:                       return "\xE2\x80\x94";
    }
}

const char* entryStateLabel(EntryState s) {
    switch (s) {
        case EntryState::FirstNodeTested:   return "First Node Tested";
        case EntryState::FirstNodeFailed:   return "First Node Failed \xE2\x80\x94 WAIT";
        case EntryState::SecondNodeTested:  return "Second Node Tested";
        case EntryState::SecondNodeFailed:  return "Second Node Failed \xE2\x80\x94 WAIT";
        case EntryState::EntryNodeReached:  return "Entry Node Reached";
        case EntryState::RiskValidation:    return "Risk Validation";
        case EntryState::Entered:           return "ENTER";
        default:                            return "No Setup \xE2\x80\x94 WAIT";
    }
}

} // namespace qe
