#include "qe/composite_engine.h"
#include <iostream>

namespace qe {

std::map<std::string, OhlcvSeries> fetchLabeledSeries(
    HttpClient& http,
    const std::vector<TickerCandidates>& wanted,
    const std::string& period, const std::string& interval) {

    std::map<std::string, OhlcvSeries> out;
    for (auto& tc : wanted) {
        bool got = false;
        for (auto& sym : tc.candidates) {
            OhlcvSeries s = fetchChart(http, sym, period, interval);
            if (s.valid && s.bars.size() >= 5) {
                // KEY FIX: always store under the friendly label, never
                // the raw ticker symbol — see composite_engine.h header
                // comment for why this matters.
                out[tc.label] = s;
                got = true;
                break;
            }
        }
        if (!got) {
            std::cerr << "[composite_engine] " << tc.label
                      << " unavailable — excluded from composite, "
                         "remaining weights renormalized.\n";
        }
    }
    return out;
}

SubindexResult computeSubindex(
    const std::map<std::string, OhlcvSeries>& data,
    const std::vector<SubindexInput>& inputs) {

    SubindexResult res;
    res.inputs_total = (int)inputs.size();

    double weight_sum = 0.0, weighted_z = 0.0;
    for (auto& in : inputs) {
        auto it = data.find(in.label);
        if (it == data.end() || !it->second.valid) {
            res.excluded.push_back(in.label);
            continue;
        }
        double z = zscoreLast(it->second.closes());
        if (in.invert) z = -z;
        weighted_z += z * in.weight;
        weight_sum += in.weight;
        res.inputs_used++;
    }

    if (weight_sum < 1e-9) {
        res.valid = false;
        return res;
    }
    res.value = weighted_z / weight_sum; // renormalized over available weight
    res.valid = true;
    return res;
}

} // namespace qe
