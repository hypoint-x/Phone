#include "qe/markov_engine.h"
#include <algorithm>
#include <numeric>

namespace qe {

MarkovEngine::MarkovEngine() {
    transition_ = {{
        {0.55, 0.30, 0.15},   // from U
        {0.25, 0.50, 0.25},   // from N
        {0.15, 0.30, 0.55},   // from D
    }};
}

MarkovForecast MarkovEngine::forecast(MarkovState current_state) const {
    MarkovForecast out;
    const auto& row = transition_[(int)current_state];
    out.probability_up = row[0];
    out.probability_neutral = row[1];
    out.probability_down = row[2];
    out.transition_row = row;

    int best = 0;
    for (int i = 1; i < 3; ++i) if (row[i] > row[best]) best = i;
    out.predicted_state = (MarkovState)best;
    return out;
}

void MarkovEngine::nudge(MarkovState from_state, MarkovState to_state, double learning_rate) {
    auto& row = transition_[(int)from_state];
    row[(int)to_state] += learning_rate;
    double total = row[0] + row[1] + row[2];
    if (total <= 0.0) total = 1.0;
    for (auto& v : row) v /= total;
}

} // namespace qe
