#include "qe/intensity_cloud.h"
#include <map>
#include <set>
#include <cmath>
#include <algorithm>

namespace qe {

IntensityCloud computeIntensityCloud(const std::vector<OptionRow>& rows, double spot,
                                      IntensityMetric metric, double band) {
    IntensityCloud out;
    out.spot = spot;
    if (rows.empty()) return out;

    auto metricValue = [metric, spot](const OptionRow& r) -> double {
        return optionMetricValue(r, metric, spot);
    };

    std::map<double, double> call_sum, put_sum;
    for (auto& r : rows) {
        if (spot > 0 && (r.strike < spot - band || r.strike > spot + band)) continue;
        double v = metricValue(r);
        if (r.type == "call") call_sum[r.strike] += v;
        else                  put_sum[r.strike]  += v;
    }
    if (call_sum.empty() && put_sum.empty()) return out;

    std::set<double> strikes;
    for (auto& kv : call_sum) strikes.insert(kv.first);
    for (auto& kv : put_sum) strikes.insert(kv.first);

    double max_val = 1.0; // "or 1" guard, matches the Python fallback
    for (double s : strikes) {
        double c = call_sum.count(s) ? call_sum[s] : 0.0;
        double p = put_sum.count(s) ? put_sum[s] : 0.0;
        max_val = std::max({max_val, std::fabs(c), std::fabs(p)});
    }

    for (double s : strikes) {
        double c = call_sum.count(s) ? call_sum[s] : 0.0;
        double p = put_sum.count(s) ? put_sum[s] : 0.0;
        IntensityCloudRow row;
        row.strike = s; row.call = c; row.put = p; row.net = c - p;
        row.call_dominant = c >= p;
        double magnitude = std::max(c, p);
        row.intensity = (float)std::min(magnitude / max_val, 1.0);
        out.rows.push_back(row);
    }
    std::sort(out.rows.begin(), out.rows.end(),
              [](const IntensityCloudRow& a, const IntensityCloudRow& b) { return a.strike < b.strike; });

    out.valid = true;
    return out;
}

} // namespace qe
