#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Net Flow engine — aggregate call vs. put premium flow across the loaded
// option chain, broken down by DTE bucket (NetFlowResult / computeNetFlow,
// unchanged), plus a live, time-sampled tracker (NetFlowTracker) that turns
// successive option-chain snapshots into the "1D FLOW" running line chart:
// cumulative call premium bought, cumulative put premium bought, and their
// net, sampled once per snapshot since the tracker was created/reset —
// mirroring the reference UI's "live-sampled since page load" chart.
//
// TRANSPARENCY NOTE: no function named `net_flow` (or a close variant)
// exists anywhere in the Python source — I searched for net_flow,
// flow_score, "net flow", "option flow", premium_flow, and related terms
// and found nothing exactly matching. The closest adjacent concepts are
// strike_heatmap.h's per-strike net (call - put) notional, and
// compute_institutional_flow's cash/futures basis proxies — neither of
// which is "net flow" in the usual sense (aggregate net premium being
// bought into calls vs. puts, as a single read rather than a per-strike
// breakdown).
//
// Both NetFlowResult (snapshot bucket totals) and NetFlowTracker (live
// running series) are a standard, well-defined synthesis of that concept
// built from data this app already has (OptionRow.notional/.volume), not
// a port of an existing function. If you had a specific existing tool in
// mind under this name, let me know what it should actually compute and
// I'll redo it — this is a best-effort interpretation, not a verified port.
//
// NetFlowTracker's flow model: each OptionRow only exposes Yahoo's
// cumulative *session* volume, not individual prints, so "flow" here is
// inferred as volume-delta-since-last-snapshot × lastPrice × 100 (contract
// multiplier), attributed entirely to whichever side (call/put) the
// contract belongs to. That's the same inference every retail "options
// flow" tool built on snapshot polling makes (Yahoo/most brokers don't
// expose a true trade-by-trade tape for free); it can't distinguish a
// buy-to-open from a sell-to-close, so it's a flow-magnitude proxy, not a
// signed-aggressor read. Contracts are matched across snapshots by
// (strike, type, expiration) since Yahoo doesn't give a stable contract
// id in the fields this app already parses.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <string>
#include <map>

namespace qe {

struct NetFlowBucket {
    std::string label;     // "0DTE" | "1-5DTE" | "6+DTE"
    double call_notional = 0, put_notional = 0;
    double call_volume = 0, put_volume = 0;
    double net_notional = 0;  // call_notional - put_notional
    double call_put_ratio = 0; // call_volume / (call_volume + put_volume), 0.5 = balanced
};

struct NetFlowResult {
    std::vector<NetFlowBucket> buckets; // "0DTE", "1-5DTE", "6+DTE"
    double total_call_notional = 0, total_put_notional = 0;
    double total_net_notional = 0;
    double total_call_put_ratio = 0.5;
    std::string bias = "NEUTRAL"; // "CALL-DOMINANT" | "PUT-DOMINANT" | "NEUTRAL"
    bool valid = false;
};

NetFlowResult computeNetFlow(const std::vector<OptionRow>& rows);

// ── Live time-series tracker (the "1D FLOW" chart) ─────────────────────
struct NetFlowSample {
    double t_seconds = 0;      // elapsed seconds since tracker start/reset
    double call_premium = 0;   // cumulative call premium flow ($) since start
    double put_premium = 0;    // cumulative put premium flow ($) since start
    double net_premium = 0;    // call_premium - put_premium
    double spot = 0;           // underlying price at sample time
};

// Stateful, single-writer, NOT thread-safe by design (same convention as
// markov_engine.h's module-level dict it's adjacent to) — call update()
// only from the one thread/cache tick that owns the option-chain snapshot
// (the UI's main-thread render loop reading EngineCache<OptionChain>::get()
// results, in practice).
class NetFlowTracker {
public:
    // Feeds one option-chain snapshot in. Safe to call with the same
    // snapshot repeatedly (e.g. every UI frame) — it internally recomputes
    // deltas against last-seen per-contract volume, so a snapshot that
    // hasn't actually changed since the last call contributes zero flow
    // and does not push a duplicate sample. `now_seconds` should be a
    // monotonic clock (e.g. glfwGetTime()); the first call establishes
    // the tracker's t=0 origin ("since page load").
    void update(const OptionChain& chain, double now_seconds);

    // Clears all history and per-contract volume memory, restarting the
    // "since page load" origin at the next update() call. Call this on
    // ticker change (a SPY put isn't the same instrument as an AAPL put)
    // so the chart doesn't show a spurious cross-ticker discontinuity.
    void reset();

    const std::vector<NetFlowSample>& history() const { return history_; }
    bool hasData() const { return !history_.empty(); }

private:
    struct ContractKey {
        double strike; std::string type, expiration;
        bool operator<(const ContractKey& o) const {
            if (strike != o.strike) return strike < o.strike;
            if (type != o.type) return type < o.type;
            return expiration < o.expiration;
        }
    };

    std::map<ContractKey, double> last_volume_;
    std::vector<NetFlowSample> history_;
    double call_cum_ = 0, put_cum_ = 0;
    double t0_ = -1;         // origin timestamp, set on first update()
    double last_sample_t_ = -1e18;
    bool have_baseline_ = false; // first snapshot only seeds last_volume_,
                                  // contributes no flow (nothing to diff against)

    // Caps how much history is retained so a long-running session doesn't
    // grow this unbounded; oldest samples are dropped once exceeded. At a
    // typical 15-30s refresh cadence this comfortably covers a full
    // trading day before anything is trimmed.
    static constexpr size_t kMaxSamples = 4000;
    // Minimum spacing between chart samples so this is driven by the
    // underlying cache refresh cadence, not the ~60fps render loop calling
    // update() every frame with an unchanged snapshot.
    static constexpr double kMinSampleGapSeconds = 1.0;
};

} // namespace qe
