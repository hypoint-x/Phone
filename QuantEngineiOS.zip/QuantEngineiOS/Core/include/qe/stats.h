#pragma once
// ─────────────────────────────────────────────────────────────────────────
// stats — small shared statistics helpers used across every engine
// (z-scores for composite indices, Wilder RSI, rolling stats).
// ─────────────────────────────────────────────────────────────────────────
#include <vector>
#include <cmath>
#include <numeric>
#include <algorithm>

namespace qe {

inline double mean(const std::vector<double>& v) {
    if (v.empty()) return 0.0;
    return std::accumulate(v.begin(), v.end(), 0.0) / v.size();
}

inline double stddev(const std::vector<double>& v) {
    if (v.size() < 2) return 0.0;
    double m = mean(v);
    double acc = 0.0;
    for (double x : v) acc += (x - m) * (x - m);
    return std::sqrt(acc / (v.size() - 1));
}

// z-score of the last value in `series` relative to the full series
// (matches the Python version's `(x - x.mean()) / x.std()` pattern used
// throughout MLE/CE/SPLE for each subindex component).
inline double zscoreLast(const std::vector<double>& series) {
    if (series.empty()) return 0.0;
    double s = stddev(series);
    if (s < 1e-12) return 0.0;
    return (series.back() - mean(series)) / s;
}

// Wilder's RSI — ported from the FIXED Python version (compute_rsi), which
// was corrected from a plain rolling-mean approximation to proper Wilder
// exponential smoothing (alpha = 1/period), matching what TradingView/
// ThinkorSwim show. The plain-rolling-mean version diverges noticeably
// right after trend changes — exactly when RSI-based overbought/oversold
// signals matter most.
inline std::vector<double> wilderRsi(const std::vector<double>& closes, int period = 14) {
    std::vector<double> rsi(closes.size(), 50.0);
    if ((int)closes.size() <= period) return rsi;

    std::vector<double> gains(closes.size(), 0.0), losses(closes.size(), 0.0);
    for (size_t i = 1; i < closes.size(); ++i) {
        double delta = closes[i] - closes[i - 1];
        gains[i]  = delta > 0 ? delta : 0.0;
        losses[i] = delta < 0 ? -delta : 0.0;
    }

    // Seed with simple average over the first `period` bars (bars 1..period)
    double avg_gain = 0.0, avg_loss = 0.0;
    for (int i = 1; i <= period; ++i) { avg_gain += gains[i]; avg_loss += losses[i]; }
    avg_gain /= period; avg_loss /= period;

    auto rsiFrom = [](double ag, double al) {
        if (al < 1e-12) return 100.0;
        double rs = ag / al;
        return 100.0 - (100.0 / (1.0 + rs));
    };
    rsi[period] = rsiFrom(avg_gain, avg_loss);

    double alpha = 1.0 / period;
    for (size_t i = period + 1; i < closes.size(); ++i) {
        avg_gain = alpha * gains[i] + (1 - alpha) * avg_gain;
        avg_loss = alpha * losses[i] + (1 - alpha) * avg_loss;
        rsi[i] = rsiFrom(avg_gain, avg_loss);
    }
    return rsi;
}

// Pandas-equivalent `series.ewm(span=X).mean()` (adjust=True, the pandas
// default) — returns only the last value, since that's all callers like
// compute_mtf_bias need. Differs subtly from a plain recursive EMA
// (adjust=False) in the first ~1/alpha bars while the weight-normalizing
// denominator is still ramping up; converges to the same steady-state
// value after that. Ported this way (rather than the simpler recursive
// form used elsewhere in this codebase for the ticker-chart EMAs) because
// the Python compute_mtf_bias() specifically used pandas .ewm(...).mean()
// with its default adjust=True, and the two forms are NOT numerically
// identical on the shorter timeframe series (e.g. 63-bar daily) MTF uses.
inline double ewmMeanLastAdjustTrue(const std::vector<double>& x, double span) {
    if (x.empty()) return 0.0;
    double alpha = 2.0 / (span + 1.0);
    double numerator = x[0];
    double denominator = 1.0;
    for (size_t i = 1; i < x.size(); ++i) {
        numerator = x[i] + (1.0 - alpha) * numerator;
        denominator = 1.0 + (1.0 - alpha) * denominator;
    }
    return numerator / denominator;
}

// Full-series version of ewmMeanLastAdjustTrue, for callers that need
// more than just the last value (e.g. detecting a crossover between the
// last two bars).
inline std::vector<double> ewmMeanAdjustTrue(const std::vector<double>& x, double span) {
    std::vector<double> out(x.size(), 0.0);
    if (x.empty()) return out;
    double alpha = 2.0 / (span + 1.0);
    double numerator = x[0];
    double denominator = 1.0;
    out[0] = numerator / denominator;
    for (size_t i = 1; i < x.size(); ++i) {
        numerator = x[i] + (1.0 - alpha) * numerator;
        denominator = 1.0 + (1.0 - alpha) * denominator;
        out[i] = numerator / denominator;
    }
    return out;
}

// tanh-squashes a raw value into [-1,1] using `scale` as the ~1-sigma
// reference, so components with very different natural units can be
// linearly combined — ported from the Python version's _qe_zclip().
inline double zClip(double x, double scale) {
    if (scale == 0.0) return 0.0;
    return std::tanh(x / scale);
}

// Plain recursive EMA (adjust=False-equivalent, seeded by the first
// value) — the shared version of the small static helper that used to
// live only in spy_ema_chart_engine.cpp. Moved here so ma_ladder_engine.cpp
// can use the identical math for its EMA5/9/22/50/200 ladder rather than
// hand-rolling a second copy; spy_ema_chart_engine.cpp's own EMA9/20/50
// now call this too (behavior unchanged, see that file's header comment
// for why this form is kept distinct from mtf_engine's adjust=True EMA).
inline std::vector<double> recursiveEma(const std::vector<double>& prices, double span) {
    std::vector<double> out;
    out.reserve(prices.size());
    if (prices.empty()) return out;
    double k = 2.0 / (span + 1.0);
    double val = prices[0];
    for (double p : prices) {
        val = p * k + val * (1.0 - k);
        out.push_back(val);
    }
    return out;
}

// Wilder's ATR — same smoothing shape as wilderRsi() above (seed with a
// simple average of the first `period` true-range values, then smooth
// with alpha = 1/period), applied to true range instead of gain/loss.
// Used by the Keltner Channel bands added to spy_ema_chart_engine.h.
inline std::vector<double> wilderAtr(const std::vector<double>& highs, const std::vector<double>& lows,
                                      const std::vector<double>& closes, int period = 20) {
    size_t n = closes.size();
    std::vector<double> atr(n, 0.0);
    if ((int)n <= period) return atr;

    std::vector<double> tr(n, 0.0);
    tr[0] = highs[0] - lows[0];
    for (size_t i = 1; i < n; ++i) {
        double a = highs[i] - lows[i];
        double b = std::fabs(highs[i] - closes[i - 1]);
        double c = std::fabs(lows[i] - closes[i - 1]);
        tr[i] = std::max({a, b, c});
    }

    double avg = 0.0;
    for (int i = 1; i <= period; ++i) avg += tr[i];
    avg /= period;
    atr[period] = avg;

    double alpha = 1.0 / period;
    for (size_t i = period + 1; i < n; ++i) {
        avg = alpha * tr[i] + (1 - alpha) * avg;
        atr[i] = avg;
    }
    // Back-fill the warmup region with the first computed value so callers
    // don't have to special-case leading zeros (matches wilderRsi's
    // "flat 50.0 until seeded" convention, just with ATR's own seed value).
    for (size_t i = 0; i < (size_t)period && i < n; ++i) atr[i] = atr[period];
    return atr;
}

// On-Balance Volume — cumulative running total, +volume on an up close,
// -volume on a down close, unchanged on a flat close. Standard definition,
// no Python original to port (this app's original had no OBV read).
inline std::vector<double> onBalanceVolume(const std::vector<double>& closes, const std::vector<double>& volumes) {
    std::vector<double> obv(closes.size(), 0.0);
    if (closes.empty()) return obv;
    obv[0] = 0.0;
    for (size_t i = 1; i < closes.size(); ++i) {
        if (closes[i] > closes[i - 1]) obv[i] = obv[i - 1] + volumes[i];
        else if (closes[i] < closes[i - 1]) obv[i] = obv[i - 1] - volumes[i];
        else obv[i] = obv[i - 1];
    }
    return obv;
}

struct StochRsiResult {
    std::vector<double> k, d; // both 0-100
};

// StochRSI(14,14,3,3): stochastic oscillator applied to Wilder RSI(14)
// instead of price, then %K/%D smoothed with 3-period simple moving
// averages — the standard/default parameterization (TradingView, ToS).
// No Python original to port; this app had no StochRSI read before.
inline StochRsiResult computeStochRsi(const std::vector<double>& closes, int rsi_period = 14,
                                       int stoch_period = 14, int smooth_k = 3, int smooth_d = 3) {
    StochRsiResult out;
    size_t n = closes.size();
    out.k.assign(n, 50.0);
    out.d.assign(n, 50.0);
    if ((int)n <= rsi_period + stoch_period) return out;

    std::vector<double> rsi = wilderRsi(closes, rsi_period);
    std::vector<double> raw_k(n, 50.0);
    for (size_t i = 0; i < n; ++i) {
        size_t start = (i + 1 >= (size_t)stoch_period) ? i + 1 - stoch_period : 0;
        double lo = rsi[start], hi = rsi[start];
        for (size_t k = start; k <= i; ++k) { lo = std::min(lo, rsi[k]); hi = std::max(hi, rsi[k]); }
        raw_k[i] = (hi - lo < 1e-9) ? 0.0 : (rsi[i] - lo) / (hi - lo) * 100.0;
    }

    auto sma = [](const std::vector<double>& v, int period) {
        std::vector<double> o(v.size(), 0.0);
        for (size_t i = 0; i < v.size(); ++i) {
            size_t start = (i + 1 >= (size_t)period) ? i + 1 - period : 0;
            double sum = 0.0;
            for (size_t k = start; k <= i; ++k) sum += v[k];
            o[i] = sum / (i - start + 1);
        }
        return o;
    };
    out.k = sma(raw_k, smooth_k);
    out.d = sma(out.k, smooth_d);
    return out;
}

struct AdxResult {
    std::vector<double> adx, di_plus, di_minus; // all 0-100
};

// Wilder's Average Directional Index (ADX) + DI+/DI-, period 14 by
// default — the standard trend-strength read (ADX itself doesn't say
// which way price is trending, only how strongly; DI+ vs DI- gives the
// direction). Same Wilder smoothing shape as wilderRsi/wilderAtr above
// (seed with a simple average over the first `period` bars, then smooth
// with alpha = 1/period), applied to +DM/-DM/TR. No Python original to
// port — new for the Chart+ trend-strength/timeframe-recommendation
// features.
inline AdxResult wilderAdx(const std::vector<double>& highs, const std::vector<double>& lows,
                            const std::vector<double>& closes, int period = 14) {
    size_t n = closes.size();
    AdxResult out;
    out.adx.assign(n, 0.0);
    out.di_plus.assign(n, 0.0);
    out.di_minus.assign(n, 0.0);
    if ((int)n <= period * 2) return out; // need warmup for +DM/-DM smoothing, then again for DX->ADX smoothing

    std::vector<double> plus_dm(n, 0.0), minus_dm(n, 0.0), tr(n, 0.0);
    for (size_t i = 1; i < n; ++i) {
        double up_move = highs[i] - highs[i - 1];
        double down_move = lows[i - 1] - lows[i];
        plus_dm[i]  = (up_move > down_move && up_move > 0.0) ? up_move : 0.0;
        minus_dm[i] = (down_move > up_move && down_move > 0.0) ? down_move : 0.0;
        double a = highs[i] - lows[i];
        double b = std::fabs(highs[i] - closes[i - 1]);
        double c = std::fabs(lows[i] - closes[i - 1]);
        tr[i] = std::max({a, b, c});
    }

    double smoothed_plus_dm = 0.0, smoothed_minus_dm = 0.0, smoothed_tr = 0.0;
    for (int i = 1; i <= period; ++i) { smoothed_plus_dm += plus_dm[i]; smoothed_minus_dm += minus_dm[i]; smoothed_tr += tr[i]; }

    std::vector<double> dx(n, 0.0);
    auto diFrom = [&](double sp, double sm, double str) {
        double dip = str < 1e-12 ? 0.0 : 100.0 * sp / str;
        double dim = str < 1e-12 ? 0.0 : 100.0 * sm / str;
        return std::make_pair(dip, dim);
    };
    {
        auto [dip, dim] = diFrom(smoothed_plus_dm, smoothed_minus_dm, smoothed_tr);
        out.di_plus[period] = dip; out.di_minus[period] = dim;
        dx[period] = (dip + dim) < 1e-12 ? 0.0 : 100.0 * std::fabs(dip - dim) / (dip + dim);
    }
    double alpha = 1.0 / period;
    for (size_t i = period + 1; i < n; ++i) {
        smoothed_plus_dm  = (1 - alpha) * smoothed_plus_dm  + plus_dm[i];
        smoothed_minus_dm = (1 - alpha) * smoothed_minus_dm + minus_dm[i];
        smoothed_tr       = (1 - alpha) * smoothed_tr       + tr[i];
        auto [dip, dim] = diFrom(smoothed_plus_dm, smoothed_minus_dm, smoothed_tr);
        out.di_plus[i] = dip; out.di_minus[i] = dim;
        dx[i] = (dip + dim) < 1e-12 ? 0.0 : 100.0 * std::fabs(dip - dim) / (dip + dim);
    }

    // ADX = Wilder-smoothed DX, seeded by a simple average of the first
    // `period` DX values (indices period..2*period-1), then smoothed.
    size_t adx_seed_end = std::min(n, (size_t)(period * 2));
    double avg_dx = 0.0; int cnt = 0;
    for (size_t i = period; i < adx_seed_end; ++i) { avg_dx += dx[i]; ++cnt; }
    if (cnt > 0) avg_dx /= cnt;
    if (adx_seed_end - 1 < n) out.adx[adx_seed_end - 1] = avg_dx;
    for (size_t i = adx_seed_end; i < n; ++i) {
        avg_dx = (avg_dx * (period - 1) + dx[i]) / period;
        out.adx[i] = avg_dx;
    }
    // Back-fill warmup so callers don't special-case leading zeros.
    for (size_t i = 0; i < adx_seed_end && i < n; ++i) out.adx[i] = out.adx[std::min(adx_seed_end, n - 1)];
    return out;
}

struct LinRegChannel {
    double slope = 0.0, intercept = 0.0, r2 = 0.0, stdev = 0.0;
    std::vector<double> mid, upper, lower; // same length as input, +/- 2*stdev band
    bool valid = false;
};

// Ordinary least-squares regression of `y` against bar index (0..n-1),
// plus a +/-`bands` standard-deviation channel around the fitted line —
// the "objective trend line" overlay: slope's sign is the trend
// direction, r2 is how clean/reliable that trend has been over this
// window, and the channel gives a mean-reversion band around it. No
// Python original to port — new for Chart+.
inline LinRegChannel linregChannel(const std::vector<double>& y, double bands = 2.0) {
    LinRegChannel out;
    size_t n = y.size();
    if (n < 3) return out;

    double sum_x = 0, sum_y = 0, sum_xy = 0, sum_xx = 0;
    for (size_t i = 0; i < n; ++i) {
        double x = (double)i;
        sum_x += x; sum_y += y[i]; sum_xy += x * y[i]; sum_xx += x * x;
    }
    double nD = (double)n;
    double denom = nD * sum_xx - sum_x * sum_x;
    if (std::fabs(denom) < 1e-12) return out;
    out.slope = (nD * sum_xy - sum_x * sum_y) / denom;
    out.intercept = (sum_y - out.slope * sum_x) / nD;

    out.mid.resize(n);
    double ss_res = 0.0, ss_tot = 0.0;
    double y_mean = sum_y / nD;
    for (size_t i = 0; i < n; ++i) {
        double fitted = out.intercept + out.slope * (double)i;
        out.mid[i] = fitted;
        ss_res += (y[i] - fitted) * (y[i] - fitted);
        ss_tot += (y[i] - y_mean) * (y[i] - y_mean);
    }
    out.r2 = ss_tot < 1e-12 ? 0.0 : 1.0 - (ss_res / ss_tot);
    out.stdev = std::sqrt(ss_res / nD);

    out.upper.resize(n);
    out.lower.resize(n);
    for (size_t i = 0; i < n; ++i) {
        out.upper[i] = out.mid[i] + bands * out.stdev;
        out.lower[i] = out.mid[i] - bands * out.stdev;
    }
    out.valid = true;
    return out;
}

// Percentile rank (0-100) of the last value within its own trailing
// history — e.g. "is today's ATR high or low relative to the last N
// readings", a volatility-regime read with no external reference table
// needed. Ties count as "at or below".
inline double percentileRankLast(const std::vector<double>& series, size_t lookback) {
    if (series.empty()) return 50.0;
    size_t end = series.size();
    size_t start = end > lookback ? end - lookback : 0;
    double last = series[end - 1];
    size_t count_le = 0, total = 0;
    for (size_t i = start; i < end; ++i) {
        if (series[i] <= last) ++count_le;
        ++total;
    }
    return total == 0 ? 50.0 : 100.0 * (double)count_le / (double)total;
}

} // namespace qe
