#pragma once
// ─────────────────────────────────────────────────────────────────────────
// GexLevelsPro — a new Quant-menu tool: real, deterministic options-
// derived price levels (gamma flip, call/put walls, ranked GEX
// concentrations, max pain, expected move, day high/low), each
// classified into a dealer-hedging zone by real, established options
// market-structure rules (not the LLM's own judgment), with an LLM
// narrator that explains what each level means in plain language --
// synthesis over already-computed numbers, same "code decides, the LLM
// narrates" principle as every other tool in this app.
//
// ── What's real vs. what the LLM does ────────────────────────────────
// Every number here is computed by code from the real options chain:
//   - gamma_flip / call_wall / put_wall: reused directly from
//     computeGexByStrike (gex_by_strike.h), unchanged.
//   - GEX 1-5: the top strikes by |net GEX| from that same engine's own
//     net_gex_strikes/net_gex_values, excluding whichever strikes are
//     already the call/put wall so nothing is double-labeled.
//   - Max Pain: the real, standard formula -- the strike where the
//     aggregate dollar loss to option WRITERS (calls ITM below it,
//     puts ITM above it, each times real open interest) is minimized.
//   - Expected Move: the standard approximation, ATM implied
//     volatility x spot x sqrt(days to expiry / 365).
//   - Day High/Low: real OHLC data for the current session.
// The dealer-hedging ZONE each level gets (BUY/SELL/ACCELERATION_UP/
// ACCELERATION_DOWN/PIVOT) is also a deterministic rule based on real,
// established market-maker hedging theory (net long gamma above spot
// -> dealers sell into rallies = resistance; net long gamma below spot
// -> dealers buy dips = support; net SHORT gamma amplifies whichever
// direction price is already moving, rather than dampening it) -- not
// an LLM guess. The LLM's only job is the NARRATIVE explaining a given
// level's classification in plain language, and it's given the real
// classification and numbers to explain, not asked to invent them.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/gex_by_strike.h"
#include "qe/intensity_cloud.h" // IntensityMetric, computeIntensityCloud -- reused for the heatmap strip
#include "qe/yahoo_endpoints.h" // OptionRow, OhlcvSeries
#include "qe/http_client.h"
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <thread>

namespace qe {

enum class GexZone { Buy, Sell, AccelerationUp, AccelerationDown, Pivot, Neutral };
const char* gexZoneLabel(GexZone z);

struct GexLevel {
    std::string label;   // "Call Wall", "Put Wall", "Gamma Flip (Zero Gamma)", "GEX 1".."GEX 5", "Max Pain", "Expected Move (Upper)", "Expected Move (Lower)", "Day High", "Day Low"
    double price = 0;
    double net_gex = 0;  // 0 for levels that aren't a GEX concentration point (Max Pain, Expected Move, Day High/Low) -- OI-weighted, matches gamma_flip/call_wall/put_wall
    GexZone zone = GexZone::Neutral;
    std::string narrative; // filled in by the LLM narrator; empty until it runs

    // Real per-level breakdown, populated for GEX concentration points
    // (walls, flip, GEX 1-5) -- zero/empty for the non-GEX levels (Max
    // Pain, Expected Move, Day High/Low), which were never call/put
    // concentration points to begin with.
    double call_gex = 0, put_gex = 0;       // real, un-netted, OI-weighted (same formula as net_gex, split by side)
    double net_gex_by_volume = 0;           // same net-GEX shape, but volume-weighted instead of OI-weighted
    double call_oi = 0, put_oi = 0;         // real open interest at this strike, each side
    double call_intensity = 0, put_intensity = 0; // [0,1], each side's |gex| relative to the max |gex| across this result's own GEX-concentration levels -- for bar-width scaling, not a probability
};

struct GexLevelsProResult {
    std::string symbol;
    double spot = 0;
    std::string dealer_regime; // "LONG GAMMA" | "SHORT GAMMA", reused directly from computeGexByStrike's own edge field
    std::vector<GexLevel> levels;
    long long generated_at = 0;
    bool valid = false;

    // Carried for the panel's candlestick chart + heatmap strip, so
    // both can render/re-zoom without a second network round-trip.
    std::vector<OptionRow> option_rows; // real chain, for on-demand intensity-cloud recomputation (Notional/Volume/OI) at whatever price band is currently visible -- NOT filtered to one expiration, since Notional/Volume/OI intensity is legitimately a multi-expiration aggregate
    std::vector<OptionRow> nearest_expiry_rows; // same chain, filtered to the single nearest expiration -- use this (not option_rows) for any on-demand GEX-by-strike recomputation, since computeGexByStrike requires single-expiration input to avoid summing gamma*OI across different expirations at the same strike
    std::vector<long long> bar_times;
    std::vector<double> bar_opens, bar_highs, bar_lows, bar_closes;

    // The SAME per-strike net GEX values gamma_flip/call_wall/put_wall
    // above are computed from (computeGexByStrike's own spot^2-scaled
    // formula, narrower ~8% band) -- kept separate from option_rows so
    // the heatmap strip's "GEX" metric can use these EXACT numbers
    // rather than recomputing GEX via intensity_cloud.h's own,
    // genuinely different formula (gamma*OI*100*spot, no band
    // restriction). Using two different GEX formulas side by side was
    // the actual bug: the heatmap's red/green zero-crossing wouldn't
    // necessarily land at the same price as the Gamma Flip line, since
    // they were computed two different ways. This field exists so the
    // panel doesn't have to choose between "wrong" and "inconsistent."
    std::vector<double> net_gex_strikes, net_gex_values;

    // Full per-strike call/put GEX, for every strike in computeGexByStrike's
    // own ~8% band -- not just the named levels above. This is what lets the
    // chart's intensity cloud show call vs put intensity at every strike,
    // the same per-strike granularity Quant Tool's own cloud has, rather
    // than only the 5-8 named levels (walls/flip/GEX 1-5).
    std::vector<double> call_gex_strikes, call_gex_values, call_gex_oi;
    std::vector<double> put_gex_strikes, put_gex_values, put_gex_oi;
};

// Pure computation, no LLM -- narratives are empty on the returned
// levels. day_high/day_low: pass 0 for either if not available; those
// levels are simply omitted rather than fabricated.
GexLevelsProResult computeGexLevelsPro(const std::string& symbol, const std::vector<OptionRow>& rows, double spot,
                                        double day_high, double day_low);

// Real, standard Max Pain formula -- returns 0 if rows is empty.
double computeMaxPain(const std::vector<OptionRow>& rows);

// Real, standard one-sigma expected move approximation (ATM implied
// vol x spot x sqrt(dte/365), using the nearest-dated expiry's ATM
// strike) -- returns 0 if rows is empty. The result is the +/- price
// distance, not an absolute level.
double computeExpectedMoveOneSigma(const std::vector<OptionRow>& rows, double spot);


} // namespace qe
