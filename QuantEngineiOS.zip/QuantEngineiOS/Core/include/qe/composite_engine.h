#pragma once
// ─────────────────────────────────────────────────────────────────────────
// composite_engine — shared machinery for the "fetch a basket of tickers,
// z-score each one, blend into weighted subindices" pattern used by the
// Macro Liquidity Engine, Commodities Engine, and SP500 Liquidity Engine.
//
// This is where the SPLE column-mislabeling bug lived in the Python
// version: download_symbol() named its column after the raw ticker
// ("DX-Y.NYB", "JPY=X"...) instead of the friendly label ("DXY",
// "USDJPY"...) that every subindex formula looked up, so lookups silently
// failed and those inputs were dropped. fetchLabeledSeries() below always
// keys results by the caller's friendly label, never the raw ticker, so
// that entire bug class can't recur.
// ─────────────────────────────────────────────────────────────────────────
#include <string>
#include <vector>
#include <map>
#include <optional>
#include "qe/yahoo_endpoints.h"
#include "qe/stats.h"

namespace qe {

struct TickerCandidates {
    std::string label;                    // friendly key, e.g. "US02Y"
    std::vector<std::string> candidates;  // tried in order until one succeeds
};

// Fetches every entry in `wanted`, trying each ticker candidate in order
// until one returns valid data (mirrors the Python engines' graceful
// degradation — a symbol failing just means that input drops out of the
// composite and downstream weights renormalize around what's left).
// Keys of the returned map are always the friendly `label`, never the
// raw ticker — this is the fix for the SPLE bug described above.
std::map<std::string, OhlcvSeries> fetchLabeledSeries(
    HttpClient& http,
    const std::vector<TickerCandidates>& wanted,
    const std::string& period, const std::string& interval);

// A named subindex input: how much weight it carries and which direction
// counts as "bullish for this subindex" (some inputs are inverted, e.g.
// rising DXY is bearish for USD liquidity/risk appetite).
struct SubindexInput {
    std::string label;
    double weight;
    bool invert = false; // true if a HIGHER z-score for this input should
                          // SUBTRACT from the subindex (e.g. rising VIX
                          // is risk-off, not risk-on)
};

struct SubindexResult {
    double value = 0.0;        // weighted-average z-score, renormalized
                                // over whatever inputs were actually present
    int inputs_used = 0;
    int inputs_total = 0;
    std::vector<std::string> excluded; // labels that failed to fetch, disclosed
    bool valid = false;
};

// Computes a weighted composite z-score across `inputs`, using whatever
// subset of `data` is present. Weights of missing inputs are dropped and
// the remaining weights renormalized to sum to 1 — this is the "disclosed
// exclusion" pattern used throughout the Python version's MLE/CE (e.g.
// "MOVE index unavailable via yfinance") rather than silently substituting
// a default value that would corrupt the composite.
SubindexResult computeSubindex(
    const std::map<std::string, OhlcvSeries>& data,
    const std::vector<SubindexInput>& inputs);

} // namespace qe
