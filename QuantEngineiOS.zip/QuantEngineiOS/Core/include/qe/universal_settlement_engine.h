#pragma once
// ─────────────────────────────────────────────────────────────────────────
// UniversalSettlementEngine — "Quant Engine, adjusted for all stocks."
// A genuinely separate, new engine (not a modification of
// SpySettlementEngine) that runs the exact same session-time momentum
// model, regression, Fibonacci, Black-Scholes hedge pressure, and
// Markov-state machinery, but parameterized by symbol instead of
// hardcoded to SPY.
//
// ── Why a new class instead of adding a symbol parameter to the old one ──
// SpySettlementEngine is depended on by name (its SPY-only behavior is
// documented and expected) by several tools built this session --
// Quant-Ai, 0DTE-Agent, SPY-Agent, the 0DTE Expected Value Engine. The
// person explicitly asked for a NEW engine, not a change to the
// existing one, so this is that: a separate class, separate instance,
// separate panel. SpySettlementEngine itself is untouched here (its own
// gamma-flip bug was already fixed directly in its own file, since
// that's a genuine correctness fix that should reach every consumer of
// the SPY-only engine too, not something withheld for the new one).
//
// ── What's actually generic vs. SPY-specific in the original ─────────
// The underlying model was already generic: it's built entirely from
// session-time intraday momentum structure (9:00/9:30/10:30/now,
// morning high/low), regression on those four points, Fibonacci
// retracement of the morning range, Black-Scholes greeks from a real
// options chain, and a Markov transition matrix over Up/Neutral/Down
// states. None of that depends on SPY's own price level or behavior --
// only two fetch calls were hardcoded to the string "SPY". This class
// is that same model with those two calls parameterized.
//
// ── What's genuinely NEW/different, not just copied ──────────────────
// The gamma-flip calculation here uses the same sign-change
// interpolation fix as dealer_positioning.cpp and the now-fixed
// spy_settlement_engine.cpp, applied from the start rather than
// inherited as a bug. Each instance keeps its own independent Markov
// engine and adaptive weight history, so a stock with different
// intraday behavior than SPY (e.g. higher volatility, different
// morning-momentum persistence) learns its OWN transition matrix over
// time via recordActual(), rather than sharing SPY's learned prior.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/spy_settlement_engine.h" // reuses SettlementForecast, MarkovEngine, MarkovState, AdaptiveLearningResult directly
#include "qe/http_client.h"
#include <string>
#include <vector>
#include <array>

namespace qe {

class UniversalSettlementEngine {
public:
    UniversalSettlementEngine();

    // symbol: any ticker with regular-session US equity/ETF hours
    // (9:30am-4:00pm ET) and a listed options chain. Index-only symbols
    // without options (e.g. raw indices rather than their ETF trackers)
    // will still get the momentum/regression/Fibonacci components, but
    // the Black-Scholes and dealer-gamma components fall back to
    // neutral defaults, same honest fallback behavior as the SPY-only
    // engine's own qeGammaSnapshot() when its options fetch fails.
    SettlementForecast computeForecast(HttpClient& http, const std::string& symbol);

    // Same real, code-driven learning loop as SpySettlementEngine's own
    // recordActual() -- scores the last forecast against a real
    // observed price, nudges this instance's own Markov matrix and
    // component weights. Call with the real price near this symbol's
    // own settlement/close.
    AdaptiveLearningResult recordActual(double actual_price);

    std::array<double, 6> weights() const { return weights_; }
    void setWeights(std::array<double, 6> w);
    const MarkovEngine& markov() const { return markov_; }

    const std::string& lastSymbol() const { return last_symbol_; }

private:
    MarkovEngine markov_;
    std::array<double, 6> weights_;
    std::string last_symbol_;

    struct HistoryEntry {
        MarkovState current_state, predicted_state;
        double price_current;
        std::array<double, 6> components;
    };
    std::vector<HistoryEntry> history_; // capped at 30, same convention as SpySettlementEngine
};

} // namespace qe
