#pragma once
// ─────────────────────────────────────────────────────────────────────────
// session_clock — minimal America/New_York session-time helper.
//
// We deliberately avoid pulling in a full IANA timezone database library
// (e.g. howardhinnant/date + tzdata) just for one offset, since this app
// only cares about the US equity/options session. ET is UTC-5 (EST) or
// UTC-4 (EDT) depending on US DST rules, which run from the second Sunday
// in March to the first Sunday in November. That rule is encoded directly
// below — it is correct for all years this app will realistically run in
// (the US DST rule has been stable since 2007) but will need updating if
// Congress changes DST rules again (there have been proposals to do so).
// ─────────────────────────────────────────────────────────────────────────
#include <ctime>
#include <algorithm>
#include <string>
#include <cstdio>

namespace qe {

// timegm() is a glibc/BSD extension, not part of the C/C++ standard and not
// available on Windows (MinGW/MSVC). MinGW's <time.h> ships _mkgmtime as the
// equivalent (interpret a struct tm as UTC and return the epoch time), so we
// route through that on Windows and use the native timegm() everywhere else.
inline std::time_t portable_timegm(std::tm* t) {
#if defined(_WIN32)
    return _mkgmtime(t);
#else
    return timegm(t);
#endif
}

inline bool isUsEasternDst(const std::tm& utc_tm) {
    // Second Sunday in March, 2:00 AM local -> compute its day-of-month.
    auto nthSunday = [&](int month, int n) {
        std::tm t{}; t.tm_year = utc_tm.tm_year; t.tm_mon = month - 1; t.tm_mday = 1;
        std::time_t tt = portable_timegm(&t);
        std::tm* first = gmtime(&tt);
        int wday = first->tm_wday; // 0=Sun
        int first_sunday = (wday == 0) ? 1 : (8 - wday);
        return first_sunday + 7 * (n - 1);
    };
    int mar_second_sunday = nthSunday(3, 2);
    int nov_first_sunday  = nthSunday(11, 1);

    int mon = utc_tm.tm_mon + 1, day = utc_tm.tm_mday;
    if (mon < 3 || mon > 11) return false;
    if (mon > 3 && mon < 11) return true;
    if (mon == 3) return day >= mar_second_sunday;
    return day < nov_first_sunday; // mon == 11
}

// Returns minutes remaining until 4:00 PM ET today, based on the current
// system time. If the market is already closed for the day (past 4:00 PM
// ET or before it opens), returns a small positive floor rather than a
// negative number, since callers (0DTE gamma calc) treat "very close to
// expiry" as the safe degenerate case, not "already expired."
inline double minutesToCloseET() {
    std::time_t now = std::time(nullptr);
    std::tm utc_tm{};
#if defined(_WIN32)
    gmtime_s(&utc_tm, &now);
#else
    gmtime_r(&now, &utc_tm);
#endif
    int offset_hours = isUsEasternDst(utc_tm) ? -4 : -5;

    std::time_t et_now = now + offset_hours * 3600;
    std::tm et_tm{};
#if defined(_WIN32)
    gmtime_s(&et_tm, &et_now);
#else
    gmtime_r(&et_now, &et_tm);
#endif

    std::tm close_tm = et_tm;
    close_tm.tm_hour = 16; close_tm.tm_min = 0; close_tm.tm_sec = 0;
    std::time_t close_et = portable_timegm(&close_tm);

    double minutes = std::difftime(close_et, et_now) / 60.0;
    return std::max(minutes, 5.0);
}

// Converts a UTC epoch second to the equivalent America/New_York wall-clock
// std::tm. This is the general building block etDateKeyFromEpoch and the
// SPY Settlement Engine's snapshot lookup are both built on.
inline std::tm toEasternTm(long long epoch_secs) {
    std::time_t t = (std::time_t)epoch_secs;
    std::tm utc_tm{};
#if defined(_WIN32)
    gmtime_s(&utc_tm, &t);
#else
    gmtime_r(&t, &utc_tm);
#endif
    int offset_hours = isUsEasternDst(utc_tm) ? -4 : -5;
    std::time_t et_t = t + offset_hours * 3600;
    std::tm et_tm{};
#if defined(_WIN32)
    gmtime_s(&et_tm, &et_t);
#else
    gmtime_r(&et_t, &et_tm);
#endif
    return et_tm;
}

// Inverse of toEasternTm: given a std::tm whose fields represent an
// America/New_York wall-clock time (e.g. "today at 9:30 AM ET"), returns
// the equivalent UTC epoch second. DST is determined from the tm's own
// date fields (isUsEasternDst only examines month/day), which is correct
// except in the ~1-hour window of the DST transition itself — an
// accepted edge case, same tradeoff the rest of this header makes.
inline long long etWallTimeToEpoch(std::tm et_wall_tm) {
    int offset_hours = isUsEasternDst(et_wall_tm) ? -4 : -5;
    std::time_t utc_equivalent = portable_timegm(&et_wall_tm) - offset_hours * 3600;
    return (long long)utc_equivalent;
}

// Returns "YYYY-MM-DD" for the given UTC epoch second, in America/New_York
// local time. Used to bucket intraday bars into trading days for VWAP's
// per-day reset — mirrors the Python version bucketing on
// `str(pandas_timestamp)[:10]`, where yfinance's DatetimeIndex is already
// tz-localized to the exchange timezone.
inline std::string etDateKeyFromEpoch(long long epoch_secs) {
    std::tm et_tm = toEasternTm(epoch_secs);
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d", et_tm.tm_year + 1900, et_tm.tm_mon + 1, et_tm.tm_mday);
    return std::string(buf);
}

} // namespace qe
