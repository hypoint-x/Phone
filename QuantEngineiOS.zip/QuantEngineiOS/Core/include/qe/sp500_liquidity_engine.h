#pragma once
// ─────────────────────────────────────────────────────────────────────────
// SP500 Liquidity Engine (SPLE) — USD funding, commodity liquidity, risk
// appetite, and a "dollar engine" composite blending DXY, FX crosses,
// rates, and cross-asset vol.
//
// THIS is the engine that had the major bug: the Python version's
// _sple_fetch() never relabeled columns from raw ticker ("DX-Y.NYB",
// "JPY=X", "EURUSD=X"...) to friendly label ("DXY", "USDJPY", "EURUSD"...),
// so almost every lookup silently failed and those inputs were dropped
// (only SHY/HYG, where label happens to equal ticker, ever matched). That
// bug is structurally impossible here because composite_engine's
// fetchLabeledSeries() always keys by friendly label — see its header
// comment.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/composite_engine.h"

namespace qe {

struct Sp500LiquidityResult {
    SubindexResult usd_funding;
    SubindexResult commodity_liquidity;
    SubindexResult risk_appetite;
    SubindexResult dollar_engine;
    double composite = 0.0;
    bool valid = false;
};

Sp500LiquidityResult computeSp500LiquidityEngine(HttpClient& http,
                                                  const std::string& period = "3mo",
                                                  const std::string& interval = "1d");

} // namespace qe
