#pragma once
// Minimal stand-in for the desktop app's MovingAveragesLadderAiEngine header: only the 8-bit codex state
// function the bullish indicator needs. Bit layout (MSB->LSB): Hard, Soft, Pullback, Support, VWAP, OBV, Keltner, StochRSI.
// Hard = macro EMAs FULLY aligned (hard_alignment == "FULL"). If the desktop engine defines Hard differently, change it here.
#include "qe/ma_ladder_engine.h"
#include <cstdint>
namespace qe {
inline uint8_t movingAveragesLadderAiState(const MaLadderConfluence& m) {
    return (uint8_t)((m.hard_alignment == "FULL" ? 0x80 : 0) | (m.soft_alignment ? 0x40 : 0) | (m.pullback_zone ? 0x20 : 0) |
                     (m.structural_support ? 0x10 : 0) | (m.vwap_floor ? 0x08 : 0) | (m.obv_confirm ? 0x04 : 0) |
                     (m.keltner_expansion ? 0x02 : 0) | (m.stochrsi_confirm ? 0x01 : 0));
}
}
