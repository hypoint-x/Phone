#pragma once
// ─────────────────────────────────────────────────────────────────────────
// GEX by Strike engine — per-strike call/put gamma exposure bars, ported
// from the Python version's /api/gamma_bars route.
//
// ── Formula fix, stated plainly ──────────────────────────────────────
// GEX is computed as gamma * OI * 100 * spot^2 * 0.01 -- the standard
// "dollar gamma exposure per 1% underlying move" formula. The *100 is
// the real options contract multiplier (each contract represents 100
// shares); this was MISSING from the original port, meaning every GEX
// value here understated the real dollar exposure by 100x. Found and
// fixed after being asked to make GEX accurate -- checked the
// formula's actual derivation from first principles (gamma = change in
// delta per $1 move; per contract, that's *100 shares; for a 1% move
// rather than $1, multiply by spot*0.01, then by spot again since
// gamma itself scales with the position, giving spot^2*0.01 overall)
// rather than just adjusting a constant until a number looked right.
// This same missing *100 was found in three other GEX-computing
// locations in this codebase (dealer_positioning.cpp,
// gamma_node_sequencer.cpp, zero_dte_engine.cpp) and fixed together, so
// GEX now means the same real dollar magnitude everywhere it's shown.
// A separate, differently-incomplete formula in intensity_cloud.h /
// option_surface.cpp (gamma*OI*100*spot, missing the quadratic spot
// term and 0.01 normalization) was also unified to this same formula.
//
// Distinct from dealer_positioning.h's computeGammaWalls() in two
// deliberate ways carried over from the original (not merged into one
// "canonical" implementation, since they're genuinely different views):
//   - Narrower strike window: spot * [0.92, 1.08] here vs. spot ± 150 in
//     compute_gamma_walls/build_surface/strike_heatmap. This route is
//     meant as a tight near-the-money GEX bar chart, not a wide ladder.
//   - call_wall/put_wall here = the strike with the single highest GEX
//     value (signed, gamma*OI*spot^2*0.01), NOT the highest |gamma|*OI
//     score used by computeGammaWalls. These can legitimately pick
//     different strikes. Both definitions are faithfully preserved
//     because this is what each original endpoint actually did.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <optional>
#include <string>

namespace qe {

struct GexByStrikeSide {
    std::vector<double> strikes;
    std::vector<double> gex; // gamma * weight(OI or volume) * spot^2 * 0.01, summed per strike
    std::vector<double> oi;  // summed open interest per strike (kept regardless of weighting, for display)
};

// Which real per-contract quantity weights the gamma exposure sum.
// OpenInterest is the standard convention (and what every existing
// caller of computeGexByStrike still gets by default) -- Volume is an
// additive alternative that reacts to TODAY's actual trading rather
// than accumulated positioning, since OI only updates once a day.
enum class GexWeighting { OpenInterest, Volume };

struct GexByStrikeResult {
    double spot = 0;
    std::optional<double> gamma_flip;
    std::optional<double> call_wall; // highest single-side GEX strike
    std::optional<double> put_wall;
    std::string edge = "SHORT GAMMA"; // "LONG GAMMA" | "SHORT GAMMA"
    GexByStrikeSide calls, puts;
    std::vector<double> net_gex_strikes;
    std::vector<double> net_gex_values; // calls.gex - puts.gex per strike
    bool valid = false;
};

// `rows` should already be DTE-filtered by the caller (mirrors the Python
// route taking load_options(ticker, dte)'s output directly).
GexByStrikeResult computeGexByStrike(const std::vector<OptionRow>& rows, double spot, GexWeighting weighting = GexWeighting::OpenInterest);

} // namespace qe
