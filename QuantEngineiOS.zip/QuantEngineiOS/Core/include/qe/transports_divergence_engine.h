#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Transports Divergence Engine — a NEW panel, not a port of anything in
// the Python original. Built entirely on top of ma_ladder_engine.h's
// existing per-symbol computation (EMA5/9/22/50/200 ladder across
// 5m/15m/1h, Hard/Soft Alignment, Pullback Zone, Structural Support,
// VWAP Floor, OBV Confirm, StochRSI Confirm, Keltner Expansion) — see
// that header for what each of those terms means exactly. This engine
// runs that computation independently for ^DJT (Dow Jones Transports)
// and CL=F (Crude Oil futures), then adds one more layer: deciding
// whether the two are behaving the way the fuel-cost relationship
// between them would predict, or whether the market looks mispriced.
//
// ── The core economic logic ────────────────────────────────────────────
// Fuel is a major direct cost for transportation companies. The
// textbook relationship is therefore INVERSE:
//   - Oil rising -> higher fuel costs -> pressure on Transports' margins
//     -> Transports should be flat/falling, not rising.
//   - Oil falling -> lower fuel costs -> relief for Transports' margins
//     -> Transports should be flat/rising, not falling.
// Using each instrument's own Macro Bias (BULL/BEAR/NEUTRAL, read off
// its EMA50/EMA200 stack on the chosen anchor timeframe — see
// ma_ladder_engine.h):
//   - Oil BULL + Transports BEAR, or Oil BEAR + Transports BULL:
//     NORMAL — the inverse relationship is holding. No mispricing to
//     bet against; relationship reading is FLAT.
//   - Oil BULL + Transports BULL (both rising together), or Oil BEAR +
//     Transports BEAR (both falling together): ANOMALOUS — the fuel-
//     cost relationship predicts the opposite of what Transports is
//     actually doing. This is the "market looks wrong" case: the bet is
//     that Transports corrects toward what the fuel-cost relationship
//     would predict.
//       Oil BULL + Transports BULL (anomalous) -> bet Transports
//       corrects DOWN to reflect the cost pressure -> SHORT ^DJT.
//       Oil BEAR + Transports BEAR (anomalous) -> bet Transports
//       corrects UP to reflect the cost relief -> LONG ^DJT.
//   - Either instrument NEUTRAL: no clear bias to compare, no signal.
//
// This is a real, testable rule, not a fitted model — no historical
// backtest backs the specific confidence weighting below; it's an
// explicit, inspectable formula (see computeTransportsDivergence's
// implementation) so it's easy to see exactly what's driving any given
// reading and adjust if the weighting doesn't match how you'd weigh it.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/ma_ladder_engine.h"
#include "qe/yahoo_endpoints.h"
#include <string>

namespace qe {

struct TransportsDivergenceResult {
    MaLadderConfluence djt; // ^DJT — full ladder/checklist, same fields ma_ladder_engine.h documents
    MaLadderConfluence oil; // CL=F — same

    std::string relationship = "NEUTRAL"; // "NORMAL (inverse)" | "ANOMALOUS (same-direction)" | "NEUTRAL"
    std::string trade_direction = "FLAT"; // "LONG DJT" | "SHORT DJT" | "FLAT"
    int confidence = 0;                   // 0-100, only meaningful when trade_direction != FLAT
    std::string reasoning;                // one-paragraph plain-English explanation of the reading above

    bool valid = false; // false only if BOTH ^DJT and CL=F failed to fetch
};

// `anchor_tf_idx` selects which timeframe each instrument's own Macro
// Bias/ladder score is built around — same meaning as
// computeMaLadderConfluence's own parameter (0=5m, 1=15m, 2=1h).
TransportsDivergenceResult computeTransportsDivergence(HttpClient& http, int anchor_tf_idx = 2);

} // namespace qe
