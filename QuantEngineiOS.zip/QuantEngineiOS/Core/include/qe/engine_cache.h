#pragma once
// ─────────────────────────────────────────────────────────────────────────
// EngineCache<T> — runs a (potentially slow, network-bound) fetch function
// on a background thread every `refresh_seconds`, and exposes a thread-safe
// snapshot for the UI thread to read every frame without blocking on I/O.
// Every engine panel in main.cpp uses one of these instead of calling the
// engine function directly in the render loop.
// ─────────────────────────────────────────────────────────────────────────
#include <thread>
#include <mutex>
#include <atomic>
#include <functional>
#include <chrono>
#include <optional>

namespace qe::ui {

template <typename T>
class EngineCache {
public:
    using FetchFn = std::function<T()>;

    EngineCache(FetchFn fn, int refresh_seconds)
        : fetch_(std::move(fn)), refresh_seconds_(refresh_seconds) {
        thread_ = std::thread([this] { loop(); });
    }
    ~EngineCache() {
        stop_ = true;
        if (thread_.joinable()) thread_.join();
    }
    EngineCache(const EngineCache&) = delete;
    EngineCache& operator=(const EngineCache&) = delete;

    // Returns the most recent successfully-fetched value, or nullopt if
    // the first fetch hasn't completed yet.
    std::optional<T> get() const {
        std::lock_guard<std::mutex> lock(mtx_);
        return value_;
    }

    bool isRefreshing() const { return refreshing_.load(); }
    std::chrono::steady_clock::time_point lastUpdated() const {
        std::lock_guard<std::mutex> lock(mtx_);
        return last_updated_;
    }

    // Forces an immediate refresh on the next background-loop tick,
    // bypassing the refresh_seconds wait — used by a manual "Refresh now"
    // button in the UI.
    void forceRefresh() { force_.store(true); }

private:
    void loop() {
        while (!stop_) {
            refreshing_.store(true);
            T result = fetch_(); // network I/O happens here, off the UI thread
            {
                std::lock_guard<std::mutex> lock(mtx_);
                value_ = std::move(result);
                last_updated_ = std::chrono::steady_clock::now();
            }
            refreshing_.store(false);

            for (int i = 0; i < refresh_seconds_ * 10 && !stop_ && !force_.load(); ++i)
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            force_.store(false);
        }
    }

    FetchFn fetch_;
    int refresh_seconds_;
    std::thread thread_;
    mutable std::mutex mtx_;
    std::optional<T> value_;
    std::chrono::steady_clock::time_point last_updated_{};
    std::atomic<bool> stop_{false};
    std::atomic<bool> refreshing_{false};
    std::atomic<bool> force_{false};
};

} // namespace qe::ui
