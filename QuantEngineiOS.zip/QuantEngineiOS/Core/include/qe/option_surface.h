#pragma once
// ─────────────────────────────────────────────────────────────────────────
// option_surface — 3D surface (metric vs. strike vs. DTE) + marker points
// for the highest-volume/highest-OI call and put, ported from the Python
// version's build_surface() / api_surface() route.
//
// Faithful port, including the original's specific (slightly unusual)
// choices, called out here rather than "fixed" silently since they were
// deliberate stylistic decisions, not bugs:
//   - The resampled 60x60 grid uses nearest-neighbor lookup (not
//     interpolation) before smoothing — PlotSurface will show visible
//     "steps" between source strikes/DTEs rather than smooth ramps until
//     the box-blur pass softens them.
//   - The box blur (3 passes of a 5-point kernel, reduced from an
//     original 15 -- see .cpp for why) uses wraparound (equivalent to
//     np.roll) at the grid edges, meaning the leftmost/rightmost strike
//     columns and top/bottom DTE rows blend slightly with the opposite
//     edge. This is a real artifact in the original (edge-wrap bleed on
//     a non-periodic surface), reproduced here for fidelity rather than
//     silently "fixed", since correcting it would change the visual
//     smoothing result the Python version's users are used to seeing.
//     Flagged in case you'd like it changed to clamp-at-edge instead.
//
// FIXED (was SPY-only in practice): the strike window used to be a fixed
// spot ± 150 *points*, which only makes sense for an underlying priced
// roughly like SPY/SPX. For a $30 stock that swallowed almost the whole
// chain (mostly irrelevant deep-OTM strikes diluting the near-the-money
// region); for anything trading well into four figures it could be too
// narrow. It's now spot ± max(20, spot * 0.4) — a window that scales
// with the underlying instead of being sized for one specific ticker.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <optional>
#include <string>
#include <algorithm>

namespace qe {

enum class SurfaceMetric { Volume, OpenInterest, Notional, Gamma, Gex };

inline const char* surfaceMetricField(SurfaceMetric m) {
    switch (m) {
        case SurfaceMetric::Volume: return "volume";
        case SurfaceMetric::OpenInterest: return "openInterest";
        case SurfaceMetric::Notional: return "notional";
        case SurfaceMetric::Gamma: return "gamma";
        case SurfaceMetric::Gex: return "gex";
    }
    return "volume";
}

// spot ± strikeWindow(spot) — scales with the underlying's price instead
// of assuming an SPY-sized instrument. See header note above.
inline double surfaceStrikeWindow(double spot) {
    return std::max(20.0, spot * 0.4);
}

struct SurfaceGrid {
    std::vector<double> x_strikes;   // length = res (default 60)
    std::vector<double> y_dte;       // length = res
    std::vector<double> z;           // flattened, row-major: z[iy*res + ix]
    int res = 0;
    bool valid = false;
};

struct SurfaceMarker {
    double x = 0, y = 0, z = 0;
    int strike = 0;
    double volume = 0, open_interest = 0;
    bool valid = false;
};

struct SurfaceMarkers {
    SurfaceMarker max_call, oi_call, max_put, oi_put;
};

// Builds the resampled+smoothed surface grid for `metric`, restricted to
// strikes within spot ± surfaceStrikeWindow(spot). Returns !valid if the
// chain is empty or has no DTE variation to grid over.
SurfaceGrid buildOptionSurface(const std::vector<OptionRow>& rows, double spot,
                                SurfaceMetric metric, int res = 60);

// Exact (non-interpolated) aggregated metric value at a given strike/DTE —
// used for marker placement, mirrors exact_metric_z() in the Python
// version so markers sit at their true data value, not a smoothed
// surface estimate. `spot` is only used by the Gex metric's formula.
double exactMetricAt(const std::vector<OptionRow>& rows, double strike, int dte,
                      SurfaceMetric metric, double spot = 0.0);

// Finds the four highlight points (highest-volume call/put, highest-OI
// call/put) within the same spot ± surfaceStrikeWindow(spot) window used
// for the surface itself.
SurfaceMarkers findSurfaceMarkers(const std::vector<OptionRow>& rows, double spot,
                                    SurfaceMetric metric);

} // namespace qe
