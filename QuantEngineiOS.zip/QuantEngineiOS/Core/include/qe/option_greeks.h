#pragma once
// ─────────────────────────────────────────────────────────────────────────
// option_greeks — populates the `gamma` field on OptionRow entries fetched
// from Yahoo (which does not provide gamma directly, unlike some paid
// data vendors). Mirrors load_options() in the Python version, including
// both of its fixes: the real risk-free rate and session-aware T for
// 0DTE contracts.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"

namespace qe {

// Mutates `chain.rows` in place, setting `.gamma` on every row via
// Black-Scholes using the real risk-free rate (fetched fresh/cached
// via fetchRiskFreeRate) and session-aware time-to-expiry.
void populateOptionGammas(HttpClient& http, OptionChain& chain);

} // namespace qe
