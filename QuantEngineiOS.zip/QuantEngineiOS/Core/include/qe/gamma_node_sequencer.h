#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Gamma Node Sequencer — "WAIT, WAIT, ENTER" multi-DTE dealer gamma node
// sequencing engine, built from the user-supplied strategy spec (v2.0).
//
// The spec describes a STRIKE × DTE gamma surface: each cell is a
// (strike, expiration) concentration of dealer gamma exposure, classified
// as a +NODE (absorptive — dealers dampen price near it) or -NODE
// (amplifying — dealers accelerate price through it). The engine walks
// price through that surface in the current direction of travel and
// looks for a three-node sequence (WAIT / WAIT / ENTER) with a defined
// invalidation level before ever signaling ENTER.
//
// DESIGN NOTES / faithful-port decisions where the spec left things
// "configurable" or offered multiple options without picking one:
//
//   - GEX per cell uses the SAME convention as gex_by_strike.h and
//     dealer_positioning.h (gamma * OI * spot^2 * 0.01, net = call - put),
//     not intensity_cloud.h's differently-scaled "gex" metric — this one
//     needs a signed dollar figure whose sign is directly interpretable
//     as the dealer's absorptive/amplifying regime (§5/§6 of the spec),
//     which is exactly what that convention already means elsewhere in
//     this codebase.
//   - §13's NodeScore formula is implemented using the spec's own
//     concrete numeric example (0.30/0.20/0.15/0.10/0.15/0.10 — GEX, DTE,
//     OI, Volume, Persistence, Proximity) since that's the only place the
//     spec commits to actual numbers; CrossDTEConsistency (mentioned in
//     §13's bullet list but absent from its own worked example) is kept
//     as a separate boolean flag (cross_dte_confirmed) rather than folded
//     into the composite, matching what the example itself does.
//   - §15/16 KING: "Possible criteria" lists five candidate rankings; this
//     implementation ranks by NodeScore (already a composite of the other
//     four), and separately aggregates by strike/DTE for KING STRIKE /
//     KING DTE per §16's explicit request that those be distinguishable
//     from the single KING NODE cell.
//   - §20/21 node failure is a snapshot check (has price already closed
//     beyond this node with N-bar acceptance, evaluated against the
//     candle history passed in) — not the more sophisticated
//     volume/order-flow-confirmed variant §20 offers as an alternative,
//     since order-flow data isn't part of this codebase's data model.
//   - §29-30's post-ENTER trade lifecycle (ENTERED → MANAGE_TRADE →
//     EXITED) needs state that persists across polls/frames, which this
//     engine — recomputed fresh from the latest chain snapshot every
//     call, like every other engine in this codebase — deliberately does
//     not carry. It reports the state machine up through RISK_VALIDATION
//     / the ENTER signal only (§27's literal "SIGNAL = ENTER" rule); an
//     actual position, once entered, is a job for auto_trade_engine.h's
//     existing stateful tracking, not this one.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <string>
#include <optional>

namespace qe {

enum class NodeType { None, Plus, Minus };
enum class SequenceType { None, Vertical, Horizontal, Diagonal, Mixed };
enum class TravelDirection { Flat, Up, Down };

// §30 state machine. Collapses ENTERED/MANAGE_TRADE/EXITED into Entered
// — see the class comment above for why post-entry lifecycle isn't
// tracked here.
enum class EntryState {
    NoSetup, FirstNodeTested, FirstNodeFailed, SecondNodeTested,
    SecondNodeFailed, EntryNodeReached, RiskValidation, Entered
};

// §31 GammaCell — one (strike, DTE) surface cell.
struct GammaCell {
    double strike = 0;
    int dte = 0;
    std::string expiration;
    int dte_column = -1; // index into GammaSurface::dte_columns, 0 = nearest

    double call_gex = 0, put_gex = 0, net_gex = 0; // gamma*OI*spot^2*0.01, signed
    double call_oi = 0, put_oi = 0, total_oi = 0;
    double call_volume = 0, put_volume = 0, total_volume = 0;

    NodeType node_type = NodeType::None;
    double node_score = 0.0;          // §13 composite, 0..1
    double persistence_score = 0.0;   // §11, 0..1 (fraction of DTE columns this strike qualifies in)
    bool cross_dte_confirmed = false; // §14
    bool is_king = false;             // §15 KING NODE
};

// §13 weights + §12/20/29 thresholds. All configurable per the spec's
// repeated "must be configurable" instruction.
struct NodeSequenceConfig {
    enum class DteWeightMode { InverseSqrt, ExponentialDecay };
    DteWeightMode dte_weight_mode = DteWeightMode::InverseSqrt;
    double decay_rate = 0.15; // only used when dte_weight_mode == ExponentialDecay

    // §13 composite weights (spec's own worked example; sums to 1.0)
    double w_gex = 0.30, w_dte = 0.20, w_oi = 0.15, w_volume = 0.10,
           w_persistence = 0.15, w_proximity = 0.10;

    double node_score_min = 0.35;      // §4: floor for "meaningful" concentration
    double proximity_band_pct = 0.10;  // spot ± 10% strike window considered at all
    double cross_dte_persistence_min = 0.5; // §14: >=half of DTE columns to count as "confirmed"

    // §20/21 node failure: close must clear the node by this fraction of
    // spot, for this many consecutive closes, to count as "accepted".
    double failure_close_beyond_pct = 0.0015;
    int failure_acceptance_bars = 2;

    // §28/29 risk
    double min_risk_reward = 2.0;
    double invalidation_atr_mult = 1.0;
};

// §25/26 the recorded WAIT/WAIT/ENTER path through the surface.
struct NodeSequence {
    GammaCell first_node, second_node, entry_node;
    bool has_first = false, has_second = false, has_entry = false;
    SequenceType sequence_type = SequenceType::None;
    EntryState state = EntryState::NoSetup;
    TravelDirection direction = TravelDirection::Flat;

    double entry_price = 0.0, invalidation_price = 0.0, target_price = 0.0;
    double risk_reward = 0.0;
    double confidence = 0.0; // mean NodeScore of the 3 nodes in the path
};

struct GammaSurface {
    double spot = 0;
    std::vector<int> dte_columns;  // distinct DTE values present, ascending (0 = nearest)
    std::vector<GammaCell> cells;  // full strike x DTE grid within the proximity band

    std::optional<GammaCell> king;       // §15/16 KING NODE (single best cell)
    std::optional<double> king_strike;   // §16 KING STRIKE (best strike, summed across its DTE columns)
    std::optional<int> king_dte_column;  // §16 KING DTE (best DTE column, summed across its strikes)

    NodeSequence active_sequence; // §17-19 current WAIT/WAIT/ENTER candidate, if any
    bool valid = false;

    const GammaCell* getNode(double strike, int dte_column) const;
    std::vector<const GammaCell*> getCrossDteNodes(double strike) const;
    std::vector<const GammaCell*> getPersistentNodes(double min_persistence = 0.5) const;
};

// `rows` = the FULL multi-expiration chain, not pre-filtered to a single
// DTE (that's the entire point of this engine — the caller should still
// apply whatever outer DTE cutoff/window it wants beforehand, same as
// every other engine here, but must not collapse to one expiration).
//
// `recent_closes` should be ascending by time (oldest first, most recent
// last) — used for direction-of-travel (§18/19) and node failure
// (§20-22). `atr` is a simple average-true-range figure in price units,
// used for the invalidation distance (§28); pass 0 to fall back to
// 0.5% of spot.
GammaSurface computeGammaSurface(const std::vector<OptionRow>& rows, double spot,
                                  const std::vector<double>& recent_closes,
                                  double atr, const NodeSequenceConfig& cfg = {});

const char* nodeTypeLabel(NodeType t);
const char* sequenceTypeLabel(SequenceType t);
const char* entryStateLabel(EntryState s);

} // namespace qe
