#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Quant Engine (SPY 3:30) — end-of-day gamma snapshot + breakout
// probability vs. anchored VWAP.
//
// Ported with two fixes carried over from the Python version:
//   1. Breakout probability: previously used abs(spot - vwap), so prob_up
//      could never fall below 0.5 regardless of which side of VWAP price
//      was on — "BEARISH BIAS" could never fire. Now uses signed distance
//      run through a normal-CDF z-score off the VWAP band's own std dev.
//   2. "VWAP" here is a REAL price-based anchored VWAP (typical price
//      weighted by bar volume) — the Python version's main dashboard had
//      briefly computed this from the options chain's strike/volume
//      instead of price/volume, which is a different metric entirely.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include "qe/dealer_positioning.h"
#include <optional>

namespace qe {

struct AnchoredVwap {
    double vwap = 0.0;
    double std = 0.0;
    double upper_1 = 0, lower_1 = 0, upper_2 = 0, lower_2 = 0;
    bool valid = false;
};

// Computes a session-anchored VWAP from intraday OHLCV bars (typical
// price = (H+L+C)/3, weighted by bar volume) — NOT from the options
// chain, which is the bug this replaces.
AnchoredVwap computeSessionVwap(const OhlcvSeries& intraday);

struct BreakoutProbability {
    double prob_up = 0.5, prob_down = 0.5;
    std::string signal = "NO DATA"; // "BULLISH BIAS" | "BEARISH BIAS" | "NEUTRAL"
};

BreakoutProbability computeBreakoutProbability(double spot, const AnchoredVwap& vwap);

struct QuantEngineSnapshot {
    double spot = 0;
    double dealer_gamma_exposure = 0;
    std::optional<double> gamma_flip;
    double implied_volatility = 0.0;
    int days_to_expiration = 0;
    AnchoredVwap vwap;
    BreakoutProbability breakout;
    bool valid = false;
};

// The full SPY 3:30 snapshot: fetches the 0DTE-priority option chain,
// computes dealer GEX/gamma-flip, fetches recent intraday bars for VWAP,
// and combines into the breakout read.
QuantEngineSnapshot computeQuantEngineSnapshot(HttpClient& http,
                                                const std::string& symbol = "SPY");

} // namespace qe
