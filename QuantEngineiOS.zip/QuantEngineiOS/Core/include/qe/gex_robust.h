#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Robust (spoof-resistant) GEX.
//
// What this can and cannot do: Yahoo's chain has last price, volume, open
// interest and IV per contract. It has NO order book and NO quote history,
// so resting orders that are placed and cancelled (spoofing / flickering
// quotes) never reach this data directly, and they cannot be identified
// from it. What CAN distort a GEX / gamma-flip number from this data is:
//   * strikes with open interest but no trading and no price (stale / dead),
//   * a few outsized strikes that dominate the sum,
//   * junk IV, and
//   * a flip read from a single per-strike sign change that jumps when one
//     strike moves.
// The robust mode addresses those, and reports how stable the flip is so a
// fragile number is visible as fragile.
//
// Method
//   1. Drop contracts with no price discovery (volume 0 and last price 0),
//      with junk IV, or outside +-12% of spot.
//   2. Confirm open interest with trading: weight = OI * conf, where
//      conf = 0.35 + 0.65 * min(1, volume / (0.10 * OI)).
//   3. Winsorize weights at the 97.5th percentile.
//   4. Flip = zero crossing nearest spot of TOTAL dealer gamma recomputed
//      over a spot sweep (+-10%), not a single per-strike sign change.
//   5. Stability: re-solve the flip under 40 random 25% weight perturbations
//      and report the 10th-90th percentile band.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <optional>
#include <vector>

namespace qe {

struct GexRobustResult {
    bool valid = false;
    double spot = 0;
    std::optional<double> flip;          // sweep zero-crossing nearest spot
    std::optional<double> flip_lo, flip_hi;   // 10th / 90th percentile under perturbation
    std::optional<double> flip_strike;   // smoothed per-strike crossing (for comparison)
    std::optional<double> call_wall, put_wall;
    std::vector<double> strikes, net, call_gex, put_gex;     // robust per-strike (weighted, nearest-expiry-agnostic)
    std::vector<double> sweep_spot, sweep_total;             // total dealer gamma profile
    int rows_in = 0, rows_used = 0, dropped_stale = 0, dropped_iv = 0, clipped = 0;
    double mean_conf = 0;
    double stability = 0;                // 1 - (flip_hi-flip_lo)/spot*100 clipped to [0,1]-ish helper (0 = fragile, 1 = firm)
};

GexRobustResult computeGexRobust(const std::vector<OptionRow>& rows, double spot, double risk_free);

} // namespace qe
