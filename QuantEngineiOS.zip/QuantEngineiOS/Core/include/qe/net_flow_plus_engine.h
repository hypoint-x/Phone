#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Net Flow+ engine — feeds the 3D spectral-analyzer-style flow visualizer.
//
// TRANSPARENCY NOTE (read before assuming this is a real trade tape):
// this app's only data source is Yahoo's option-chain snapshot endpoint,
// which reports *cumulative session volume* and open interest per
// contract, not individual trade prints. There is no real timestamp,
// aggressor side, sweep flag, or block flag anywhere in that feed.
//
// Net Flow+ turns each *increase* in a contract's volume between two
// consecutive snapshots into one synthetic "trade" event (FlowEvent) —
// exactly the same volume-delta inference NetFlowTracker (net_flow_engine.h)
// already makes for the 1D FLOW chart, just emitted as discrete particles
// instead of an aggregated running total. `FlowClass` (aggressive/sweep/
// block/extreme) is a heuristic read over that same delta data (relative
// size vs. this batch, vs. open interest, and vs. this session's running
// premium distribution) — it is a flow-magnitude/pattern proxy, not a
// verified market event. Label it as such anywhere it's shown to a user.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <deque>
#include <string>
#include <unordered_map>
#include <cstdint>

namespace qe {

enum class FlowClass {
    Neutral,
    AggressiveCall,
    AggressivePut,
    Sweep,
    Block,
    Extreme, // >99th percentile premium this session — overrides other classes for color
};

struct FlowEvent {
    uint64_t id = 0;
    std::string symbol;
    double timestamp = 0;        // glfwGetTime() seconds when synthesized (not wall-clock trade time)
    double strike = 0;
    std::string expiration;      // "YYYY-MM-DD"
    int dte = 0;
    bool is_call = true;
    double volume_delta = 0;     // contracts added since last snapshot ("size" of this synthetic trade)
    double open_interest = 0;
    double last_price = 0;
    double net_premium = 0;      // volume_delta * last_price * 100 (unsigned magnitude)
    double gamma = 0;
    double vega = 0;
    double iv = 0;
    FlowClass cls = FlowClass::Neutral;
};

class NetFlowPlusTracker {
public:
    // Feed the latest chain snapshot. Returns the synthetic events created
    // by *this* call (empty most frames — only non-empty right after the
    // underlying EngineCache actually produced a new snapshot with volume
    // deltas). Also appends them to the rolling `history()`.
    const std::vector<FlowEvent>& update(const OptionChain& chain, double now_seconds);

    const std::deque<FlowEvent>& history() const { return history_; }

    // 99th-percentile premium across the current history, used for the
    // "Extreme" (white) classification threshold and for callers that
    // want to show it in the UI.
    double premium_p99() const { return premium_p99_; }

    void reset();

private:
    struct LastSeen { double volume = 0; double open_interest = 0; };
    std::unordered_map<std::string, LastSeen> last_seen_;
    std::deque<FlowEvent> history_;
    std::vector<FlowEvent> last_new_;
    std::vector<double> premium_samples_; // bounded, used for the running p99
    double premium_p99_ = 0;
    uint64_t next_id_ = 1;
    bool have_baseline_ = false; // first snapshot only establishes baselines, emits nothing

    static constexpr size_t kMaxHistory = 6000;
    static constexpr size_t kMaxPremiumSamples = 3000;
};

} // namespace qe
