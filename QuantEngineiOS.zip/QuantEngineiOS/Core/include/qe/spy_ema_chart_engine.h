#pragma once
// ─────────────────────────────────────────────────────────────────────────
// SPY EMA Chart Engine — the full multi-indicator ticker chart (candles +
// session VWAP + EMA9/20/50 + Bollinger Bands(20,2) + RSI(14) + session
// high/low), ported from the Python version's /api/ticker_chart route.
//
// Two EMA implementations exist side-by-side in the Python original, and
// this port keeps them distinct rather than merging them into "one true
// EMA function":
//   - THIS engine's EMA9/20/50 use a plain recursive EMA seeded by the
//     first price (pandas adjust=False-equivalent) — matches the Python
//     route's own hand-rolled `ema()` helper exactly.
//   - mtf_engine.h's EMA50 uses pandas' `.ewm(span=X).mean()` default
//     (adjust=True), which is NOT numerically identical on short series —
//     see stats.h::ewmMeanLastAdjustTrue for why that distinction is kept.
//
// VWAP here resets per calendar day for intraday intervals and is
// cumulative-from-start for daily bars — same as the Python version.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <string>

namespace qe {

struct SpyEmaChart {
    // Unix epoch seconds per bar, same length/order as closes/opens/etc.
    // below — lets the UI plot on a real (time, price) axis and label the
    // bottom axis with actual market time instead of a bare bar index.
    std::vector<long long> timestamps;
    std::string interval; // echoes back whichever interval was requested
                           // ("5m"/"15m"/"60m"/...), so the UI can confirm
                           // what timeframe it's actually looking at.
    std::vector<double> closes, opens, highs, lows, volumes;
    std::vector<double> vwap;
    std::vector<double> ema9, ema20, ema50;
    std::vector<double> bb_upper, bb_mid, bb_lower;
    std::vector<double> rsi;
    double session_high = 0, session_low = 0;
    double last = 0, open = 0, change = 0, pct = 0;

    // Heikin-Ashi OHLC, derived from the same underlying bars above
    // (standard formula: ha_close = avg(O,H,L,C); ha_open = avg of prior
    // bar's ha_open/ha_close, seeded by avg(open[0],close[0]); ha_high/low
    // = max/min of the real high/low and the two ha_open/ha_close values).
    // These smooth noise for a cleaner trend read but are NOT what
    // VWAP/EMA/BB/RSI above are computed from — those all still use real
    // price, matching how every real charting platform layers HA candles
    // on top of price-based indicators rather than re-deriving them.
    std::vector<double> ha_open, ha_high, ha_low, ha_close;

    // Keltner Channel(20, 2.0): basis = EMA20 of close (same series as
    // ema20 above), bands = basis +/- 2.0 * ATR(20) (Wilder ATR, see
    // stats.h::wilderAtr). No Python original to port — this is a new
    // addition, using the standard/default Keltner parameterization.
    std::vector<double> keltner_upper, keltner_lower, keltner_width;
    // True when the latest band width is >10% wider than it was 10 bars
    // ago — a simple, self-referential "volatility expanding out of a
    // squeeze" flag. This is a plain heuristic (not a formal named
    // indicator/port); it only looks at this chart's own band-width
    // history, not any cross-timeframe squeeze definition.
    bool keltner_expanding = false;

    // ── Everything below is new: no Python original to port from —
    // added for deeper trend/entry-timing analysis on top of the
    // existing indicator set above. ──

    // MACD(12,26,9): standard EMA12-EMA26 line, EMA9-of-that as signal,
    // line-minus-signal as histogram. Same recursiveEma() form as
    // EMA9/20/50 above (not pandas adjust=True) for internal consistency
    // with the rest of this engine.
    std::vector<double> macd_line, macd_signal, macd_hist;

    // Wilder ADX(14) + DI+/DI- (stats.h::wilderAdx) — trend *strength*
    // (ADX) independent of direction, plus which direction (DI+ > DI- =
    // bullish) is currently dominant. The single biggest input to "is
    // this actually trending, or should I not bother trying to trade a
    // trend right now."
    std::vector<double> adx, di_plus, di_minus;

    // On-Balance Volume (stats.h::onBalanceVolume) plus a simple
    // divergence flag: price's own recent trend slope vs OBV's recent
    // trend slope (both via linregChannel over the same trailing
    // window) pointing opposite ways — a classic early warning that the
    // move isn't backed by real participation.
    std::vector<double> obv;
    bool obv_bullish_divergence = false; // price falling, OBV rising
    bool obv_bearish_divergence = false; // price rising, OBV falling

    // ATR(14) plus where the *current* reading sits in its own trailing
    // distribution (0-100 percentile) — "is this a high- or low-
    // volatility environment right now", which is what any ATR-based
    // stop/target distance below should actually be scaled against.
    std::vector<double> atr14;
    double atr_percentile = 50.0;

    // Linear regression trend channel (stats.h::linregChannel) fit over
    // the trailing `reg_window` bars only (a recent-trend read, not the
    // whole possibly-180-bar series) — slope's sign is the trend
    // direction, r2 is how clean that trend has been, and mid/upper/
    // lower give an objective "is price stretched from its own trend
    // line" band. mid/upper/lower are only populated for the last
    // `reg_window` bars (indices [n - reg_window, n)); the UI positions
    // them using that same trailing slice of `timestamps`.
    int reg_window = 0;
    double reg_slope = 0.0, reg_r2 = 0.0;
    std::vector<double> reg_mid, reg_upper, reg_lower;

    // Classic (Floor Trader) pivot points from the prior completed
    // session's H/L/C — PP, R1/R2 (resistance), S1/S2 (support). Not
    // meaningful for a series with no identifiable prior session (e.g.
    // too short a daily history), hence `pivot_valid`.
    bool pivot_valid = false;
    double pivot_pp = 0, pivot_r1 = 0, pivot_r2 = 0, pivot_s1 = 0, pivot_s2 = 0;

    // Fractal-based support/resistance: 5-bar swing highs/lows (this
    // bar's high/low is the max/min of the 2 bars on each side) detected
    // over the full window, then clustered by proximity (within ~0.15%
    // of price) so repeated touches near the same level count as one
    // level with a touch count instead of many separate near-duplicate
    // lines. Sorted by touch count descending, capped to the strongest
    // handful.
    struct SrLevel { double price; int touches; bool is_resistance; };
    std::vector<SrLevel> sr_levels;

    // Volume profile over the full visible window: Point of Control
    // (price bin with the most volume) and the Value Area (narrowest
    // price band containing ~70% of total volume, expanded outward from
    // the POC bin) — classic "where did most of the trading actually
    // happen" read, independent of where price is *now*.
    bool volume_profile_valid = false;
    double vp_poc = 0, vp_vah = 0, vp_val = 0;
    // Parallel arrays for optionally drawing the profile itself: price
    // at the center of each bin, and that bin's share of total volume
    // (0-1) — a horizontal histogram, read bin-by-bin alongside price.
    std::vector<double> vp_bin_price, vp_bin_volume_frac;

    // Auto Fibonacci retracement, drawn from the most recent significant
    // swing (highest high / lowest low over a trailing lookback window,
    // direction inferred from which one printed more recently: high
    // after low => uptrend, retracement measured down from the high;
    // low after high => downtrend, retracement measured up from the
    // low). Standard ratios only (0/23.6/38.2/50/61.8/78.6/100) — no
    // Python original to port, new for this Chart+ pass.
    bool fib_valid = false;
    double fib_swing_high = 0, fib_swing_low = 0;
    bool fib_uptrend = true; // true: high came after low (retrace down from high)
    struct FibLevel { double ratio; double price; std::string label; };
    std::vector<FibLevel> fib_levels;

    // A handful of classic single/two-candle patterns detected on the
    // most recent bars (real OHLC, not Heikin-Ashi) — potential entry-
    // trigger candles, not a full pattern-recognition library.
    struct CandlePattern { size_t index; std::string name; bool bullish; };
    std::vector<CandlePattern> patterns;

    // Composite "setup" read: blends EMA9/20/50 stacking, ADX/DI
    // direction+strength, RSI positioning, MACD histogram, and price vs
    // VWAP into one signed score in [-100, 100] (positive = bullish
    // setup, negative = bearish), plus a plain-language label/reasons
    // list so the number is never presented without its "why".
    double setup_score = 0.0;
    std::string setup_label; // e.g. "STRONG BULLISH SETUP"
    std::vector<std::string> setup_reasons;

    // Entry/stop/target plan, direction taken from setup_score's sign
    // (flat inside a neutral band => no plan). Upgraded from a plain
    // "enter at market, stop = 1.5*ATR" mechanical read into a
    // confluence-based, timeframe-aware plan:
    //   - Entry price is the nearest *cluster* of confirming levels
    //     (VWAP, EMA9/20/50, Keltner/BB bands, pivots, fractal S/R,
    //     volume-profile POC/VAH/VAL) rather than always "chase at
    //     market" — if several independent tools already agree on a
    //     price near where price actually is, that's the entry; if the
    //     nearest strong confluence zone is a pullback away, the plan
    //     says wait for it instead of chasing.
    //   - Stop distance is bounded by ATR multiples that widen from
    //     scalp (5m) to swing (1h) `style`, but is anchored to the
    //     confluence zone's outer edge, not a flat multiple alone.
    //   - Targets prefer the nearest real structure (opposing S/R,
    //     pivot, POC/VAH/VAL) beyond the entry in the trade's
    //     direction, falling back to a plain R-multiple only when no
    //     structure exists in range.
    // Still a mechanical read of the data above — not personalized
    // advice, doesn't know account size or risk tolerance.
    struct TradePlan {
        bool valid = false;
        std::string direction; // "LONG" | "SHORT" | "NONE"
        double entry = 0, stop = 0, target_1r = 0, target_2r = 0, risk_per_share = 0;

        // Trading style this timeframe is being framed as, driving the
        // stop/target ATR multiples used above — "SCALP" (1m/5m),
        // "INTRADAY" (15m), or "SWING" (1h/1d).
        std::string style;

        // "MARKET" — price is already at/inside the confluence zone, or
        // no usable structure was found so this falls back to the old
        // chase-at-last behavior; "LIMIT" — plan is to wait for a
        // pullback/rally into the named zone before entering.
        std::string entry_type;

        // How many independent tools agree on the entry zone, weighted
        // by how reliable each tends to be (VWAP/POC/pivots weigh more
        // than a single Bollinger touch) — "A+ HIGH CONFLUENCE" (many
        // strong factors stacked at one price), "B MODERATE", or
        // "C LOW / single factor" (only the ATR fallback fired).
        std::string entry_quality;

        // Which named tools (e.g. "VWAP", "EMA20", "Pivot S1",
        // "Fractal support (3x touch)", "Volume POC") actually cluster
        // at the chosen entry price — the human-readable "why here".
        std::vector<std::string> confluence_factors;

        // Whether each target came from real structure (next S/R,
        // pivot, or volume-profile level in the trade's direction) or
        // is a plain R-multiple fallback because nothing was in range —
        // shown in the UI so a structural target isn't mistaken for an
        // arbitrary round number, or vice versa.
        bool target_1r_structural = false, target_2r_structural = false;

        // Realized reward:risk for each target given the actual
        // entry/stop distance above — only exactly 1.0/2.0 when a
        // target fell back to the plain R-multiple; a structural target
        // can land at any ratio (e.g. 1.4R if the nearest resistance is
        // a bit closer than a clean 1R would have been).
        double reward_risk_1r = 0.0, reward_risk_2r = 0.0;

        // Plain-language condition under which this plan should be
        // considered wrong, independent of just hitting the stop price
        // (e.g. the EMA stack flipping against the trade) — a second,
        // structural way to know the read has changed even if price
        // hasn't reached the stop yet.
        std::string invalidation;
    };
    TradePlan trade_plan;

    bool valid = false;
};

// `interval` should be one of "1m","5m","15m","1h","1d" (matches the
// Python route's is_intraday check, which drives the VWAP reset behavior
// and the day-change basis for `change`/`pct`).
SpyEmaChart computeSpyEmaChart(HttpClient& http, const std::string& symbol,
                                const std::string& period, const std::string& interval);

// Same computation, factored out with the network fetch already done —
// computeSpyEmaChart() above is now a thin wrapper around this. Exposed
// so tooling/tests can feed synthetic OhlcvSeries data straight in
// without a live HttpClient/network round-trip.
SpyEmaChart computeSpyEmaChartFromSeries(OhlcvSeries s, const std::string& interval);

} // namespace qe
