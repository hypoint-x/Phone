#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Moving Average Ladder Engine — a NEW panel, not a port of anything in
// the Python original (there's no equivalent route/function there). This
// is a fresh synthesis built on top of indicators already available
// elsewhere in this codebase (recursive EMA, Wilder RSI/StochRSI, OBV,
// session VWAP + Keltner Channel from spy_ema_chart_engine.h), assembled
// per an explicit spec: a 5/9/22/50/200 EMA ladder read across 5m/15m/1h,
// rolled up into a fixed checklist of YES/NO confirmations plus one
// confidence number.
//
// Several of the requested terms don't have one universal industry
// definition (esp. "Hard Alignment", "Pullback Zone", "Structural
// Support") — this header spells out exactly which definition was picked
// for each, so mismatches against what you had in mind are easy to spot
// and adjust.
//
// ── Field definitions ──────────────────────────────────────────────────
//
// Per timeframe (5m, 15m, 1h), the ladder is EMA5/9/22/50/200 computed
// with the same plain recursive EMA (seeded by the first close) that
// spy_ema_chart_engine.h uses for its own EMA9/20/50 — see stats.h's
// recursiveEma() for why that form (not mtf_engine's adjust=True EMA) is
// used here, so these numbers match what you'd see adding the same
// periods to that chart.
//
//   MACRO BIAS (NEUTRAL/BULL/BEAR) — read off the 1h timeframe only (the
//   slowest/"macro" of the three): BULL if price > EMA50 > EMA200, BEAR
//   if price < EMA50 < EMA200, else NEUTRAL. This is the anchor direction
//   every field below is measured against.
//
//   HARD ALIGNMENT (NONE/PARTIAL/FULL) — how many of the 3 timeframes
//   have a fully stacked ladder (EMA5>EMA9>EMA22>EMA50>EMA200, or the
//   mirrored descending stack for BEAR) in the SAME direction as Macro
//   Bias. FULL = all 3 timeframes stacked, PARTIAL = 1-2, NONE = 0
//   (including whenever Macro Bias itself is NEUTRAL — nothing to align
//   with).
//
//   SOFT ALIGNMENT (YES/NO) — a looser directional check: on BOTH 5m and
//   15m, price sits on the Macro-Bias-consistent side of at least 3 of
//   the 5 EMAs (doesn't require the EMAs themselves to be in perfect
//   order, just price positioning relative to most of them).
//
//   PULLBACK ZONE (YES/NO) — on 5m, price has retraced to within 0.15%
//   of EMA9 or EMA22 (whichever is closer) while Macro Bias is still
//   directional — the "buy/sell the dip to a fast moving average in a
//   trend" read.
//
//   STRUCTURAL SUPPORT (YES/NO) — on 15m, the last 2 bars show a
//   higher-low (BULL) or lower-high (BEAR) — the same swing-structure
//   test mtf_engine.cpp uses for its own per-timeframe bias score,
//   reused here at a single fixed timeframe instead of scored per-TF.
//
//   VWAP FLOOR (YES/NO) — on 5m, price is holding above (BULL) or below
//   (BEAR) the session-anchored VWAP from spy_ema_chart_engine.h.
//
//   OBV CONFIRM (YES/NO) — on 15m, On-Balance Volume's own 20-period EMA
//   has a positive slope over the last 5 bars for BULL, negative for
//   BEAR (volume flow agreeing with price direction).
//
//   STOCHRSI CONFIRM (YES/NO) — on 15m, StochRSI(14,14,3,3) %K crossed up
//   through 20 in the last 3 bars for BULL, or down through 80 for BEAR —
//   momentum turning in the trend's favor from an oversold/overbought
//   pullback, not just "currently extreme."
//
//   KELTNER EXPANSION (YES/NO) — on 5m, reuses
//   spy_ema_chart_engine.h's own keltner_expanding flag (band width >10%
//   wider than 10 bars ago) — volatility breaking out of a squeeze.
//
//   LONG TRIGGER (YES/NO) — true only when Macro Bias is BULL, Hard
//   Alignment is not NONE, and Soft Alignment + at least one of
//   {Pullback Zone, Structural Support} + VWAP Floor + OBV Confirm +
//   StochRSI Confirm + Keltner Expansion are ALL true. Deliberately named
//   for the long side only, matching the spec as given — a mirrored
//   "Short Trigger" for BEAR setups isn't included but is a one-line add
//   if wanted.
//
//   CONFIDENCE (0-100) — 30 (base) + Hard Alignment bonus (FULL +25,
//   PARTIAL +12, NONE +0) + 6 points per true confirmation among
//   {Soft Alignment, Pullback Zone, Structural Support, VWAP Floor, OBV
//   Confirm, StochRSI Confirm, Keltner Expansion} (7 x 6 = 42 max),
//   clamped to [0,100], then halved if Macro Bias is NEUTRAL (a
//   directional checklist score means much less with no directional
//   anchor to hang it on).
//
// ── Timeframe filter (anchor_tf) ──────────────────────────────────────
// All 3 timeframes are still fetched and shown in the ladder table every
// time — the filter changes which ONE of them the score is actually
// built around:
//   - Macro Bias reads off the CHOSEN timeframe's price/EMA50/EMA200
//     stack (originally hardcoded to 1h only).
//   - Soft Alignment now requires the OTHER two timeframes (not the
//     anchor) to directionally agree with Macro Bias — e.g. with 5m
//     chosen as anchor, 15m and 1h must agree, instead of always
//     checking 5m+15m regardless of anchor.
//   - Pullback Zone, VWAP Floor, and Keltner Expansion are computed on
//     the anchor timeframe's own price series (was hardcoded to 5m).
//   - Structural Support, OBV Confirm, and StochRSI Confirm are computed
//     on the anchor timeframe's own bars (was hardcoded to 15m).
// Net effect: picking "5m" scores a fast scalp setup on its own terms
// instead of always being graded against a 1h macro anchor; picking
// "1h" reproduces the original always-1h-anchored behavior exactly.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include "qe/spy_ema_chart_engine.h"
#include <string>
#include <vector>

namespace qe {

// Per-timeframe candles + this engine's own EMA5/9/22/50/200 series (NOT
// just the final value each already had) — retained rather than
// discarded, at no extra computation cost: buildLadderTf() already
// computes the full recursiveEma() vectors internally, it previously
// just kept .back() and threw the rest away.
struct MaLadderChartSeries {
    std::vector<long long> timestamps; // unix epoch seconds, one per bar
    std::vector<double> opens, highs, lows, closes;
    std::vector<double> ema5, ema9, ema22, ema50, ema200; // same length/order as closes above
    bool valid = false;
};

struct MaLadderTimeframe {
    std::string tf; // "5m" | "15m" | "1h"
    double price = 0;
    double ema5 = 0, ema9 = 0, ema22 = 0, ema50 = 0, ema200 = 0;
    bool full_stack_bull = false; // ema5>ema9>ema22>ema50>ema200
    bool full_stack_bear = false; // mirrored descending stack
    bool valid = false;           // false if this TF failed to fetch / <20 bars
    MaLadderChartSeries series;   // full historical series for this TF — for charting, not the checklist logic
};

struct MaLadderConfluence {
    std::vector<MaLadderTimeframe> timeframes; // 5m, 15m, 1h, in that order

    std::string anchor_tf = "1h";          // which TF the score below is built around
    int confidence = 0;                    // 0-100
    std::string macro_bias = "NEUTRAL";    // NEUTRAL | BULL | BEAR
    std::string hard_alignment = "NONE";   // NONE | PARTIAL | FULL
    bool soft_alignment = false;
    bool pullback_zone = false;
    bool structural_support = false;
    bool vwap_floor = false;
    bool obv_confirm = false;
    bool stochrsi_confirm = false;
    bool keltner_expansion = false;
    bool long_trigger = false;

    // Full anchor-timeframe chart — candles, EMA9/20/50, VWAP, Keltner
    // bands, BB, RSI, MACD, ADX, OBV, all of it (see SpyEmaChart). This
    // was already being computed internally to read VWAP Floor and
    // Keltner Expansion above and then discarded after pulling out one
    // number from each — now retained as-is instead, since it's already
    // a complete, ready-to-plot dataset for the anchor timeframe
    // specifically (its own EMA9/20/50 periods, not this engine's
    // 5/9/22/50/200 ladder — both are available, on the anchor
    // timeframe's own MaLadderTimeframe.series and here respectively).
    SpyEmaChart anchor_chart;

    bool valid = false; // false only if ALL 3 timeframes failed to fetch
};

// `anchor_tf_idx` selects which timeframe the score is built around:
// 0 = 5m, 1 = 15m, 2 = 1h (default — matches the original always-1h
// behavior). See the "Timeframe filter" header section above.
MaLadderConfluence computeMaLadderConfluence(HttpClient& http, const std::string& symbol,
                                              int anchor_tf_idx = 2);

} // namespace qe
