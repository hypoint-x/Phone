#pragma once
// ─────────────────────────────────────────────────────────────────────────
// SPY Settlement Engine — multi-factor 3:30 PM SPY settlement forecast,
// ported from the Python version's compute_quant_engine() /
// _qe_record_actual() (spec: skills-a.txt / spy_settlement_quant_engine
// v1.0). Combines:
//   w1 Settlement score · w2 Markov state transition (markov_engine.h) ·
//   w3 Expected Value · w4 Linear-regression trend projection ·
//   w5 Black-Scholes dealer-gamma bias · w6 Fibonacci retracement
//
// IMPORTANT — this is NOT the same thing as quant_engine.h's
// "Quant Engine (SPY 3:30)" panel ported earlier in this project. That
// one was a much simpler gamma-snapshot + session-VWAP breakout read.
// THIS is the actual spec'd multi-factor settlement forecast with
// adaptive learning. Both are legitimate, independently-existing tools
// in the Python source (the simpler one didn't replace this one — I
// just hadn't ported this one yet). Keeping both, distinctly named.
//
// Two fidelity notes carried over deliberately, NOT unified with the
// rest of this port's conventions:
//   1. This engine's 0DTE time-to-expiry floor is a flat "~30 minutes of
//      theta-time" ((30/(60*6.5))/252), regardless of actual wall-clock
//      time — a DIFFERENT convention than black_scholes.h's
//      timeToExpiry0dte(), which uses the real ET minutes-to-close. The
//      Python source genuinely has both conventions in different places;
//      this port preserves that rather than silently standardizing on
//      one, since "fixing" it would change this specific spec'd engine's
//      output from what the spec describes.
//   2. Its ATM-IV / gamma-flip / dealer-GEX snapshot uses a ±10%
//      strike window and averages IV over the 6 nearest-to-spot strikes —
//      different from dealer_positioning.h's computeGammaWalls (no window
//      filter at all) and gex_by_strike.h's ±8% window. Three genuinely
//      different windows exist across three genuinely different original
//      endpoints; ported as three genuinely different functions rather
//      than merged into one "canonical" gamma snapshot.
//
// STATEFUL, NOT THREAD-SAFE: owns a MarkovEngine plus a rolling 30-entry
// forecast history and adaptive weights, mutated by recordActual() —
// same single-writer assumption as markov_engine.h. One instance per
// running app, matching the Python version's single module-level
// _qe_state dict.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/markov_engine.h"
#include "qe/http_client.h"
#include <array>
#include <vector>
#include <string>
#include <optional>

namespace qe {

struct SettlementForecast {
    bool available = false;
    std::string error;
    std::string as_of;
    bool is_live = false;

    // inputs
    double spy_900 = 0, spy_930 = 0, spy_1030 = 0, spy_current = 0;
    double morning_high = 0, morning_low = 0;
    double implied_volatility = 0.18, risk_free_rate = 0.05, dealer_gamma_exposure = 0;
    int days_to_expiration = 0;
    std::optional<double> gamma_flip;

    // state classification
    MarkovState current_state = MarkovState::Neutral;
    MarkovState predicted_state = MarkovState::Neutral;
    double morning_change_pct = 0;

    // markov
    double probability_up = 0, probability_neutral = 0, probability_down = 0;
    std::array<double, 3> transition_row{};

    // expected value
    double ev_value = 0, reward_up = 0, reward_neutral = 0, reward_down = 0;
    std::string ev_interpretation;

    // black-scholes hedge pressure
    double bs_delta = 0, bs_gamma = 0, bs_vega = 0, bs_theta = 0;
    std::string gamma_bias_label, bs_interpretation;

    // fibonacci (levels in the same fixed display order as the original:
    // 0.236, 0.382, 0.500, 0.618, 0.786, 1.272, 1.618, 2.618)
    std::vector<std::pair<std::string, double>> fib_levels;
    std::string fib_nearest_label;
    double fib_nearest_level = 0, fib_distance_pct = 0;

    // linear regression (09:00/09:30/10:30/now -> projected 15:30)
    double slope = 0, intercept = 0, r_squared = 0, projected_330_price = 0;

    // settlement score
    double settlement_score = 0;
    std::string settlement_bias_label;
    int trend_adjustment_pct = 0;
    std::string dealer_adjustment, ev_adjustment;

    // final weighted forecast
    double final_score = 0;
    std::string direction; // "BULLISH" | "BEARISH" | "NEUTRAL"
    double confidence_score = 0;
    std::array<double, 6> weights{}; // w1..w6, as used for this forecast

    // chart series: {"09:00","09:30","10:30","now","15:30 (proj.)"}
    std::vector<std::string> chart_times;
    std::vector<double> chart_values;
};

struct AdaptiveLearningResult {
    bool ok = false;
    std::string error;
    bool correct = false;
    std::string predicted_state, actual_state;
    std::array<double, 6> updated_weights{};
    std::array<double, 3> updated_transition_row{};
};

class SpySettlementEngine {
public:
    SpySettlementEngine(); // seeds weights to 1/6 each, matching _qe_state

    // Equivalent of compute_quant_engine() — fetches fresh SPY snapshot +
    // options chain and produces a full forecast. On success, also
    // appends to the rolling history used by recordActual().
    SettlementForecast computeForecast(HttpClient& http);

    // Equivalent of _qe_record_actual() — scores the last forecast
    // against the real 3:30 print, nudges the Markov transition matrix
    // and the w1-w6 weights toward whatever pointed the right way.
    AdaptiveLearningResult recordActual(double spy_330_actual);

    std::array<double, 6> weights() const { return weights_; }
    // Matches /api/quant_engine/weights's POST handler: clamps to >= 0,
    // renormalizes to sum to 1.
    void setWeights(std::array<double, 6> w);

    // Read-only access to the internal Markov engine — lets a standalone
    // "Markov Engine" panel show the same live, adaptively-learned
    // transition matrix that's actually driving this engine's w2
    // component, rather than an unrelated duplicate instance that would
    // silently drift out of sync with it over time.
    const MarkovEngine& markov() const { return markov_; }

private:
    MarkovEngine markov_;
    std::array<double, 6> weights_;

    struct HistoryEntry {
        MarkovState current_state, predicted_state;
        double spy_current;
        std::array<double, 6> components; // raw (pre-weight) component values
    };
    std::vector<HistoryEntry> history_; // capped at 30, mirrors Python's [-30:]
};

} // namespace qe
