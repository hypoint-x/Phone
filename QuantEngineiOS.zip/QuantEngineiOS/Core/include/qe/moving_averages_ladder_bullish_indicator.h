#pragma once
// ─────────────────────────────────────────────────────────────────────────
// MovingAveragesLadderBullishIndicator -- a strategic bullish/bearish index
// across the 5m, 15m and 1h Moving Average Ladder anchors.
//
// For each timeframe it takes that anchor's MaLadderConfluence, derives the
// 8-bit codex state (same bit layout as MovingAveragesLadderAiEngine), looks
// up the codex row's expected value (EV, in R, at the size the rule asks
// for), and signs it by the direction of the codex trade (long / short /
// none). The three scores are blended with the higher timeframe leading:
//     1h 45%  +  15m 35%  +  5m 20%
// and the 5m state is used as the entry timer.
//
// EV figures are assumption-based priors (see MovingAveragesLadder_BearBull_EV
// md/csv) and NOT backtested. States the author's codex files do not cover
// (54 of 256) and NEUTRAL macro bias contribute no score; remaining weights
// are renormalized and `coverage` reports how much of the blend was scored.
//
// Caller computes the three confluences (one per anchor) as the MA Ladder
// panel already does; this file does no fetching.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/ma_ladder_engine.h"
#include <array>
#include <cstdint>
#include <string>

namespace qe {

struct BullishTf {
    uint8_t state = 0;          // 8-bit codex state
    int bias = 0;               // +1 BULL, -1 BEAR, 0 NEUTRAL
    int band = 1;               // 0 Low (10-30), 1 Mid (40-60), 2 High (70-90)
    int confidence_pct = 0;
    bool covered = false;       // false = state not in the codex files (no score)
    int dir = 0;                // direction of the codex trade: +1 long, -1 short, 0 no trade
    float ev_sized = 0.f;       // EV in R at the codex size
    float ev_trade = 0.f;       // EV in R per full-size trade
    bool confirm_first = false; // rule says wait for a candle close / break before entering
    float ev_score = 0.f;       // signed EV scaled to [-1, +1]; positive = bullish
    float macro_lean = 0.f;     // bias sign x confidence band weight, [-1, +1]
};

struct BullishIndicator {
    std::array<BullishTf, 3> tf;       // [0]=5m, [1]=15m, [2]=1h
    float index = 0.f;                 // -100 .. +100, positive = bullish
    float macro_lean = 0.f;            // weighted macro bias/confidence lean, [-1, +1]
    float coverage = 0.f;              // fraction of the timeframe weights that could be scored (1.0 = all three)
    bool trigger_5m = false;           // 5m state fires a long with meaningful EV
    bool entry_ready = false;          // bullish stance AND 5m trigger with no wait-for-confirmation clause
    float suggested_size = 0.f;        // fraction of normal size the 5m codex rule asks for (0 when not entry_ready)
    std::string stance = "NO READ";    // STRATEGIC BULLISH / BULLISH LEAN / NO EDGE / MIXED / BEARISH LEAN / STRATEGIC BEARISH / NO READ
};

BullishTf computeBullishTf(const MaLadderConfluence& ml);
BullishIndicator computeBullishIndicator(const MaLadderConfluence& m5, const MaLadderConfluence& m15, const MaLadderConfluence& h1);

} // namespace qe
