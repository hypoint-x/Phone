#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Markov Engine — the 3-state (Up/Neutral/Down) transition matrix used by
// the SPY Settlement Engine's w2 component, ported from the Python
// version's `_QE_DEFAULT_TRANSITION` / `_qe_state["transition"]` +
// the transition-matrix-nudging half of `_qe_record_actual()`.
//
// This is a genuinely reusable, stateful module: the transition matrix
// starts from a seed prior (not fitted data) and is nudged toward
// observed outcomes over time via a simple learning-rate update, exactly
// as the Python version's comment describes it ("Prior transition matrix
// ... a seed prior, not fitted data").
//
// Stateful and NOT thread-safe by design — same as the Python version's
// module-level `_qe_state` dict, which every request read and mutated
// without a lock. One MarkovEngine instance should be owned by whatever
// single place drives the settlement engine's refresh cycle (see
// spy_settlement_engine.h), not shared across concurrent callers.
// ─────────────────────────────────────────────────────────────────────────
#include <array>
#include <string>
#include <vector>

namespace qe {

// State order matches the Python version's _QE_STATES = ["U","N","D"].
enum class MarkovState { Up = 0, Neutral = 1, Down = 2 };

inline std::string markovStateToString(MarkovState s) {
    switch (s) { case MarkovState::Up: return "U"; case MarkovState::Neutral: return "N"; default: return "D"; }
}
inline MarkovState markovStateFromString(const std::string& s) {
    if (s == "U") return MarkovState::Up;
    if (s == "D") return MarkovState::Down;
    return MarkovState::Neutral;
}

struct MarkovForecast {
    double probability_up = 0, probability_neutral = 0, probability_down = 0;
    MarkovState predicted_state = MarkovState::Neutral;
    std::array<double, 3> transition_row{}; // the row used for this forecast, for display
};

class MarkovEngine {
public:
    // Seeds with the same prior the Python version used:
    //   U: [0.55, 0.30, 0.15]   N: [0.25, 0.50, 0.25]   D: [0.15, 0.30, 0.55]
    MarkovEngine();

    // Looks up the transition row for `current_state` and returns the
    // forecast (predicted_state = argmax of that row).
    MarkovForecast forecast(MarkovState current_state) const;

    // Nudges transition_[from][to] up by `learning_rate` (default 0.08,
    // matching the Python version's `lr = 0.08`), then renormalizes that
    // row to sum to 1. Mirrors _qe_record_actual()'s transition-matrix
    // update exactly.
    void nudge(MarkovState from_state, MarkovState to_state, double learning_rate = 0.08);

    // Current 3x3 matrix, row = from-state, col = to-state, same order
    // as _QE_STATES — exposed for display/debugging and for the
    // /api/quant_engine-equivalent's "transition_row" field.
    const std::array<std::array<double, 3>, 3>& transition() const { return transition_; }

private:
    std::array<std::array<double, 3>, 3> transition_;
};

} // namespace qe
