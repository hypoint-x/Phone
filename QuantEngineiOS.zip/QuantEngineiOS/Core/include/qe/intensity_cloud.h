#pragma once
// ─────────────────────────────────────────────────────────────────────────
// Intensity Cloud engine — per-strike call vs. put intensity for the
// "Quant Tool — Leading Intensity Cloud" panel, ported from the Python
// version's build_intensity_cloud() / /api/intensity_cloud.
//
// Supports the same 4 metrics as the original's _INTENSITY_METRIC_COLS:
// notional, volume, openInterest ("oi"), and gex.
//
// FIDELITY NOTE on "gex", updated after an accuracy fix: this used to be
// a fourth, differently-scaled GEX convention in the ported codebase
// (`gamma * openInterest * 100 * spot`, vs. the rest of the app's
// `gamma * openInterest * spot^2 * 0.01`). The Python source's own
// comment claimed this was "consistent with the rest of the app's gamma
// helpers" -- that claim was never actually true even in the original
// (a real, pre-existing bug carried over by the port, not introduced by
// it). Also found during the same pass: every other GEX-computing
// location in this codebase (gex_by_strike.h, dealer_positioning.h,
// gamma_node_sequencer.h, zero_dte_engine.h) was missing the real
// options contract multiplier (*100, since each contract represents 100
// shares) in its own spot^2*0.01 formula, understating every dollar-GEX
// figure by 100x. Both gaps are now fixed together: this function uses
// the same gamma*OI*100*spot^2*0.01 formula as everywhere else in the
// app, so "gex" means the same real dollar magnitude no matter which
// panel is showing it.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <vector>
#include <string>

namespace qe {

enum class IntensityMetric { Notional, Volume, OpenInterest, Gex };

inline IntensityMetric intensityMetricFromString(const std::string& s) {
    if (s == "volume") return IntensityMetric::Volume;
    if (s == "oi" || s == "openinterest") return IntensityMetric::OpenInterest;
    if (s == "gex") return IntensityMetric::Gex;
    return IntensityMetric::Notional; // "notional" | "nominal" | default
}

// Shared per-row metric extraction, used by both computeIntensityCloud()
// and computeStrikeHeatmap() so that switching the metric in the "Quant
// Tool" panel moves both visuals identically instead of each having its
// own (potentially diverging) formula for the same metric name.
inline double optionMetricValue(const OptionRow& r, IntensityMetric metric, double spot) {
    switch (metric) {
        case IntensityMetric::Notional: return r.notional;
        case IntensityMetric::Volume: return r.volume;
        case IntensityMetric::OpenInterest: return r.openInterest;
        case IntensityMetric::Gex:
            // gamma * OI * 100 * spot^2 * 0.01 -- the standard "dollar
            // gamma exposure per 1% underlying move" formula, unified
            // here with every other GEX-computing location in this
            // codebase (see gex_by_strike.h's header note for the full
            // derivation). This function previously used gamma*OI*100*
            // spot (missing the quadratic spot term and 0.01
            // normalization), a different and also-incomplete formula
            // from the rest of the app's GEX calculations -- not a
            // deliberate alternate convention, just a second gap found
            // during the same accuracy pass.
            return r.gamma * r.openInterest * 100.0 * (spot != 0 ? spot * spot * 0.01 : 1.0);
    }
    return r.notional;
}

struct IntensityCloudRow {
    double strike = 0;
    double call = 0, put = 0, net = 0;
    float intensity = 0.0f; // max(call,put) / max_val across all rows, clamped [0,1]
    bool call_dominant = false; // "side" in the original
};

struct IntensityCloud {
    double spot = 0;
    std::vector<IntensityCloudRow> rows; // sorted by strike ASCENDING (matches
                                          // the Python version's piv.sort_index())
    bool valid = false;
};

// `rows` should already be DTE-filtered by the caller. `band` restricts
// to strikes within spot ± band (Python default 120 for the function,
// but the live endpoint's query-string default is 15, clamped to
// [3, 150] — callers should pick whichever matches their use case).
IntensityCloud computeIntensityCloud(const std::vector<OptionRow>& rows, double spot,
                                      IntensityMetric metric, double band = 15.0);

} // namespace qe
