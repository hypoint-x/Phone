#pragma once
// ─────────────────────────────────────────────────────────────────────────
// black_scholes — option greeks used by the dealer-positioning / gamma-wall
// engines. Ported from the Python version's `gamma()` helper, including the
// two fixes made to it in the prior round:
//   1. Risk-free rate `r` is the real ^IRX-derived rate (via
//      fetchRiskFreeRate), not a hardcoded 1%.
//   2. Time-to-expiry `T` for 0DTE contracts uses actual minutes-to-close
//      instead of a flat "one full day" (1/365), which understated gamma
//      for same-day SPY/SPX expiries — see timeToExpiry0dte().
// ─────────────────────────────────────────────────────────────────────────
#include <cmath>
#include <chrono>

namespace qe {

inline double normPdf(double x) {
    static const double inv_sqrt_2pi = 0.3989422804014327;
    return inv_sqrt_2pi * std::exp(-0.5 * x * x);
}

inline double normCdf(double x) {
    // erf-based CDF, standard normal
    return 0.5 * (1.0 + std::erf(x / std::sqrt(2.0)));
}

// Black-Scholes gamma. Same for calls and puts (a fact the earlier
// gamma_flip bug fix specifically had to account for — see
// engines/dealer_positioning.cpp).
inline double bsGamma(double spot, double strike, double T, double r, double sigma) {
    if (spot <= 0 || strike <= 0 || T <= 0 || sigma <= 0) return 0.0;
    double d1 = (std::log(spot / strike) + (r + 0.5 * sigma * sigma) * T) /
                (sigma * std::sqrt(T));
    return normPdf(d1) / (spot * sigma * std::sqrt(T));
}

// Session-aware T for 0DTE options: fraction of a trading year remaining
// until the 4:00 PM ET close, not a flat calendar day. Mirrors the fix
// applied to load_options() in the Python version — using T=1/365 for a
// same-day expiry vastly overstates T (understates gamma) right when
// 0DTE gamma dominates SPY/SPX flow.
//
// `minutes_to_close` should be computed by the caller using the actual
// wall-clock time in America/New_York (this header stays timezone-agnostic
// so it doesn't need a timezone library dependency; see ui/session_clock.h
// for the ET-aware helper that produces this value).
inline double timeToExpiry0dte(double minutes_to_close) {
    constexpr double kMinutesPerTradingDay = 60.0 * 6.5; // 9:30–4:00 ET
    constexpr double kTradingDaysPerYear = 252.0;
    double t = (minutes_to_close / kMinutesPerTradingDay) / kTradingDaysPerYear;
    return std::max(t, 1.0 / (365.0 * 24.0)); // floor at ~1 hour-equivalent
}

inline double timeToExpiry(int dte, double minutes_to_close_if_0dte) {
    if (dte == 0) return timeToExpiry0dte(minutes_to_close_if_0dte);
    return std::max(dte / 365.0, 1.0 / 365.0);
}

// Black-Scholes delta. opt_type: true=call, false=put.
inline double bsDelta(double S, double K, double T, double r, double sigma, bool is_call = true) {
    if (T <= 0 || sigma <= 0 || S <= 0 || K <= 0) return 0.0;
    double d1 = (std::log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    return is_call ? normCdf(d1) : normCdf(d1) - 1.0;
}

// Black-Scholes vega, per 1-vol-point (matches the Python version's /100
// scaling, i.e. this returns the price change for a 1.00 move in sigma
// expressed as a whole number like 0.20, not the raw per-unit-sigma vega).
inline double bsVega(double S, double K, double T, double r, double sigma) {
    if (T <= 0 || sigma <= 0 || S <= 0 || K <= 0) return 0.0;
    double d1 = (std::log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    return S * normPdf(d1) * std::sqrt(T) / 100.0;
}

// Black-Scholes theta, per calendar day (matches the Python version's
// /365 scaling). opt_type: true=call, false=put.
inline double bsTheta(double S, double K, double T, double r, double sigma, bool is_call = true) {
    if (T <= 0 || sigma <= 0 || S <= 0 || K <= 0) return 0.0;
    double d1 = (std::log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double term1 = -(S * normPdf(d1) * sigma) / (2.0 * std::sqrt(T));
    double term2 = is_call ? (-r * K * std::exp(-r * T) * normCdf(d2))
                            : ( r * K * std::exp(-r * T) * normCdf(-d2));
    return (term1 + term2) / 365.0;
}

} // namespace qe
