#pragma once
// ─────────────────────────────────────────────────────────────────────────
// HttpClient — thin libcurl wrapper + Yahoo Finance session handling.
//
// Yahoo Finance has no official public API. The endpoints this app uses
// (query1/query2.finance.yahoo.com for quotes, chains, chart data) are
// unofficial, reverse-engineered, and can change or break without notice.
// As of the underlying Python version this was ported from, Yahoo also
// started requiring a session handshake: you must first hit a Yahoo page
// to receive cookies, then call /v1/test/getcrumb (or the equivalent
// consent-cookie dance for EU IPs) to obtain a "crumb" token, and include
// both the cookies and crumb on every subsequent query request or you get
// HTTP 401. This class owns exactly that lifecycle so every engine can
// just call get() / getJson() without worrying about auth.
// ─────────────────────────────────────────────────────────────────────────
#include <string>
#include <optional>
#include <mutex>       // std::recursive_mutex
#include <chrono>
#include <nlohmann/json.hpp>

namespace qe {

struct HttpResponse {
    long status_code = 0;
    std::string body;
    bool ok() const { return status_code >= 200 && status_code < 300; }
};

class HttpClient {
public:
    HttpClient();
    ~HttpClient();

    HttpClient(const HttpClient&) = delete;
    HttpClient& operator=(const HttpClient&) = delete;

    // Plain GET, no auth. Used for endpoints that don't need a crumb
    // (e.g. some chart endpoints still work without one).
    HttpResponse get(const std::string& url,
                     const std::string& extra_headers = "");

    // GET with the Yahoo cookie+crumb attached, refreshing the session
    // first if we don't have one yet or it's stale (>50 min old — crumbs
    // are typically valid ~1h, we refresh early to avoid racing expiry).
    HttpResponse getYahoo(const std::string& url);

    // Convenience: getYahoo() + nlohmann::json::parse(). Throws
    // nlohmann::json::parse_error on malformed bodies (e.g. Yahoo
    // returning an HTML error page instead of JSON, which happens
    // during rate-limiting) — callers should catch and treat as a
    // soft failure, same as the Python version's try/except around
    // yfinance calls.
    nlohmann::json getYahooJson(const std::string& url);

    // Forces the next getYahoo()/getYahooJson() call to redo the
    // cookie+crumb handshake. Useful if a request comes back 401
    // even though we thought our session was fresh.
    void invalidateSession();

private:
    struct Impl;
    Impl* impl_;

    std::recursive_mutex session_mtx_;
    std::string cookie_jar_path_;
    std::string crumb_;
    std::chrono::steady_clock::time_point crumb_fetched_at_{};
    bool session_valid_ = false;

    // Performs the cookie-then-crumb handshake described above.
    // Returns false if either step fails (network error, Yahoo changed
    // the endpoint shape, etc.) — callers fall back to unauthenticated
    // requests, which will likely 401 on quote endpoints but may still
    // work on some chart endpoints.
    bool ensureSession();
    bool sessionStale() const;
};

} // namespace qe
