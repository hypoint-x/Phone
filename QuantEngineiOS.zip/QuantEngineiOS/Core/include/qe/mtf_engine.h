#pragma once
// ─────────────────────────────────────────────────────────────────────────
// MTF Engine — multi-timeframe bias read across 1m/5m/15m/1h/1d, ported
// from the Python version's compute_mtf_bias() / summarize_mtf() /
// compute_buy_signal() / compute_early_signal() / compute_confidence().
//
// Each timeframe is scored 0-2 based on: (a) whether the swing structure
// (higher-high/higher-low vs lower-low/lower-high over the last 3 bars)
// agrees with the candle direction, and (b) whether price is on the
// correct side of its own 50-period EMA for that structure. This is a
// faithful port — no formula changes were needed here (unlike MLE/SPLE/
// dealer positioning), since the ticker-column mismatch bug that hit
// those engines doesn't apply to compute_mtf_bias (it works off a single
// symbol's own OHLC columns, always correctly labeled).
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <string>
#include <vector>

namespace qe {

struct MtfTimeframeResult {
    std::string tf;      // "1m" | "5m" | "15m" | "1h" | "1d"
    std::string bias;    // "BULL" | "BEAR" | "NEUTRAL"
    std::string candle;  // "BULL" | "BEAR" (current bar green/red)
    std::string trend;   // "ABOVE EMA" | "BELOW EMA" (vs EMA50 on that TF)
    int score = 0;       // 0-2, see header comment
};

// Fetches each of the 5 standard timeframes for `symbol` and scores them.
// A timeframe that fails to fetch or has <20 bars is silently dropped
// (mirrors the Python version's bare `except: continue` per-timeframe) —
// the rest of the read still returns using whatever timeframes succeeded.
std::vector<MtfTimeframeResult> computeMtfBias(HttpClient& http, const std::string& symbol);

struct MtfSummary {
    std::string signal = "NO DATA"; // "BULLISH" | "BEARISH" | "NEUTRAL" | "NO DATA"
    int confidence = 0;             // 0-100
};
MtfSummary summarizeMtf(const std::vector<MtfTimeframeResult>& mtf);

// "WAIT" | "BUY" | "SELL" depending on which side has more BULL/BEAR reads.
std::string computeBuySignal(const std::vector<MtfTimeframeResult>& mtf);

// Names the single highest-scoring timeframe's bias as the "earliest"
// actionable read (ported 1:1 from compute_early_signal's max-by-score).
std::string computeEarlySignal(const std::vector<MtfTimeframeResult>& mtf);

// Blends average MTF score with how far the breakout probability sits
// from 50/50 into a single 1-99 confidence number. `breakout_prob_up`
// should come from quant_engine.h's BreakoutProbability::prob_up.
int computeConfidence(const std::vector<MtfTimeframeResult>& mtf, double breakout_prob_up);

} // namespace qe
