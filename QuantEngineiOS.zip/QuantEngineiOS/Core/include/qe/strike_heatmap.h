#pragma once
// ─────────────────────────────────────────────────────────────────────────
// strike_heatmap — call vs. put dominance by strike, ported from the
// Python version's build_strike_heatmap_html(). Returns structured rows
// instead of HTML strings (this is a native ImGui app, not a browser),
// but the underlying math — grouping, net/total, peak detection, color
// intensity — is a faithful 1:1 port of the notional case.
//
// METRIC SWITCHING: the original only ever summed notional. The "Quant
// Tool — Leading Intensity Cloud" panel combines this heatmap with
// intensity_cloud.h's cloud overlay, which *does* support switching
// between notional/volume/openInterest/gex — so as of this port, the
// heatmap accepts the same qe::IntensityMetric and uses the identical
// per-row value formula (see intensity_cloud.cpp's metricValue()) for
// every metric, so switching the metric in that panel now moves both
// visuals together instead of only the cloud.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include "qe/intensity_cloud.h" // IntensityMetric (shared metric enum)
#include <vector>
#include <limits>

namespace qe {

struct StrikeHeatmapRow {
    double strike = 0;
    double call_notional = 0; // holds the *selected metric's* call-side value
    double put_notional = 0;  // holds the *selected metric's* put-side value
    double net = 0;    // call_notional - put_notional
    double total = 0;  // call_notional + put_notional (direction-agnostic activity)
    bool call_dominant = false;
    float intensity = 0.0f; // |net| / max(|net|) across all strikes, clamped [0,1]
    bool is_peak = false;   // true for the single strike with the highest `total`
    bool is_runner_up = false; // true for the strike with the 2nd-highest `total` —
                                // lets the UI give the "silver" runner-up its own
                                // (quieter) highlight instead of only ever marking
                                // a single strike as noteworthy.
};

struct StrikeHeatmap {
    std::vector<StrikeHeatmapRow> rows; // sorted by strike DESCENDING (matches
                                         // the original's ladder convention —
                                         // highest strike at the top)
    bool valid = false;

    // ENHANCEMENT: how decisively the peak strike actually dominates —
    // (best_total - runner_up_total) / best_total, clamped [0,1]. 1.0 =
    // all activity concentrated at one strike with nothing else close;
    // near 0.0 = the peak is barely ahead of the next-busiest strike, a
    // much weaker read than the plain "is_peak" boolean alone conveys.
    // Callers (the UI's glow-pulse border) use this to modulate pulse
    // speed/brightness so a decisive peak visibly reads as more urgent
    // than a marginal one, instead of every peak rendering identically.
    float peak_dominance = 0.0f;

    // Strike of the 2nd-highest `total` row (matches whichever row has
    // is_runner_up == true), NaN if there are fewer than 2 strikes with
    // nonzero total. Exposed directly (rather than making callers re-scan
    // `rows` for the flag) since the UI needs it before it's iterated the
    // row list.
    double runner_up_strike = std::numeric_limits<double>::quiet_NaN();
};

// `rows` should already be DTE-filtered by the caller (this mirrors the
// Python version taking whatever `data` the route already loaded via
// load_options(ticker, dte), rather than filtering DTE itself).
//
// `metric` selects notional/volume/openInterest/gex, matching
// intensity_cloud.h's IntensityMetric. `spot` is only used by the Gex
// metric's formula (gamma * OI * 100 * spot) and is ignored otherwise —
// pass 0 for non-Gex metrics if spot isn't handy.
StrikeHeatmap computeStrikeHeatmap(const std::vector<OptionRow>& rows,
                                    IntensityMetric metric = IntensityMetric::Notional,
                                    double spot = 0.0);

} // namespace qe
