#pragma once
// ─────────────────────────────────────────────────────────────────────────
// yahoo_endpoints — thin typed layer over the unofficial Yahoo Finance
// endpoints, replacing what `yfinance` did in the Python version.
//
// Endpoints used (unofficial, undocumented, subject to breakage):
//   Chart/OHLCV:   https://query1.finance.yahoo.com/v8/finance/chart/{sym}
//   Options chain: https://query1.finance.yahoo.com/v7/finance/options/{sym}
//   Quote summary: https://query1.finance.yahoo.com/v10/finance/quoteSummary/{sym}
//
// All of these go through HttpClient::getYahoo(), so they carry the
// cookie+crumb session automatically.
// ─────────────────────────────────────────────────────────────────────────
#include <string>
#include <vector>
#include <optional>
#include "qe/http_client.h"

namespace qe {

struct Bar {
    long long timestamp = 0;   // unix epoch seconds
    double open = 0, high = 0, low = 0, close = 0, adjclose = 0;
    double volume = 0;
};

struct OhlcvSeries {
    std::string symbol;
    std::vector<Bar> bars;
    bool valid = false;

    // Mirrors the defensive column-access pattern the Python version used
    // for yfinance's occasional MultiIndex-column quirk — here there's no
    // such quirk (we control the JSON parsing directly), but we keep this
    // shape so engine code reads naturally: series.closes(), etc.
    std::vector<double> closes() const;
    std::vector<double> highs() const;
    std::vector<double> lows() const;
    std::vector<double> volumes() const;
    double lastClose() const { return bars.empty() ? 0.0 : bars.back().close; }
};

struct OptionRow {
    double strike = 0;
    double lastPrice = 0;
    double impliedVolatility = 0.2; // yahoo default fallback, matches Python version
    double openInterest = 0;
    double volume = 0;
    double notional = 0; // lastPrice * volume * 100 (100 = contract multiplier)
    double gamma = 0;   // computed locally (Black-Scholes), not provided by Yahoo
    std::string type;   // "call" or "put"
    std::string expiration; // "YYYY-MM-DD"
    int dte = 0;
};

struct OptionChain {
    std::string symbol;
    double spot = 0;
    std::vector<OptionRow> rows;
    bool valid = false;
};

// period examples: "1d","5d","1mo","3mo","6mo","1y","2y","5y","max"
// interval examples: "1m","2m","5m","15m","30m","60m","1d","1wk","1mo"
// NOTE on limits carried over from the Python version: intraday intervals
// (1m/2m/5m) are only available for recent history (~60 days for 1m,
// ~60 days for other sub-daily on Yahoo's backend) — request a period
// that respects that or you'll silently get a truncated range back.
OhlcvSeries fetchChart(HttpClient& http, const std::string& symbol,
                       const std::string& period, const std::string& interval);

// Fetches the full options chain across up to `max_expirations` expiries
// within `dte_limit` days, mirroring load_options() from the Python
// version (including its dte_limit filter and gamma back-fill — gamma
// is NOT part of Yahoo's response and must be computed by the caller;
// see engines/black_scholes.h).
OptionChain fetchOptionChain(HttpClient& http, const std::string& symbol,
                             int dte_limit = 15, int max_expirations = 10);

// 13-week T-bill yield (^IRX) as a decimal (e.g. 0.05 for 5%), used as
// the risk-free rate for every Black-Scholes calc — mirrors the fixed
// _qe_risk_free_rate() from the Python version, including its 10-minute
// cache (implemented here via a static in the .cpp, guarded by a mutex).
double fetchRiskFreeRate(HttpClient& http);

} // namespace qe
