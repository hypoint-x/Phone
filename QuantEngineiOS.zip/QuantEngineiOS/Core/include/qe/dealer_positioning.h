#pragma once
// ─────────────────────────────────────────────────────────────────────────
// dealer_positioning — dealer gamma exposure (GEX) and gamma walls.
//
// Ported from the Python version AFTER its two accuracy fixes:
//   1. GEX uses dollar-gamma-exposure scaling (gamma * OI * spot^2 * 0.01,
//      i.e. dealer P&L per 1% underlying move) instead of raw unscaled
//      gamma*OI, which put numbers on an incomparable, spot-independent
//      scale.
//   2. gamma_flip uses NET dealer gamma per strike (call gamma*OI minus
//      put gamma*OI, spot-scaled) instead of an unweighted, unsigned sum
//      of raw gamma across calls AND puts — Black-Scholes gamma is
//      positive for both calls and puts, so blindly summing them can't
//      locate a genuine zero-exposure strike.
// ─────────────────────────────────────────────────────────────────────────
#include <vector>
#include <optional>
#include "qe/yahoo_endpoints.h"

namespace qe {

struct GammaWalls {
    std::optional<double> call_wall;
    std::optional<double> put_wall;
    std::optional<double> gamma_flip;
};

struct DealerPositioning {
    std::string regime = "NEUTRAL"; // "LONG GAMMA" | "SHORT GAMMA" | "NEUTRAL"
    double gex = 0.0;
};

// call_wall / put_wall = strikes with the largest OI-weighted |gamma|
// concentration (dealer hedging magnets). gamma_flip = the strike where
// net dealer gamma exposure crosses zero.
GammaWalls computeGammaWalls(const std::vector<OptionRow>& rows, double spot);

// Net dealer gamma exposure across the whole chain, using the same
// dollar-GEX convention as computeGammaWalls (spot^2-scaled).
DealerPositioning computeDealerPositioning(const std::vector<OptionRow>& rows, double spot);

} // namespace qe
