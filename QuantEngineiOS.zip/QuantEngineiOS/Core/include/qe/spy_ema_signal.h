#pragma once
// ─────────────────────────────────────────────────────────────────────────
// SPY EMA Signal engine — the lightweight EMA9/EMA21 read used by the main
// dashboard's alert engine.
//
// FLAGGED, NOT SILENTLY FIXED: in the Python version's main route, `ema9`
// and `ema21` (single latest values, via `close_series.ewm(span=9/21)
// .mean().iloc[-1]`) were computed inside the alerts try-block but never
// actually referenced by any alert condition below them — CVD, RSI,
// gamma/VWAP, Euro-close/CTA windows, and wall-proximity alerts all fire
// off other variables. The EMA9/21 computation was effectively dead code:
// calculated every request, never used. Rather than port that gap
// faithfully (which would mean shipping a function that computes a value
// and then does nothing with it), this engine completes the obviously-
// intended feature: an EMA9/21 cross + above/below reading, structured so
// main.cpp can actually wire it into an alert. If you'd rather this stay
// unused (e.g. because you have a reason for excluding it from alerts
// that isn't visible in the code), it's a one-line change to drop it from
// the panel.
// ─────────────────────────────────────────────────────────────────────────
#include "qe/yahoo_endpoints.h"
#include <string>

namespace qe {

struct SpyEmaSignal {
    double ema9 = 0.0, ema21 = 0.0;
    std::string state = "NO DATA"; // "BULL CROSS" | "BEAR CROSS" | "ABOVE" | "BELOW" | "NO DATA"
    bool valid = false;
};

// `intraday` should be a recent intraday series (the Python version used
// the same 5d/5m tape already fetched for CVD/alerts — pass the same
// series here to avoid an extra fetch).
SpyEmaSignal computeSpyEmaSignal(const OhlcvSeries& intraday);

} // namespace qe
