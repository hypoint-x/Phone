// qe_ios.cpp — JSON bridge over the desktop engines. No engine maths lives here: every method
// fetches the same inputs main.cpp does, calls the same engine function, and serialises the result.
#include "qe_ios.h"
#include "qe/yahoo_endpoints.h"
#include "qe/option_greeks.h"
#include "qe/option_surface.h"
#include "qe/strike_heatmap.h"
#include "qe/intensity_cloud.h"
#include "qe/mtf_engine.h"
#include "qe/ma_ladder_engine.h"
#include "qe/gex_robust.h"
#include "qe/moving_averages_ladder_bullish_indicator.h"
#include "qe/spy_ema_chart_engine.h"
#include "qe/transports_divergence_engine.h"
#include "qe/gex_by_strike.h"
#include "qe/gex_levels_pro.h"
#include "qe/gamma_node_sequencer.h"
#include "qe/net_flow_engine.h"
#include "qe/net_flow_plus_engine.h"
#include "qe/quant_engine.h"
#include "qe/universal_settlement_engine.h"
#include "qe/stats.h"
#include <nlohmann/json.hpp>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <fstream>
#include <map>
#include <memory>
#include <mutex>
#include <thread>

using nlohmann::json;
using namespace qe;

namespace {

std::string g_asset_dir;

HttpClient& http() {                       // one client (=> one crumb) per calling thread
    thread_local std::unique_ptr<HttpClient> c;
    if (!c) c.reset(new HttpClient());
    return *c;
}
double nowSeconds() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
json fin(double v) { return std::isfinite(v) ? json(v) : json(nullptr); }
json optD(const std::optional<double>& o) { return o ? fin(*o) : json(nullptr); }
std::string upper(std::string s) { for (auto& c : s) c = (char)toupper((unsigned char)c); return s; }
json err(const std::string& m) { return json{{"ok", false}, {"error", m}}; }

OptionChain loadChain(const std::string& sym, int dte, int nexp) {
    OptionChain c = fetchOptionChain(http(), sym, dte, nexp);
    if (c.valid) populateOptionGammas(http(), c);   // Yahoo sends no gamma; without this every GEX is 0
    return c;
}
std::vector<OptionRow> window(const OptionChain& c, int max_dte) {
    std::vector<OptionRow> o;
    for (auto& r : c.rows) if (r.dte <= max_dte) o.push_back(r);
    return o;
}

// ── serialisers ───────────────────────────────────────────────────────────
json jBars(const OhlcvSeries& s) {
    json t = json::array(), o = json::array(), h = json::array(), l = json::array(), c = json::array(), v = json::array();
    for (auto& b : s.bars) { t.push_back(b.timestamp); o.push_back(b.open); h.push_back(b.high); l.push_back(b.low); c.push_back(b.close); v.push_back(b.volume); }
    return {{"t", t}, {"o", o}, {"h", h}, {"l", l}, {"c", c}, {"v", v}};
}

json jChart(const SpyEmaChart& c, bool full = true) {
    json j = {{"valid", c.valid}, {"interval", c.interval}, {"last", fin(c.last)}, {"open", fin(c.open)},
              {"change", fin(c.change)}, {"pct", fin(c.pct)}, {"session_high", fin(c.session_high)},
              {"session_low", fin(c.session_low)}, {"setup_score", fin(c.setup_score)},
              {"setup_label", c.setup_label}, {"setup_reasons", c.setup_reasons},
              {"rsi_last", c.rsi.empty() ? json(nullptr) : fin(c.rsi.back())}};
    if (!full) return j;
    j["t"] = c.timestamps; j["o"] = c.opens; j["h"] = c.highs; j["l"] = c.lows; j["c"] = c.closes; j["v"] = c.volumes;
    j["vwap"] = c.vwap; j["ema9"] = c.ema9; j["ema20"] = c.ema20; j["ema50"] = c.ema50;
    j["bb_upper"] = c.bb_upper; j["bb_mid"] = c.bb_mid; j["bb_lower"] = c.bb_lower;
    j["rsi"] = c.rsi; j["macd"] = c.macd_line; j["macd_signal"] = c.macd_signal; j["macd_hist"] = c.macd_hist;
    j["adx"] = c.adx; j["di_plus"] = c.di_plus; j["di_minus"] = c.di_minus;
    j["keltner_upper"] = c.keltner_upper; j["keltner_lower"] = c.keltner_lower; j["keltner_expanding"] = c.keltner_expanding;
    j["obv_bull_div"] = c.obv_bullish_divergence; j["obv_bear_div"] = c.obv_bearish_divergence;
    j["atr_percentile"] = fin(c.atr_percentile);
    j["reg"] = {{"slope", fin(c.reg_slope)}, {"r2", fin(c.reg_r2)}, {"mid", c.reg_mid}, {"upper", c.reg_upper}, {"lower", c.reg_lower}};
    j["pivots"] = {{"valid", c.pivot_valid}, {"pp", c.pivot_pp}, {"r1", c.pivot_r1}, {"r2", c.pivot_r2}, {"s1", c.pivot_s1}, {"s2", c.pivot_s2}};
    json sr = json::array();
    for (auto& s : c.sr_levels) sr.push_back({{"price", s.price}, {"touches", s.touches}, {"resistance", s.is_resistance}});
    j["sr"] = sr;
    j["volume_profile"] = {{"valid", c.volume_profile_valid}, {"poc", c.vp_poc}, {"vah", c.vp_vah}, {"val", c.vp_val},
                           {"bin_price", c.vp_bin_price}, {"bin_frac", c.vp_bin_volume_frac}};
    json fib = json::array();
    for (auto& f : c.fib_levels) fib.push_back({{"ratio", f.ratio}, {"price", f.price}, {"label", f.label}});
    j["fib"] = {{"valid", c.fib_valid}, {"high", c.fib_swing_high}, {"low", c.fib_swing_low}, {"uptrend", c.fib_uptrend}, {"levels", fib}};
    json pat = json::array();
    for (auto& p : c.patterns) pat.push_back({{"index", p.index}, {"name", p.name}, {"bullish", p.bullish}});
    j["patterns"] = pat;
    auto& tp = c.trade_plan;
    j["trade_plan"] = {{"valid", tp.valid}, {"direction", tp.direction}, {"entry", tp.entry}, {"stop", tp.stop},
                       {"target_1r", tp.target_1r}, {"target_2r", tp.target_2r}, {"risk", tp.risk_per_share},
                       {"style", tp.style}, {"entry_type", tp.entry_type}, {"entry_quality", tp.entry_quality},
                       {"factors", tp.confluence_factors}, {"rr1", tp.reward_risk_1r}, {"rr2", tp.reward_risk_2r},
                       {"invalidation", tp.invalidation}};
    return j;
}

json jLadder(const MaLadderConfluence& m, bool with_series) {
    json tfs = json::array();
    for (auto& t : m.timeframes) {
        json x = {{"tf", t.tf}, {"price", t.price}, {"ema5", t.ema5}, {"ema9", t.ema9}, {"ema22", t.ema22},
                  {"ema50", t.ema50}, {"ema200", t.ema200}, {"bull_stack", t.full_stack_bull},
                  {"bear_stack", t.full_stack_bear}, {"valid", t.valid}};
        if (with_series && t.series.valid) {
            x["series"] = {{"t", t.series.timestamps}, {"o", t.series.opens}, {"h", t.series.highs}, {"l", t.series.lows},
                           {"c", t.series.closes}, {"ema5", t.series.ema5}, {"ema9", t.series.ema9},
                           {"ema22", t.series.ema22}, {"ema50", t.series.ema50}, {"ema200", t.series.ema200}};
        }
        tfs.push_back(x);
    }
    return {{"valid", m.valid}, {"anchor_tf", m.anchor_tf}, {"confidence", m.confidence}, {"macro_bias", m.macro_bias},
            {"hard_alignment", m.hard_alignment}, {"soft_alignment", m.soft_alignment}, {"pullback_zone", m.pullback_zone},
            {"structural_support", m.structural_support}, {"vwap_floor", m.vwap_floor}, {"obv_confirm", m.obv_confirm},
            {"stochrsi_confirm", m.stochrsi_confirm}, {"keltner_expansion", m.keltner_expansion},
            {"long_trigger", m.long_trigger}, {"timeframes", tfs}, {"anchor_chart", jChart(m.anchor_chart, false)}};
}

json jMtf(const std::vector<MtfTimeframeResult>& v) {
    json a = json::array();
    for (auto& r : v) a.push_back({{"tf", r.tf}, {"bias", r.bias}, {"candle", r.candle}, {"trend", r.trend}, {"score", r.score}});
    MtfSummary s = summarizeMtf(v);
    return {{"timeframes", a}, {"signal", s.signal}, {"confidence", s.confidence},
            {"buy_signal", computeBuySignal(v)}, {"early_signal", computeEarlySignal(v)}};
}

const char* markovName(MarkovState s) { return s == MarkovState::Up ? "UP" : s == MarkovState::Down ? "DOWN" : "NEUTRAL"; }

json jForecast(const SettlementForecast& f) {
    json fib = json::array();
    for (auto& p : f.fib_levels) fib.push_back({{"label", p.first}, {"price", p.second}});
    return {{"available", f.available}, {"error", f.error}, {"as_of", f.as_of}, {"is_live", f.is_live},
            {"price_900", f.spy_900}, {"price_930", f.spy_930}, {"price_1030", f.spy_1030}, {"price_current", f.spy_current},
            {"morning_high", f.morning_high}, {"morning_low", f.morning_low}, {"iv", f.implied_volatility},
            {"risk_free", f.risk_free_rate}, {"dealer_gamma", f.dealer_gamma_exposure}, {"dte", f.days_to_expiration},
            {"gamma_flip", optD(f.gamma_flip)}, {"current_state", markovName(f.current_state)},
            {"predicted_state", markovName(f.predicted_state)}, {"morning_change_pct", f.morning_change_pct},
            {"p_up", f.probability_up}, {"p_neutral", f.probability_neutral}, {"p_down", f.probability_down},
            {"ev", f.ev_value}, {"ev_text", f.ev_interpretation},
            {"delta", f.bs_delta}, {"gamma", f.bs_gamma}, {"vega", f.bs_vega}, {"theta", f.bs_theta},
            {"gamma_bias", f.gamma_bias_label}, {"bs_text", f.bs_interpretation}, {"fib", fib},
            {"fib_nearest_label", f.fib_nearest_label}, {"fib_nearest", f.fib_nearest_level}, {"fib_distance_pct", f.fib_distance_pct},
            {"slope", f.slope}, {"r2", f.r_squared}, {"projected_330", f.projected_330_price},
            {"settlement_score", f.settlement_score}, {"settlement_bias", f.settlement_bias_label},
            {"final_score", f.final_score}, {"direction", f.direction}, {"confidence", f.confidence_score},
            {"weights", std::vector<double>(f.weights.begin(), f.weights.end())},
            {"chart_times", f.chart_times}, {"chart_values", f.chart_values}};
}

std::string flowClassName(FlowClass c) {
    switch (c) {
        case FlowClass::AggressiveCall: return "AGGRESSIVE CALL";
        case FlowClass::AggressivePut: return "AGGRESSIVE PUT";
        case FlowClass::Sweep: return "SWEEP";
        case FlowClass::Block: return "BLOCK";
        case FlowClass::Extreme: return "EXTREME";
        default: return "NEUTRAL";
    }
}

// ── desk scan state ───────────────────────────────────────────────────────
struct DeskEntry {
    std::string symbol; bool valid = false;
    double price = 0, rsi = 50;
    std::string ma_bias = "NEUTRAL", ma_hard = "NONE", mtf_signal = "NO DATA", mtf_buy = "WAIT";
    int ma_conf = 0, mtf_conf = 0; bool long_trigger = false;
};
struct Desk {
    std::mutex m; std::vector<DeskEntry> entries; int total = 0, completed = 0;
    std::atomic<bool> running{false}, stop{false}; std::thread coord; long long started = 0;
    ~Desk() { stop = true; if (coord.joinable()) coord.join(); }
} g_desk;

void deskWorker(const std::vector<std::string>& syms, std::atomic<size_t>& next, int pause_ms) {
    while (!g_desk.stop.load()) {
        size_t i = next.fetch_add(1);
        if (i >= syms.size()) break;
        DeskEntry e; e.symbol = syms[i];
        try {
            MaLadderConfluence ma = computeMaLadderConfluence(http(), e.symbol, 2);
            auto mtf = computeMtfBias(http(), e.symbol);
            MtfSummary ms = summarizeMtf(mtf);
            e.valid = ma.valid || ms.signal != "NO DATA";
            if (ma.valid) {
                e.ma_bias = ma.macro_bias; e.ma_conf = ma.confidence; e.ma_hard = ma.hard_alignment; e.long_trigger = ma.long_trigger;
                e.price = ma.anchor_chart.last;
                if (e.price <= 0) for (auto& t : ma.timeframes) if (t.valid) { e.price = t.price; break; }
                if (!ma.anchor_chart.rsi.empty()) e.rsi = ma.anchor_chart.rsi.back();
            }
            e.mtf_signal = ms.signal; e.mtf_conf = ms.confidence; e.mtf_buy = computeBuySignal(mtf);
        } catch (...) { e.valid = false; }
        { std::lock_guard<std::mutex> l(g_desk.m); g_desk.entries.push_back(e); g_desk.completed++; }
        if (pause_ms > 0) std::this_thread::sleep_for(std::chrono::milliseconds(pause_ms));
    }
}

void deskCoordinator(std::vector<std::string> syms, int workers, int pause_ms) {
    std::atomic<size_t> next{0};
    std::vector<std::thread> ts;
    for (int i = 0; i < workers; ++i) ts.emplace_back(deskWorker, std::cref(syms), std::ref(next), pause_ms);
    for (auto& t : ts) t.join();
    g_desk.running = false;
}

std::vector<std::string> loadUniverse() {
    std::vector<std::string> out;
    std::ifstream f(g_asset_dir + "/sp500_symbols.txt");
    std::string line;
    while (std::getline(f, line)) {
        while (!line.empty() && isspace((unsigned char)line.back())) line.pop_back();
        size_t a = 0; while (a < line.size() && isspace((unsigned char)line[a])) ++a;
        if (a < line.size()) out.push_back(line.substr(a));
    }
    return out;
}

// ── persistent trackers (Net Flow / Net Flow+ accumulate across polls) ─────
std::mutex g_trk_m;
std::map<std::string, NetFlowTracker> g_flow;
std::map<std::string, NetFlowPlusTracker> g_flowp;
UniversalSettlementEngine g_universal;
std::mutex g_universal_m;

// ── dispatch ──────────────────────────────────────────────────────────────
json dispatch(const std::string& method, const json& a) {
    std::string sym = upper(a.value("symbol", std::string("SPY")));

    if (method == "ping") return {{"ok", true}};

    if (method == "chart") {            // Chart+
        auto c = computeSpyEmaChart(http(), sym, a.value("period", "5d"), a.value("interval", "5m"));
        return {{"ok", c.valid}, {"symbol", sym}, {"chart", jChart(c)}};
    }
    if (method == "ma_ladder") {
        auto m = computeMaLadderConfluence(http(), sym, a.value("anchor", 2));
        return {{"ok", m.valid}, {"symbol", sym}, {"ladder", jLadder(m, true)}};
    }
    if (method == "bullish") {          // Moving Averages Ladder — Bullish/Bearish Indicator (5m + 15m + 1h)
        MaLadderConfluence m5 = computeMaLadderConfluence(http(), sym, 0), m15 = computeMaLadderConfluence(http(), sym, 1), h1 = computeMaLadderConfluence(http(), sym, 2);
        if (!m5.valid && !m15.valid && !h1.valid) return err("price data unavailable for " + sym + " (Yahoo rate-limit); try again in a minute");
        BullishIndicator b = computeBullishIndicator(m5, m15, h1);
        static const char* names[3] = {"5m", "15m", "1h"};
        json tf = json::array();
        for (int i = 0; i < 3; ++i) {
            const BullishTf& t = b.tf[i]; std::string bits;
            for (int k = 7; k >= 0; --k) bits += ((t.state >> k) & 1) ? '1' : '0';
            const MaLadderConfluence& m = i == 0 ? m5 : i == 1 ? m15 : h1;
            tf.push_back({{"tf", names[i]}, {"state", bits}, {"bias", t.bias}, {"bias_name", m.macro_bias}, {"band", t.band}, {"confidence", t.confidence_pct},
                          {"covered", t.covered}, {"dir", t.dir}, {"ev_sized", t.ev_sized}, {"ev_trade", t.ev_trade}, {"confirm_first", t.confirm_first},
                          {"score", t.ev_score}, {"lean", t.macro_lean}, {"valid", m.valid}});
        }
        return {{"ok", true}, {"symbol", sym}, {"index", b.index}, {"macro_lean", b.macro_lean}, {"coverage", b.coverage}, {"trigger_5m", b.trigger_5m},
                {"entry_ready", b.entry_ready}, {"size", b.suggested_size}, {"stance", b.stance}, {"tf", tf}};
    }
    if (method == "mtf") {
        return {{"ok", true}, {"symbol", sym}, {"mtf", jMtf(computeMtfBias(http(), sym))}};
    }
    if (method == "quote") {
        OhlcvSeries s = fetchChart(http(), sym, "5d", "1d");
        return {{"ok", s.valid}, {"symbol", sym}, {"bars", jBars(s)}};
    }
    if (method == "quant_engine") {     // Quant Engine — All Stocks
        QuantEngineSnapshot snap = computeQuantEngineSnapshot(http(), sym);
        SettlementForecast f;
        { std::lock_guard<std::mutex> l(g_universal_m); f = g_universal.computeForecast(http(), sym); }
        json s = {{"valid", snap.valid}, {"spot", snap.spot}, {"dealer_gex", snap.dealer_gamma_exposure},
                  {"gamma_flip", optD(snap.gamma_flip)}, {"iv", snap.implied_volatility}, {"dte", snap.days_to_expiration},
                  {"vwap", {{"valid", snap.vwap.valid}, {"vwap", snap.vwap.vwap}, {"std", snap.vwap.std},
                            {"u1", snap.vwap.upper_1}, {"l1", snap.vwap.lower_1}, {"u2", snap.vwap.upper_2}, {"l2", snap.vwap.lower_2}}},
                  {"prob_up", snap.breakout.prob_up}, {"prob_down", snap.breakout.prob_down}, {"signal", snap.breakout.signal}};
        return {{"ok", snap.valid || f.available}, {"symbol", sym}, {"snapshot", s}, {"forecast", jForecast(f)}};
    }
    if (method == "intensity_cloud") {  // Quant Tool
        int dte = a.value("dte", 45);
        auto metric = intensityMetricFromString(a.value("metric", "notional"));
        OptionChain c = loadChain(sym, 45, 15);
        if (!c.valid) return err("option chain unavailable (Yahoo rate-limit or no options for " + sym + ")");
        auto rows = window(c, dte);
        double band = a.value("band", c.spot * 0.05);
        IntensityCloud cl = computeIntensityCloud(rows, c.spot, metric, band);
        json r = json::array();
        for (auto& x : cl.rows) r.push_back({{"strike", x.strike}, {"call", x.call}, {"put", x.put}, {"net", x.net}, {"intensity", x.intensity}, {"call_dominant", x.call_dominant}});
        OhlcvSeries bars = fetchChart(http(), sym, "1d", "5m");
        return {{"ok", cl.valid}, {"symbol", sym}, {"spot", c.spot}, {"rows", r}, {"bars", jBars(bars)}};
    }
    if (method == "strike_heatmap") {
        int dte = a.value("dte", 45);
        auto metric = intensityMetricFromString(a.value("metric", "notional"));
        OptionChain c = loadChain(sym, 45, 15);
        if (!c.valid) return err("option chain unavailable (Yahoo rate-limit or no options for " + sym + ")");
        StrikeHeatmap hm = computeStrikeHeatmap(window(c, dte), metric, c.spot);
        json r = json::array();
        for (auto& x : hm.rows) r.push_back({{"strike", x.strike}, {"call", x.call_notional}, {"put", x.put_notional}, {"net", x.net},
                                              {"total", x.total}, {"call_dominant", x.call_dominant}, {"intensity", x.intensity},
                                              {"peak", x.is_peak}, {"runner_up", x.is_runner_up}});
        return {{"ok", hm.valid}, {"symbol", sym}, {"spot", c.spot}, {"rows", r},
                {"peak_dominance", hm.peak_dominance}, {"runner_up_strike", fin(hm.runner_up_strike)}};
    }
    if (method == "gex") {              // GEX levels pro + GEX by strike
        OptionChain c = fetchOptionChain(http(), sym);
        if (!c.valid || c.rows.empty()) return err("option chain unavailable for " + sym);
        populateOptionGammas(http(), c);
        OhlcvSeries daily = fetchChart(http(), sym, "5d", "1d");
        double hi = 0, lo = 0;
        if (daily.valid && !daily.bars.empty()) { hi = daily.bars.back().high; lo = daily.bars.back().low; }
        GexLevelsProResult r = computeGexLevelsPro(sym, c.rows, c.spot, hi, lo);
        if (!r.valid) return err("not enough option data to compute GEX levels");
        json lv = json::array();
        for (auto& l : r.levels) lv.push_back({{"label", l.label}, {"price", l.price}, {"net_gex", l.net_gex}, {"zone", gexZoneLabel(l.zone)},
                                                {"call_gex", l.call_gex}, {"put_gex", l.put_gex}, {"net_gex_vol", l.net_gex_by_volume},
                                                {"call_oi", l.call_oi}, {"put_oi", l.put_oi},
                                                {"call_intensity", l.call_intensity}, {"put_intensity", l.put_intensity}});
        auto side = [&](const GexByStrikeResult& g) {
            return json{{"edge", g.edge}, {"flip", optD(g.gamma_flip)}, {"call_wall", optD(g.call_wall)}, {"put_wall", optD(g.put_wall)},
                        {"strikes", g.net_gex_strikes}, {"net", g.net_gex_values}, {"call_gex", g.calls.gex}, {"put_gex", g.puts.gex},
                        {"call_strikes", g.calls.strikes}, {"put_strikes", g.puts.strikes}};
        };
        GexByStrikeResult oi = computeGexByStrike(r.nearest_expiry_rows, r.spot, GexWeighting::OpenInterest);
        GexByStrikeResult vol = computeGexByStrike(r.nearest_expiry_rows, r.spot, GexWeighting::Volume);
        OhlcvSeries intraday = fetchChart(http(), sym, "5d", "15m");
        GexRobustResult rb = computeGexRobust(c.rows, r.spot, 0.0);
        json rj = {{"valid", rb.valid}, {"flip", optD(rb.flip)}, {"flip_lo", optD(rb.flip_lo)}, {"flip_hi", optD(rb.flip_hi)},
                   {"flip_strike", optD(rb.flip_strike)}, {"call_wall", optD(rb.call_wall)}, {"put_wall", optD(rb.put_wall)},
                   {"strikes", rb.strikes}, {"net", rb.net}, {"call_gex", rb.call_gex}, {"put_gex", rb.put_gex},
                   {"sweep_spot", rb.sweep_spot}, {"sweep_total", rb.sweep_total}, {"rows_in", rb.rows_in}, {"rows_used", rb.rows_used},
                   {"dropped_stale", rb.dropped_stale}, {"dropped_iv", rb.dropped_iv}, {"clipped", rb.clipped}, {"mean_conf", rb.mean_conf},
                   {"stability", rb.stability}, {"edge", rb.flip ? (r.spot > *rb.flip ? "LONG GAMMA" : "SHORT GAMMA") : "NEUTRAL"}};
        return {{"ok", true}, {"symbol", sym}, {"spot", r.spot}, {"regime", r.dealer_regime}, {"levels", lv},
                {"by_oi", side(oi)}, {"by_volume", side(vol)}, {"robust", rj}, {"bars", jBars(intraday)}};
    }
    if (method == "gamma_node") {       // Gamma Node Sequencer
        int dte = a.value("dte", 45);
        OptionChain c = loadChain(sym, 45, 15);
        OhlcvSeries bars = fetchChart(http(), sym, "1d", "5m");
        if (!c.valid) return err("option chain unavailable for " + sym + " (Yahoo rate-limit or no options); try again in a minute");
        if (!bars.valid || bars.bars.empty()) return err("price bars unavailable for " + sym + " (Yahoo rate-limit); try again in a minute");
        double atr = 0; size_t n = bars.bars.size(), w = std::min<size_t>(n, 14);
        if (w >= 2) {
            double sum = 0;
            for (size_t i = n - w + 1; i < n; ++i) {
                double h = bars.bars[i].high, l = bars.bars[i].low, pc = bars.bars[i - 1].close;
                sum += std::max({h - l, std::fabs(h - pc), std::fabs(l - pc)});
            }
            atr = sum / (double)(w - 1);
        }
        NodeSequenceConfig cfg;
        cfg.proximity_band_pct = a.value("band_pct", 10.0) / 100.0;
        cfg.min_risk_reward = a.value("min_rr", 2.0);
        GammaSurface s = computeGammaSurface(window(c, dte), c.spot, bars.closes(), atr, cfg);
        if (!s.valid) return err("no gamma nodes in the selected band");
        auto cell = [](const GammaCell& g) {
            return json{{"strike", g.strike}, {"dte", g.dte}, {"exp", g.expiration}, {"col", g.dte_column}, {"call_gex", g.call_gex},
                        {"put_gex", g.put_gex}, {"net_gex", g.net_gex}, {"call_oi", g.call_oi}, {"put_oi", g.put_oi},
                        {"call_vol", g.call_volume}, {"put_vol", g.put_volume}, {"type", nodeTypeLabel(g.node_type)},
                        {"score", g.node_score}, {"persistence", g.persistence_score}, {"confirmed", g.cross_dte_confirmed}, {"king", g.is_king}};
        };
        json cells = json::array();
        for (auto& g : s.cells) cells.push_back(cell(g));
        auto& q = s.active_sequence;
        json seq = {{"type", sequenceTypeLabel(q.sequence_type)}, {"state", entryStateLabel(q.state)},
                    {"direction", q.direction == TravelDirection::Up ? "UP" : q.direction == TravelDirection::Down ? "DOWN" : "FLAT"},
                    {"entry", q.entry_price}, {"invalidation", q.invalidation_price}, {"target", q.target_price},
                    {"rr", q.risk_reward}, {"confidence", q.confidence}};
        if (q.has_first) seq["first"] = cell(q.first_node);
        if (q.has_second) seq["second"] = cell(q.second_node);
        if (q.has_entry) seq["entry_node"] = cell(q.entry_node);
        return {{"ok", true}, {"symbol", sym}, {"spot", s.spot}, {"atr", atr}, {"dte_columns", s.dte_columns}, {"cells", cells},
                {"king", s.king ? cell(*s.king) : json(nullptr)}, {"king_strike", optD(s.king_strike)},
                {"king_dte_col", s.king_dte_column ? json(*s.king_dte_column) : json(nullptr)}, {"sequence", seq}};
    }
    if (method == "net_flow") {
        OptionChain c = fetchOptionChain(http(), sym, 45, 15);
        if (!c.valid) return err("option chain unavailable for " + sym);
        std::lock_guard<std::mutex> l(g_trk_m);
        auto& trk = g_flow[sym];
        if (a.value("reset", false)) trk.reset();
        trk.update(c, nowSeconds());
        NetFlowResult nf = computeNetFlow(c.rows);
        json b = json::array();
        for (auto& x : nf.buckets) b.push_back({{"label", x.label}, {"call_notional", x.call_notional}, {"put_notional", x.put_notional},
                                                {"call_volume", x.call_volume}, {"put_volume", x.put_volume}, {"net", x.net_notional}, {"cp_ratio", x.call_put_ratio}});
        json h = json::array();
        for (auto& s : trk.history()) h.push_back({{"t", s.t_seconds}, {"call", s.call_premium}, {"put", s.put_premium}, {"net", s.net_premium}, {"spot", s.spot}});
        return {{"ok", nf.valid}, {"symbol", sym}, {"spot", c.spot}, {"buckets", b}, {"bias", nf.bias},
                {"total_call", nf.total_call_notional}, {"total_put", nf.total_put_notional}, {"total_net", nf.total_net_notional},
                {"total_cp_ratio", nf.total_call_put_ratio}, {"history", h}};
    }
    if (method == "net_flow_plus") {
        OptionChain c = loadChain(sym, 15, 10);
        if (!c.valid) return err("option chain unavailable for " + sym);
        std::lock_guard<std::mutex> l(g_trk_m);
        auto& trk = g_flowp[sym];
        if (a.value("reset", false)) trk.reset();
        size_t fresh = trk.update(c, nowSeconds()).size();
        json ev = json::array();
        const auto& hist = trk.history();
        size_t cap = (size_t)a.value("limit", 300), start = hist.size() > cap ? hist.size() - cap : 0;
        for (size_t i = hist.size(); i-- > start;) {
            auto& e = hist[i];
            ev.push_back({{"id", e.id}, {"strike", e.strike}, {"exp", e.expiration}, {"dte", e.dte}, {"call", e.is_call}, {"size", e.volume_delta},
                          {"oi", e.open_interest}, {"price", e.last_price}, {"premium", e.net_premium}, {"gamma", e.gamma},
                          {"vega", e.vega}, {"iv", e.iv}, {"class", flowClassName(e.cls)}, {"t", e.timestamp}});
        }
        return {{"ok", true}, {"symbol", sym}, {"spot", c.spot}, {"events", ev}, {"new_events", fresh}, {"p99", trk.premium_p99()}};
    }
    if (method == "surface") {          // 3D Option Surface
        int dte = a.value("dte", 45);
        std::string m = a.value("metric", "volume");
        SurfaceMetric metric = m == "oi" ? SurfaceMetric::OpenInterest : m == "notional" ? SurfaceMetric::Notional
                             : m == "gamma" ? SurfaceMetric::Gamma : m == "gex" ? SurfaceMetric::Gex : SurfaceMetric::Volume;
        OptionChain c = loadChain(sym, 60, 20);
        if (!c.valid) return err("option chain unavailable for " + sym);
        auto rows = window(c, dte);
        if (rows.empty()) return err("no options within " + std::to_string(dte) + " DTE — widen Max DTE");
        int res = std::min(160, std::max(16, a.value("res", 40)));
        SurfaceGrid g = buildOptionSurface(rows, c.spot, metric, res);
        SurfaceMarkers mk = findSurfaceMarkers(rows, c.spot, metric);
        auto mj = [](const SurfaceMarker& s) { return json{{"valid", s.valid}, {"x", s.x}, {"y", s.y}, {"z", s.z}, {"strike", s.strike}, {"volume", s.volume}, {"oi", s.open_interest}}; };
        return {{"ok", g.valid}, {"symbol", sym}, {"spot", c.spot}, {"res", g.res}, {"x", g.x_strikes}, {"y", g.y_dte}, {"z", g.z},
                {"markers", {{"max_call", mj(mk.max_call)}, {"oi_call", mj(mk.oi_call)}, {"max_put", mj(mk.max_put)}, {"oi_put", mj(mk.oi_put)}}}};
    }
    if (method == "transports") {
        auto t = computeTransportsDivergence(http(), a.value("anchor", 2));
        return {{"ok", t.valid}, {"djt", jLadder(t.djt, true)}, {"oil", jLadder(t.oil, true)}, {"relationship", t.relationship},
                {"trade_direction", t.trade_direction}, {"confidence", t.confidence}, {"reasoning", t.reasoning}};
    }
    if (method == "desk_universe") {
        auto u = loadUniverse();
        return {{"ok", !u.empty()}, {"symbols", u}, {"error", u.empty() ? "sp500_symbols.txt not found in app bundle" : ""}};
    }
    if (method == "desk_start") {
        if (g_desk.running.load()) return err("scan already running");
        if (g_desk.coord.joinable()) g_desk.coord.join();
        std::vector<std::string> syms;
        if (a.contains("symbols")) for (auto& s : a["symbols"]) syms.push_back(upper(s.get<std::string>()));
        else syms = loadUniverse();
        if (syms.empty()) return err("no symbols to scan");
        { std::lock_guard<std::mutex> l(g_desk.m); g_desk.entries.clear(); g_desk.total = (int)syms.size(); g_desk.completed = 0;
          g_desk.started = (long long)std::time(nullptr); }
        g_desk.stop = false; g_desk.running = true;
        g_desk.coord = std::thread(deskCoordinator, syms, std::max(1, std::min(8, a.value("workers", 4))), a.value("pause_ms", 150));
        return {{"ok", true}, {"total", (int)syms.size()}};
    }
    if (method == "desk_stop") { g_desk.stop = true; return {{"ok", true}}; }
    if (method == "desk_state") {
        std::lock_guard<std::mutex> l(g_desk.m);
        json e = json::array();
        for (auto& x : g_desk.entries)
            e.push_back({{"symbol", x.symbol}, {"valid", x.valid}, {"price", x.price}, {"rsi", x.rsi}, {"ma_bias", x.ma_bias},
                         {"ma_conf", x.ma_conf}, {"ma_hard", x.ma_hard}, {"long_trigger", x.long_trigger},
                         {"mtf_signal", x.mtf_signal}, {"mtf_conf", x.mtf_conf}, {"mtf_buy", x.mtf_buy}});
        return {{"ok", true}, {"entries", e}, {"total", g_desk.total}, {"completed", g_desk.completed},
                {"running", g_desk.running.load()}, {"started", g_desk.started}};
    }
    return err("unknown method: " + method);
}

} // namespace

extern "C" void qe_set_asset_dir(const char* dir) { g_asset_dir = dir ? dir : ""; }

extern "C" char* qe_call(const char* method, const char* args_json) {
    json out;
    try {
        json a = (args_json && *args_json) ? json::parse(args_json) : json::object();
        if (!a.is_object()) a = json::object();
        out = dispatch(method ? method : "", a);
    } catch (const std::exception& e) {
        out = err(std::string("engine exception: ") + e.what());
    } catch (...) {
        out = err("unknown engine exception");
    }
    std::string s = out.dump(-1, ' ', false, json::error_handler_t::replace);
    char* p = (char*)std::malloc(s.size() + 1);
    std::memcpy(p, s.c_str(), s.size() + 1);
    return p;
}

extern "C" void qe_free(char* p) { std::free(p); }
extern "C" char* qe_alloc(unsigned long n) { return (char*)std::malloc(n); }
