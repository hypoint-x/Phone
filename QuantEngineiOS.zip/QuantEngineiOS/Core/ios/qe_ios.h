// qe_ios.h — the entire C surface Swift sees. Everything else is JSON in / JSON out.
#pragma once
#ifdef __cplusplus
extern "C" {
#endif

// Blocking HTTP GET provided by Swift (URLSession). Return the HTTP status (or -1 on transport
// failure). On return *body_out is a malloc()'d, NUL-terminated buffer (on failure: the error text).
// `headers` is "" or a single "Name: value" line.
typedef int (*qe_http_fn)(const char* url, const char* headers, char** body_out);

void  qe_set_http_transport(qe_http_fn fn);
void  qe_set_asset_dir(const char* dir);      // folder containing sp500_symbols.txt

// method + args_json -> result_json (always a JSON object; failures are {"ok":false,"error":"..."}).
// Caller releases the result with qe_free().
char* qe_call(const char* method, const char* args_json);
void  qe_free(char* p);

#ifdef __cplusplus
}
#endif
