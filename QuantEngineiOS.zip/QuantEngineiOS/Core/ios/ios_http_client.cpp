// iOS replacement for src/net/http_client.cpp (libcurl). Same public class, same Yahoo cookie+crumb
// lifecycle; the raw GET goes through the Swift-provided transport. Cookies live in URLSession's
// shared HTTPCookieStorage, so the handshake behaves exactly like the desktop curl cookie engine.
#include "qe/http_client.h"
#include "qe_ios.h"
#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <cstring>
#include <stdexcept>

namespace qe {
namespace { std::atomic<qe_http_fn> g_transport{nullptr}; }
void setHttpTransport(qe_http_fn fn) { g_transport.store(fn); }
}

extern "C" void qe_set_http_transport(qe_http_fn fn) { qe::setHttpTransport(fn); }

namespace qe {

struct HttpClient::Impl { int unused = 0; };

HttpClient::HttpClient() : impl_(new Impl()) {}
HttpClient::~HttpClient() { delete impl_; }

HttpResponse HttpClient::get(const std::string& url, const std::string& extra_headers) {
    HttpResponse resp;
    qe_http_fn fn = g_transport.load();
    if (!fn) { resp.status_code = -1; resp.body = "no HTTP transport installed"; return resp; }
    char* body = nullptr;
    int status = fn(url.c_str(), extra_headers.c_str(), &body);
    resp.status_code = status;
    if (body) { resp.body.assign(body); std::free(body); }
    return resp;
}

bool HttpClient::sessionStale() const {
    if (!session_valid_) return true;
    return (std::chrono::steady_clock::now() - crumb_fetched_at_) > std::chrono::minutes(50);
}

void HttpClient::invalidateSession() {
    std::lock_guard<std::recursive_mutex> lock(session_mtx_);
    session_valid_ = false;
    crumb_.clear();
}

bool HttpClient::ensureSession() {
    std::lock_guard<std::recursive_mutex> lock(session_mtx_);
    if (!sessionStale()) return true;
    (void)get("https://fc.yahoo.com"); // picks up session cookies
    HttpResponse r = get("https://query1.finance.yahoo.com/v1/test/getcrumb");
    if (!r.ok() || r.body.empty() || r.body.find("Too Many Requests") != std::string::npos) {
        session_valid_ = false; return false;
    }
    std::string crumb = r.body;
    crumb.erase(std::remove(crumb.begin(), crumb.end(), '\n'), crumb.end());
    crumb.erase(std::remove(crumb.begin(), crumb.end(), '\r'), crumb.end());
    if (crumb.empty() || crumb.find('{') != std::string::npos || crumb.find('<') != std::string::npos) {
        session_valid_ = false; return false;
    }
    crumb_ = crumb;
    crumb_fetched_at_ = std::chrono::steady_clock::now();
    session_valid_ = true;
    return true;
}

static std::string urlEscape(const std::string& s) {
    static const char* hex = "0123456789ABCDEF";
    std::string o;
    for (unsigned char c : s) {
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
        else { o += '%'; o += hex[c >> 4]; o += hex[c & 15]; }
    }
    return o;
}

HttpResponse HttpClient::getYahoo(const std::string& url) {
    std::lock_guard<std::recursive_mutex> lock(session_mtx_);
    bool have = ensureSession();
    std::string final_url = url;
    if (have && !crumb_.empty()) {
        final_url += (url.find('?') == std::string::npos ? "?" : "&");
        final_url += "crumb=" + urlEscape(crumb_);
    }
    HttpResponse resp = get(final_url);
    if (resp.status_code == 401) {
        session_valid_ = false;
        if (ensureSession()) resp = get(final_url);
    }
    return resp;
}

nlohmann::json HttpClient::getYahooJson(const std::string& url) {
    HttpResponse resp = getYahoo(url);
    if (!resp.ok() || resp.body.empty()) {
        std::string detail = (resp.status_code == -1 && !resp.body.empty()) ? " (" + resp.body + ")" : "";
        throw std::runtime_error("Yahoo request failed, status=" + std::to_string(resp.status_code) + detail);
    }
    return nlohmann::json::parse(resp.body);
}

} // namespace qe
