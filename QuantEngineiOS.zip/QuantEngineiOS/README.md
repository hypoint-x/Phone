# Quant Engine for iPhone

A native iPhone/iPad app built on a **shared C++ core**: the same engines as the Windows app
(MA Ladder, MTF, Chart+, GEX, Gamma Node Sequencer, Net Flow, …) compiled into the app, with a SwiftUI front end.
The desktop's Dear ImGui / OpenGL / Win32 UI can't run on iOS, so the screens are new; the maths is not.

## Build (needs a Mac with Xcode 15+)
```bash
brew install xcodegen
xcodegen generate            # creates QuantEngine.xcodeproj from project.yml
open QuantEngine.xcodeproj   # pick your Team under Signing, choose an iPhone, Run
```
No Mac? Push this folder to GitHub: `.github/workflows/ios.yml` builds it on a macOS runner (host smoke test + unsigned simulator build).

## Install on your iPhone without a Mac (from Windows)
1. Create a free GitHub account, make a new repo, upload this folder's contents, and open the **Actions** tab. The "Build iPhone app (.ipa)" workflow runs on a macOS server (a few minutes). Click the finished run and download the **QuantEngine-unsigned-ipa** artifact; unzip it to get `QuantEngine-unsigned.ipa`.
2. Install **Sideloadly** (sideloadly.io) on Windows, plug in the iPhone, drag the .ipa in, sign in with your Apple ID. It re-signs and installs the app. (AltStore works too.)
3. On the iPhone: Settings > General > VPN & Device Management > trust your Apple ID; on iOS 16+ also enable Developer Mode.
A free Apple ID's apps expire after 7 days (re-sideload); a paid developer account ($99/yr) lasts a year.
If the build fails, the Actions log shows the compile errors (the SwiftUI code has never been compiled; see Honest limits). Paste them to me and I'll fix them.

## What's in it
| Screen | Desktop engine reused |
|---|---|
| Quant Desk (scan table: Symbol · **Price** · MA · MTF · **RSI**) | `computeMaLadderConfluence` + `computeMtfBias` over `sp500_symbols.txt` (524 tickers), 1–8 workers |
| Quant Engine (any stock) | `computeQuantEngineSnapshot` + `UniversalSettlementEngine` |
| Quant Tool (intensity cloud) | `computeIntensityCloud` |
| Gamma Node Sequencer | `computeGammaSurface` |
| Strike Heatmap | `computeStrikeHeatmap` |
| GEX | `computeGexLevelsPro` + `computeGexByStrike` (OI / volume) |
| Chart+ | `computeSpyEmaChart` |
| MA Ladder, MTF | `computeMaLadderConfluence`, `computeMtfBias` |
| Net Flow, Net Flow+ | `computeNetFlow`, `NetFlowTracker`, `NetFlowPlusTracker` |
| 3D Options | `buildOptionSurface` + `findSurfaceMarkers` → SceneKit mesh |
| Transport Divergence | `computeTransportsDivergence` |

## Layout
- `Core/` — engines copied from the desktop source (unchanged except where noted), `Core/ios/qe_ios.cpp` JSON bridge, `Core/ios/ios_http_client.cpp` (libcurl replaced by URLSession through one C callback; same Yahoo cookie+crumb logic).
- `App/` — SwiftUI app. Swift never touches engine structs: it calls `qe_call("method", json)` and reads JSON.
- `Tests/linux_smoke.cpp` — runs every bridge method end to end (see below).
- `tools/sync_core.py <desktop source dir>` — re-copies engines when the desktop code changes.

## Differences from desktop
- The only engine edit: GEX's llama.cpp **narrator** is cut out (the level maths is untouched).
- **Price and RSI columns in the scan table**: RSI is RSI(14) on the MA Ladder's anchor timeframe (1h); Price is that chart's last close. The desktop source I was given had no such columns on the desk, so this is my reading of your request, easy to change in `deskWorker` (qe_ios.cpp).
- Net Flow / Net Flow+ only accumulate while their screen is open (iOS doesn't run it in the background).
- Not ported (desktop-only by nature): Auto Assist, ViRP/YOLO, DirectX input tools, the local-LLM agents, globe, Arduino/AgenticWork tools.

## Honest limits
- Data comes from **Yahoo's unofficial endpoints** (same as desktop): can rate-limit or change. A full desk scan is thousands of requests (minutes). Fine for personal use / TestFlight; not something to ship to the App Store as-is.
- Verified here (Linux, no Xcode): C++ core builds with gcc, clang+libstdc++ and clang+libc++ (Apple's STL); smoke test passes under ASan/UBSan/TSan against a *synthetic* Yahoo; all Swift files pass `swiftc -parse`; `J.swift` compiled and tested against real bridge output; every JSON key the Swift reads was cross-checked against the bridge.
- **Not verified:** SwiftUI/Charts/SceneKit code has not been compiled (those frameworks only exist on Apple platforms) and nothing has been run against live Yahoo or on a device. Expect to fix a few compile errors on first build.
