#!/usr/bin/env python3
"""Copy the portable engines from the desktop source tree into Core/.

Usage: python3 tools/sync_core.py /path/to/quant_engine_source   (the folder holding include/ src/ assets/ third_party/)

Only pure-computation engines are copied. Three things differ from desktop:
  * net/http_client.cpp (libcurl) is NOT copied -> Core/ios/ios_http_client.cpp routes through URLSession.
  * gex_levels_pro: the LLM narrator (llama.cpp) is cut out; the level maths is untouched.
  * assets/sp500_symbols.txt is bundled into the app as a resource.
"""
import os, re, shutil, sys

src = sys.argv[1]
here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
core = os.path.join(here, "Core")

ENGINES = """composite_engine dealer_positioning option_greeks option_surface strike_heatmap intensity_cloud
mtf_engine spy_ema_chart_engine spy_ema_signal ma_ladder_engine transports_divergence_engine gex_by_strike
gex_levels_pro net_flow_engine net_flow_plus_engine gamma_node_sequencer quant_engine sp500_liquidity_engine
markov_engine spy_settlement_engine universal_settlement_engine""".split()
HEADERS_EXTRA = ["http_client","yahoo_endpoints","black_scholes","session_clock","stats","engine_cache"]

for d in ("include/qe", "src/engines", "src/net", "include/nlohmann", "assets"):
    os.makedirs(os.path.join(core, d), exist_ok=True)

for e in ENGINES:
    shutil.copy(os.path.join(src, "src/engines", e + ".cpp"), os.path.join(core, "src/engines", e + ".cpp"))
    shutil.copy(os.path.join(src, "include/qe", e + ".h"), os.path.join(core, "include/qe", e + ".h"))
for h in HEADERS_EXTRA:
    p = os.path.join(src, "include/qe", h + ".h")
    if os.path.exists(p): shutil.copy(p, os.path.join(core, "include/qe", h + ".h"))
shutil.copy(os.path.join(src, "src/net/yahoo_endpoints.cpp"), os.path.join(core, "src/net/yahoo_endpoints.cpp"))
shutil.copytree(os.path.join(src, "third_party/nlohmann_json/include/nlohmann"),
                os.path.join(core, "include/nlohmann"), dirs_exist_ok=True)
shutil.copy(os.path.join(src, "assets/sp500_symbols.txt"), os.path.join(core, "assets/sp500_symbols.txt"))

# ---- gex_levels_pro: strip the llama.cpp narrator --------------------------
h = os.path.join(core, "include/qe/gex_levels_pro.h")
t = open(h).read()
t = t.replace('#include "qe/multi_agent_orchestrator.h" // SharedLlmModel, PipelineAgent\n', '')
t = re.sub(r'class GexLevelsNarrator \{.*?\n\};\n', '', t, flags=re.S)
open(h, "w").write(t)
c = os.path.join(core, "src/engines/gex_levels_pro.cpp")
t = open(c).read()
i = t.index("GexLevelsNarrator::GexLevelsNarrator()")
# back up to the comment block/blank line preceding it
j = t.rfind("\n\n", 0, i)
t = t[:j] + "\n\n} // namespace qe\n"
open(c, "w").write(t)
print("synced into", core)
