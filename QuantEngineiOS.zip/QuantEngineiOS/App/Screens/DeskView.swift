import SwiftUI

/// Quant Desk — scans the S&P 500 + extras universe (MA Ladder + MTF per symbol) with the same engines as the desktop desk.
/// Columns: SYMBOL · PRICE · MA bias/conf · MTF signal/conf · RSI.
struct DeskView: View {
    @EnvironmentObject var app: AppState

    struct Row: Identifiable {
        let id: String
        let symbol: String
        let valid: Bool
        let price: Double, rsi: Double
        let maBias: String, maHard: String, mtfSignal: String, mtfBuy: String
        let maConf: Int, mtfConf: Int
        let trigger: Bool
    }
    enum Sort: String, CaseIterable { case maConf = "MA conf", mtfConf = "MTF conf", rsi = "RSI", symbol = "A–Z" }
    enum Filter: String, CaseIterable { case all = "All", bull = "Bull", bear = "Bear", trigger = "Long trigger" }

    @State private var rows: [Row] = []
    @State private var total = 0
    @State private var completed = 0
    @State private var running = false
    @State private var error: String?
    @State private var sort: Sort = .maConf
    @State private var filter: Filter = .all
    @State private var query = ""
    @State private var workers = 4
    @State private var poller: Task<Void, Never>?

    private var shown: [Row] {
        var r = rows.filter { $0.valid }
        if !query.isEmpty { r = r.filter { $0.symbol.contains(query.uppercased()) } }
        switch filter {
        case .all: break
        case .bull: r = r.filter { $0.maBias == "BULL" || $0.mtfSignal == "BULLISH" }
        case .bear: r = r.filter { $0.maBias == "BEAR" || $0.mtfSignal == "BEARISH" }
        case .trigger: r = r.filter { $0.trigger }
        }
        switch sort {
        case .maConf: r.sort { $0.maConf > $1.maConf }
        case .mtfConf: r.sort { $0.mtfConf > $1.mtfConf }
        case .rsi: r.sort { $0.rsi > $1.rsi }
        case .symbol: r.sort { $0.symbol < $1.symbol }
        }
        return r
    }

    var body: some View {
        VStack(spacing: 0) {
            controls.padding(.horizontal, 16).padding(.bottom, 8)
            header
            List {
                ForEach(shown) { r in
                    NavigationLink(destination: MALadderView()) { rowView(r) }
                        .simultaneousGesture(TapGesture().onEnded { app.set(r.symbol) })
                        .listRowInsets(EdgeInsets(top: 6, leading: 12, bottom: 6, trailing: 8))
                }
                if shown.isEmpty && !running {
                    Text(rows.isEmpty ? "Tap Start to scan the universe." : "No symbols match the filter.")
                        .foregroundStyle(.secondary).font(.footnote)
                }
            }
            .listStyle(.plain)
        }
        .navigationTitle("Quant Desk").navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .automatic), prompt: "Filter symbol")
        .onAppear { Task { await refresh() } }
        .onDisappear { poller?.cancel() }
    }

    private var controls: some View {
        VStack(spacing: 8) {
            HStack {
                Button {
                    if running { stop() } else { Task { await start() } }
                } label: {
                    Label(running ? "Stop" : "Start scan", systemImage: running ? "stop.fill" : "play.fill")
                        .frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent).tint(running ? Theme.bear : Theme.accent)
                Stepper("", value: $workers, in: 1...8).labelsHidden().disabled(running)
                Text("\(workers)×").font(.caption).foregroundStyle(.secondary)
            }
            if total > 0 {
                ProgressView(value: Double(completed), total: Double(max(total, 1)))
                HStack {
                    Text("\(completed)/\(total) scanned").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Text("\(shown.count) shown").font(.caption).foregroundStyle(.secondary)
                }
            }
            if let error { Text(error).font(.footnote).foregroundStyle(Theme.warn) }
            Picker("Filter", selection: $filter) { ForEach(Filter.allCases, id: \.self) { Text($0.rawValue).tag($0) } }
                .pickerStyle(.segmented)
            HStack {
                Text("Sort").font(.caption).foregroundStyle(.secondary)
                Picker("Sort", selection: $sort) { ForEach(Sort.allCases, id: \.self) { Text($0.rawValue).tag($0) } }
                    .pickerStyle(.segmented)
            }
            Text("A full scan is thousands of Yahoo requests and takes minutes. Results fill in live; partial data is usable any time.")
                .font(.caption2).foregroundStyle(.tertiary)
        }
    }

    private var header: some View {
        HStack(spacing: 6) {
            Text("SYMBOL").frame(width: 54, alignment: .leading)
            Text("PRICE").frame(width: 64, alignment: .trailing)
            Text("MA").frame(width: 62, alignment: .leading)
            Text("MTF").frame(width: 62, alignment: .leading)
            Text("RSI").frame(width: 36, alignment: .trailing)
            Spacer(minLength: 0)
        }
        .font(.system(size: 10, weight: .bold)).foregroundStyle(.secondary)
        .padding(.horizontal, 12).padding(.vertical, 6).background(Color(.tertiarySystemBackground))
    }

    private func rowView(_ r: Row) -> some View {
        HStack(spacing: 6) {
            Text(r.symbol).font(.system(.subheadline, design: .monospaced).weight(.bold)).frame(width: 54, alignment: .leading)
            Text(Fmt.price(r.price)).font(.system(.footnote, design: .monospaced)).frame(width: 64, alignment: .trailing)
            VStack(alignment: .leading, spacing: 1) {
                Text(r.maBias).font(.system(size: 11, weight: .bold)).foregroundStyle(Theme.bias(r.maBias))
                Text("\(r.maConf)\(r.trigger ? " ▲" : "")").font(.system(size: 10)).foregroundStyle(.secondary)
            }.frame(width: 62, alignment: .leading)
            VStack(alignment: .leading, spacing: 1) {
                Text(r.mtfSignal).font(.system(size: 11, weight: .bold)).foregroundStyle(Theme.bias(r.mtfSignal)).lineLimit(1).minimumScaleFactor(0.7)
                Text("\(r.mtfConf) · \(r.mtfBuy)").font(.system(size: 10)).foregroundStyle(.secondary).lineLimit(1)
            }.frame(width: 62, alignment: .leading)
            Text(String(format: "%.0f", r.rsi))
                .font(.system(.footnote, design: .monospaced).weight(.semibold))
                .foregroundStyle(r.rsi >= 70 ? Theme.bear : (r.rsi <= 30 ? Theme.bull : .primary))
                .frame(width: 36, alignment: .trailing)
            Spacer(minLength: 0)
        }
    }

    // MARK: engine plumbing
    private func start() async {
        error = nil
        let r = await Engine.shared.call("desk_start", ["workers": workers, "pause_ms": 150])
        if r["ok"].bool { running = true; total = r["total"].int; completed = 0; rows = []; beginPolling() }
        else { error = r["error"].string }
    }
    private func stop() {
        Task { _ = await Engine.shared.call("desk_stop") }
    }
    private func beginPolling() {
        poller?.cancel()
        poller = Task {
            while !Task.isCancelled {
                await refresh()
                if !running { break }
                try? await Task.sleep(nanoseconds: 1_200_000_000)
            }
        }
    }
    private func refresh() async {
        let s = await Engine.shared.call("desk_state")
        guard s["ok"].bool else { return }
        total = s["total"].int; completed = s["completed"].int
        let was = running
        running = s["running"].bool
        rows = s["entries"].array.map { e in
            Row(id: e["symbol"].string, symbol: e["symbol"].string, valid: e["valid"].bool,
                price: e["price"].d(), rsi: e["rsi"].d(50), maBias: e["ma_bias"].string, maHard: e["ma_hard"].string,
                mtfSignal: e["mtf_signal"].string, mtfBuy: e["mtf_buy"].string,
                maConf: e["ma_conf"].int, mtfConf: e["mtf_conf"].int, trigger: e["long_trigger"].bool)
        }
        if running && !was { beginPolling() }
    }
}
