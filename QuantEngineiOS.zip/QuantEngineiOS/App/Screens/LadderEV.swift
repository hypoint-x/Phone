import SwiftUI

/// Codex data (bundled ladder_codex.json): BEAR/BULL EV-optimized rows by 8-bit state x confidence band, plus the NEUTRAL codex.
/// EV figures are assumption-based priors from the supplied codex files, NOT backtested results.
enum LadderCodex {
    static let bitNames = ["Hard", "Soft", "Pullback", "Support", "VWAP", "OBV", "Keltner", "StochRSI"]
    static let bandLabels = ["10-30", "40-60", "70-90"]
    static let bandNames = ["Low", "Mid", "High"]

    static let data: J = {
        guard let url = Bundle.main.url(forResource: "ladder_codex", withExtension: "json"),
              let d = try? Data(contentsOf: url),
              let o = try? JSONSerialization.jsonObject(with: d) else { return J(nil) }
        return J(o)
    }()

    static func bits(_ state: String) -> [String] {
        let chars = Array(state)
        var out: [String] = []
        for i in 0..<min(chars.count, bitNames.count) where chars[i] == "1" { out.append(bitNames[i]) }
        return out
    }

    /// The codex row for a state read; `neutral` rows are one-per-state (no confidence bands).
    static func row(state: String, biasName: String, band: Int) -> (row: J, neutral: Bool, indicators: String)? {
        if biasName == "NEUTRAL" {
            let n = data["ne"][state]
            if n.exists { return (row: n, neutral: true, indicators: n["i"].string) }
            return nil
        }
        let st = data["bb"][state]
        let b = max(0, min(2, band))
        let r = st[biasName][bandLabels[b]]
        if r.exists { return (row: r, neutral: false, indicators: st["i"].string) }
        return nil
    }

    static func tierColor(_ t: String) -> Color {
        switch t { case "A": return Theme.bull; case "B": return Theme.accent; case "C": return Theme.warn; case "X": return Theme.bear; default: return .secondary }
    }
    static func signed(_ v: Double, _ digits: Int = 3) -> String { v.isFinite ? String(format: "%+.\(digits)f", v) : "–" }
}

/// One codex line: interpretation, rule, optimized action, risk and EV figures.
struct CodexDetail: View {
    let found: (row: J, neutral: Bool, indicators: String)?
    let state: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let f = found {
                let r = f.row
                HStack {
                    Text(state).font(.system(.subheadline, design: .monospaced).weight(.semibold))
                    Text(f.indicators.isEmpty ? "Absolute Zero" : f.indicators).font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    if !f.neutral, r["t"].string != "-", !r["t"].string.isEmpty {
                        Pill(text: "Tier \(r["t"].string)", color: LadderCodex.tierColor(r["t"].string))
                    }
                }
                Text(r["in"].string).font(.footnote)
                Text("Rule: \(r["ta"].string)").font(.footnote)
                if !f.neutral {
                    Text("Optimized: \(r["oa"].string)").font(.footnote)
                    if !r["co"].string.isEmpty { Text("Counter: \(r["co"].string)").font(.footnote).foregroundStyle(.secondary) }
                }
                if r["W"].exists {
                    HStack {
                        StatTile(label: "P(win)", value: r["p"].exists ? String(format: "%.1f%%", r["p"].d() * 100) : "–")
                        StatTile(label: "W", value: String(format: "%.1fR", r["W"].d()))
                        if f.neutral { StatTile(label: "Size", value: r["sz"].string.isEmpty ? "–" : r["sz"].string) }
                        else { StatTile(label: "Risk", value: String(format: "%.2f%%", r["rk"].d())) }
                        StatTile(label: "EV sized", value: LadderCodex.signed(r["es"].d()), color: r["es"].d() > 0 ? Theme.bull : r["es"].d() < 0 ? Theme.bear : .primary)
                        if !f.neutral { StatTile(label: "Stress EV", value: LadderCodex.signed(r["se"].d()), color: r["se"].d() > 0 ? Theme.bull : r["se"].d() < 0 ? Theme.bear : .primary) }
                    }
                } else {
                    Text("No trade (EV 0).").font(.caption).foregroundStyle(.secondary)
                }
            } else {
                Text("State \(state) has no row in the supplied codex files (54 of 256 states are uncovered), so it adds no score.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(10)
        .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

private struct IndexGauge: View {
    let value: Double
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(LinearGradient(colors: [Theme.bear, Color.gray.opacity(0.35), Theme.bull], startPoint: .leading, endPoint: .trailing))
                    .frame(height: 10)
                Rectangle().fill(Color.white).frame(width: 4, height: 16)
                    .offset(x: g.size.width * CGFloat((min(max(value, -100), 100) + 100) / 200) - 2)
            }
            .frame(height: 16)
        }
        .frame(height: 16)
    }
}

/// Moving Averages Ladder Bullish / Bearish indicator: 5m + 15m + 1h codex states blended 20/35/45.
struct BullishCard: View {
    @EnvironmentObject var app: AppState
    var title: String = "Bullish / Bearish indicator"
    @State private var res: J? = nil
    @State private var err: String? = nil
    @State private var open: Set<Int> = []

    var body: some View {
        Card(title: title) {
            if let b = res {
                content(b)
            } else if let e = err {
                Label(e, systemImage: "exclamationmark.triangle").foregroundStyle(Theme.warn).font(.footnote)
            } else {
                ProgressView()
            }
        }
        .task(id: app.symbol) {
            while !Task.isCancelled {
                await load()
                try? await Task.sleep(nanoseconds: 60 * 1_000_000_000)
            }
        }
    }

    @MainActor private func load() async {
        let r = await Engine.shared.call("bullish", ["symbol": app.symbol])
        if r["ok"].bool { res = r; err = nil }
        else if res == nil { err = r["error"].exists ? r["error"].string : "Indicator unavailable right now." }
    }

    @ViewBuilder private func content(_ b: J) -> some View {
        let idx = b["index"].d()
        let stance = b["stance"].string
        HStack(alignment: .firstTextBaseline) {
            Text(String(format: "%+.0f", idx)).font(.system(size: 34, weight: .bold, design: .rounded))
                .foregroundStyle(idx > 0 ? Theme.bull : idx < 0 ? Theme.bear : Color.primary)
            Text("/ ±100").font(.caption).foregroundStyle(.secondary)
            Spacer()
            Pill(text: stance, color: stance.contains("BULL") ? Theme.bull : stance.contains("BEAR") ? Theme.bear : Theme.warn)
        }
        IndexGauge(value: idx)
        HStack {
            Text("bearish"); Spacer(); Text("neutral"); Spacer(); Text("bullish")
        }.font(.caption2).foregroundStyle(.secondary)
        HStack {
            StatTile(label: "Entry timer (5m)", value: b["entry_ready"].bool ? "READY" : (b["trigger_5m"].bool ? "fires, no stance" : "waiting"),
                     color: b["entry_ready"].bool ? Theme.bull : .primary)
            StatTile(label: "Suggested size", value: b["entry_ready"].bool ? String(format: "%.2fx", b["size"].d()) : "–")
            StatTile(label: "Coverage", value: String(format: "%.0f%%", b["coverage"].d() * 100), color: b["coverage"].d() < 0.999 ? Theme.warn : .primary)
        }
        ForEach(b["tf"].array.indices, id: \.self) { i in
            tfRow(b["tf"][i], i)
        }
        Text("Blend: 1h 45% + 15m 35% + 5m 20%. Tap a row for its codex line. EV values are assumption-based priors from your codex files, not backtested results; uncovered states and NEUTRAL bias add no score.")
            .font(.caption2).foregroundStyle(.secondary)
    }

    @ViewBuilder private func tfRow(_ t: J, _ i: Int) -> some View {
        let biasName = t["bias_name"].string
        let state = t["state"].string
        let band = t["band"].int
        let dir = t["dir"].int
        VStack(alignment: .leading, spacing: 4) {
            Button {
                if open.contains(i) { open.remove(i) } else { open.insert(i) }
            } label: {
                HStack(spacing: 6) {
                    Text(t["tf"].string).font(.subheadline.weight(.semibold)).frame(width: 34, alignment: .leading)
                    Text(state).font(.system(.caption, design: .monospaced))
                    Pill(text: "\(biasName) \(t["confidence"].int)%", color: Theme.bias(biasName))
                    if biasName == "NEUTRAL" { Pill(text: "NEUTRAL") }
                    else if !t["covered"].bool { Pill(text: "no codex row") }
                    else if dir > 0 { Pill(text: "LONG", color: Theme.bull) }
                    else if dir < 0 { Pill(text: "SHORT", color: Theme.bear) }
                    else { Pill(text: "stand aside") }
                    Spacer()
                    Text(t["covered"].bool && t["bias"].int != 0 ? LadderCodex.signed(t["ev_sized"].d()) + "R" : "–")
                        .font(.subheadline.monospacedDigit().weight(.semibold))
                        .foregroundStyle(t["score"].d() > 0 ? Theme.bull : t["score"].d() < 0 ? Theme.bear : Color.primary)
                }
            }.buttonStyle(.plain)
            let names = LadderCodex.bits(state)
            Text("\(names.isEmpty ? "no confirmations" : names.joined(separator: " · ")) · band \(LadderCodex.bandNames[max(0, min(2, band))]) (\(LadderCodex.bandLabels[max(0, min(2, band))]))\(t["confirm_first"].bool ? " · confirm first" : "")")
                .font(.caption2).foregroundStyle(.secondary)
            if open.contains(i) {
                CodexDetail(found: LadderCodex.row(state: state, biasName: biasName, band: band), state: state)
            }
        }
        .padding(.top, 4)
    }
}

/// Reference browser: switch the 8 indicators on/off, pick a bias, read the codex rows.
struct CodexBrowser: View {
    @State private var bits: [Bool] = [false, true, true, true, true, true, true, true]
    @State private var bias = "BULL"
    @State private var expanded = false

    private var state: String { bits.map { $0 ? "1" : "0" }.joined() }

    private var top: [(String, String, String, Double)] {
        guard let bb = LadderCodex.data["bb"].raw as? [String: Any] else { return [] }
        var out: [(String, String, String, Double)] = []
        for (st, v) in bb {
            let vj = J(v)
            for bs in ["BULL", "BEAR"] {
                let r = vj[bs]["70-90"]
                if r["t"].string == "A" { out.append((st, bs, vj["i"].string, r["es"].d())) }
            }
        }
        out.sort { $0.3 != $1.3 ? $0.3 > $1.3 : $0.0 < $1.0 }
        return Array(out.prefix(8))
    }

    var body: some View {
        Card {
            DisclosureGroup(isExpanded: $expanded) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Pick the switches that are on and a bias. Rows come from your Phase 1–8 codex with the EV-optimized layer (action, risk size, tier, stress test). Assumption-based priors, not backtested.")
                        .font(.caption).foregroundStyle(.secondary)
                    FlowLayout {
                        ForEach(0..<8, id: \.self) { i in
                            Button { bits[i].toggle() } label: {
                                Text(LadderCodex.bitNames[i]).font(.caption.weight(.semibold))
                                    .padding(.horizontal, 10).padding(.vertical, 5)
                                    .background(bits[i] ? Theme.accent : Theme.card, in: Capsule())
                                    .foregroundStyle(bits[i] ? Color.white : Color.primary)
                            }.buttonStyle(.plain)
                        }
                    }
                    Picker("Bias", selection: $bias) {
                        Text("Bull").tag("BULL"); Text("Bear").tag("BEAR"); Text("Neutral").tag("NEUTRAL")
                    }.pickerStyle(.segmented)
                    if bias == "NEUTRAL" {
                        CodexDetail(found: LadderCodex.row(state: state, biasName: "NEUTRAL", band: 0), state: state)
                    } else {
                        ForEach(0..<3, id: \.self) { b in
                            Text("\(LadderCodex.bandNames[b]) confidence (\(LadderCodex.bandLabels[b]))").font(.caption.weight(.semibold))
                            CodexDetail(found: LadderCodex.row(state: state, biasName: bias, band: b), state: state)
                        }
                    }
                    Text("Top setups (tier A, high confidence)").font(.caption.weight(.semibold)).padding(.top, 4)
                    ForEach(0..<top.count, id: \.self) { i in
                        let x = top[i]
                        HStack {
                            Text(x.0).font(.system(.caption, design: .monospaced))
                            Pill(text: x.1, color: Theme.bias(x.1))
                            Text(x.2).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                            Spacer()
                            Text(LadderCodex.signed(x.3) + "R").font(.caption.monospacedDigit().weight(.semibold)).foregroundStyle(Theme.bull)
                        }
                    }
                }.padding(.top, 8)
            } label: {
                Text("EV codex · all 256 states").font(.subheadline.weight(.semibold))
            }
        }
    }
}
