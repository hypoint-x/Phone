import SwiftUI
import Charts

/// Quant Engine — All Stocks: 3:30 settlement forecast (Markov + Black-Scholes + fib + regression) and VWAP/GEX breakout snapshot for any ticker.
struct QuantEngineView: View {
    var body: some View {
        ToolScreen(title: "Quant Engine", method: "quant_engine") { d in
            let f = d["forecast"], s = d["snapshot"]
            if f["available"].bool { forecast(f) } else if f["error"].string.count > 0 {
                Card { Label(f["error"].string, systemImage: "exclamationmark.triangle").foregroundStyle(Theme.warn).font(.footnote) }
            }
            if s["valid"].bool { snapshot(s) }
        }
    }

    private func forecast(_ f: J) -> some View {
        VStack(spacing: 12) {
            Card(title: "Settlement forecast") {
                HStack {
                    Text(f["direction"].string).font(.title2.weight(.bold)).foregroundStyle(Theme.bias(f["direction"].string))
                    Spacer()
                    Text("confidence \(Fmt.num(f["confidence"].d() * 100, 0))%").font(.subheadline).foregroundStyle(.secondary)
                }
                HStack {
                    StatTile(label: "Current", value: Fmt.price(f["price_current"].d()))
                    StatTile(label: "Projected 3:30", value: Fmt.price(f["projected_330"].d()))
                    StatTile(label: "Final score", value: Fmt.num(f["final_score"].d(), 2))
                }
                probBar(up: f["p_up"].d(), neutral: f["p_neutral"].d(), down: f["p_down"].d())
                HStack {
                    StatTile(label: "State", value: f["current_state"].string, color: Theme.bias(f["current_state"].string))
                    StatTile(label: "Predicted", value: f["predicted_state"].string, color: Theme.bias(f["predicted_state"].string))
                    StatTile(label: "Morning chg", value: Fmt.pct(f["morning_change_pct"].d()))
                }
            }
            if f["chart_values"].count > 1 {
                Card(title: "Intraday path") {
                    let v = f["chart_values"].doubles
                    Chart { ForEach(v.indices, id: \.self) { i in
                        if v[i].isFinite { LineMark(x: .value("i", i), y: .value("px", v[i])).foregroundStyle(Theme.accent) } } }
                        .chartYScale(domain: (v.filter { $0.isFinite }.min() ?? 0)...(v.filter { $0.isFinite }.max() ?? 1))
                        .frame(height: 140)
                }
            }
            Card(title: "Expected value & greeks") {
                KeyValueRow(key: "EV", value: Fmt.num(f["ev"].d(), 3), color: f["ev"].d() >= 0 ? Theme.bull : Theme.bear)
                Text(f["ev_text"].string).font(.footnote).foregroundStyle(.secondary)
                KeyValueRow(key: "Delta", value: Fmt.num(f["delta"].d(), 3))
                KeyValueRow(key: "Gamma", value: Fmt.num(f["gamma"].d(), 4))
                KeyValueRow(key: "Vega", value: Fmt.num(f["vega"].d(), 3))
                KeyValueRow(key: "Theta", value: Fmt.num(f["theta"].d(), 3))
                KeyValueRow(key: "Gamma bias", value: f["gamma_bias"].string)
                Text(f["bs_text"].string).font(.footnote).foregroundStyle(.secondary)
            }
            Card(title: "Structure") {
                KeyValueRow(key: "Dealer GEX", value: Fmt.big(f["dealer_gamma"].d()))
                KeyValueRow(key: "Gamma flip", value: Fmt.opt(f["gamma_flip"]))
                KeyValueRow(key: "Implied vol", value: Fmt.pct(f["iv"].d() * 100, digits: 1))
                KeyValueRow(key: "Nearest fib", value: "\(f["fib_nearest_label"].string)  \(Fmt.price(f["fib_nearest"].d()))")
                KeyValueRow(key: "Regression slope / R²", value: "\(Fmt.num(f["slope"].d(), 3)) / \(Fmt.num(f["r2"].d(), 2))")
                KeyValueRow(key: "Settlement bias", value: f["settlement_bias"].string, color: Theme.bias(f["settlement_bias"].string))
            }
        }
    }

    private func snapshot(_ s: J) -> some View {
        Card(title: "VWAP & breakout") {
            HStack {
                Text(s["signal"].string).font(.headline).foregroundStyle(Theme.bias(s["signal"].string))
                Spacer()
                Text("spot \(Fmt.price(s["spot"].d()))").font(.subheadline).foregroundStyle(.secondary)
            }
            probBar(up: s["prob_up"].d(), neutral: 0, down: s["prob_down"].d())
            if s["vwap"]["valid"].bool {
                HStack {
                    StatTile(label: "−2σ", value: Fmt.price(s["vwap"]["l2"].d()))
                    StatTile(label: "−1σ", value: Fmt.price(s["vwap"]["l1"].d()))
                    StatTile(label: "VWAP", value: Fmt.price(s["vwap"]["vwap"].d()), color: .yellow)
                    StatTile(label: "+1σ", value: Fmt.price(s["vwap"]["u1"].d()))
                    StatTile(label: "+2σ", value: Fmt.price(s["vwap"]["u2"].d()))
                }
            }
            KeyValueRow(key: "Dealer GEX", value: Fmt.big(s["dealer_gex"].d()))
            KeyValueRow(key: "Gamma flip", value: Fmt.opt(s["gamma_flip"]))
            KeyValueRow(key: "IV / DTE", value: "\(Fmt.pct(s["iv"].d() * 100, digits: 1)) / \(s["dte"].int)")
        }
    }

    private func probBar(up: Double, neutral: Double, down: Double) -> some View {
        let t = max(up + neutral + down, 0.0001)
        return VStack(alignment: .leading, spacing: 4) {
            GeometryReader { g in
                HStack(spacing: 2) {
                    Rectangle().fill(Theme.bull).frame(width: g.size.width * up / t)
                    Rectangle().fill(Color.gray.opacity(0.5)).frame(width: g.size.width * neutral / t)
                    Rectangle().fill(Theme.bear).frame(width: g.size.width * down / t)
                }.clipShape(Capsule())
            }.frame(height: 10)
            HStack {
                Text("Up \(Fmt.num(up * 100, 0))%").foregroundStyle(Theme.bull)
                Spacer()
                if neutral > 0 { Text("Neutral \(Fmt.num(neutral * 100, 0))%").foregroundStyle(.secondary); Spacer() }
                Text("Down \(Fmt.num(down * 100, 0))%").foregroundStyle(Theme.bear)
            }.font(.caption2.weight(.semibold))
        }
    }
}
