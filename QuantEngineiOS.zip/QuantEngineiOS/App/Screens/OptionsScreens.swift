import SwiftUI
import Charts

enum FlowMetric: String, CaseIterable, Identifiable {
    case notional = "Notional", volume = "Volume", oi = "OI", gex = "GEX"
    var id: String { rawValue }
    var key: String { self == .notional ? "notional" : self == .volume ? "volume" : self == .oi ? "oi" : "gex" }
}

/// Quant Tool — Leading Intensity Cloud: per-strike call/put intensity around spot, with today's 5m candles.
struct QuantToolView: View {
    @State private var metric = FlowMetric.notional
    @State private var dte = 45

    var body: some View {
        ToolScreen(title: "Quant Tool", method: "intensity_cloud", args: ["metric": metric.key, "dte": dte],
                   key: "\(metric.key)|\(dte)", autoRefresh: 60) { d in
            MetricPicker(metric: $metric, dte: $dte)
            let spot = d["spot"].d()
            Card(title: "Today · 5m") {
                BarsCandles(bars: d["bars"], levels: [PriceLevel(label: "spot", price: spot, color: .yellow)], height: 200)
            }
            Card(title: "Intensity cloud · \(metric.rawValue)") {
                IntensityBars(rows: d["rows"], spot: spot)
            }
        }
    }
}

struct MetricPicker: View {
    @Binding var metric: FlowMetric
    @Binding var dte: Int
    var body: some View {
        VStack(spacing: 8) {
            Picker("Metric", selection: $metric) { ForEach(FlowMetric.allCases) { Text($0.rawValue).tag($0) } }.pickerStyle(.segmented)
            Picker("Max DTE", selection: $dte) { ForEach([7, 15, 30, 45], id: \.self) { Text("≤\($0)d").tag($0) } }.pickerStyle(.segmented)
        }
    }
}

/// Diverging horizontal bars: puts left (red), calls right (green), one row per strike, high strikes on top.
struct IntensityBars: View {
    let rows: J
    let spot: Double

    private struct Item: Identifiable { let id: Double; let strike: Double; let call: Double; let put: Double }
    private var items: [Item] {
        rows.array.map { Item(id: $0["strike"].d(), strike: $0["strike"].d(), call: $0["call"].d(), put: $0["put"].d()) }
            .sorted { $0.strike > $1.strike }
    }
    private func label(_ s: Double) -> String { s == s.rounded() ? String(format: "%.0f", s) : String(format: "%.1f", s) }
    private var nearest: Double? { items.min { abs($0.strike - spot) < abs($1.strike - spot) }?.strike }

    var body: some View {
        let list = items
        let maxV = max(list.map { max($0.call, $0.put) }.max() ?? 1, 1)
        Chart {
            ForEach(list) { it in
                BarMark(xStart: .value("zero", 0), xEnd: .value("Call", it.call), y: .value("Strike", label(it.strike)))
                    .foregroundStyle(Theme.bull.opacity(0.35 + 0.65 * min(it.call / maxV, 1)))
                BarMark(xStart: .value("zero", 0), xEnd: .value("Put", -it.put), y: .value("Strike", label(it.strike)))
                    .foregroundStyle(Theme.bear.opacity(0.35 + 0.65 * min(it.put / maxV, 1)))
            }
            if let n = nearest {
                RuleMark(y: .value("Spot", label(n))).foregroundStyle(.yellow)
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 3]))
                    .annotation(position: .trailing, alignment: .center) { Text("spot").font(.system(size: 9)).foregroundStyle(.yellow) }
            }
        }
        .chartXAxis(.hidden)
        .chartYAxis { AxisMarks(position: .leading) { v in AxisValueLabel { if let s = v.as(String.self) { Text(s).font(.system(size: 9)) } } } }
        .frame(height: CGFloat(max(list.count, 6)) * 15 + 20)
    }
}

/// Strike Intensity heatmap: ranked per-strike net flow with peak / runner-up markers.
struct StrikeHeatmapView: View {
    @State private var metric = FlowMetric.notional
    @State private var dte = 45

    var body: some View {
        ToolScreen(title: "Strike Heatmap", method: "strike_heatmap", args: ["metric": metric.key, "dte": dte],
                   key: "\(metric.key)|\(dte)", autoRefresh: 60) { d in
            MetricPicker(metric: $metric, dte: $dte)
            let rows = d["rows"].array
            Card(title: "Summary") {
                HStack {
                    StatTile(label: "Spot", value: Fmt.price(d["spot"].d()))
                    StatTile(label: "Peak dominance", value: Fmt.num(d["peak_dominance"].d() * 100, 0) + "%")
                    StatTile(label: "Runner-up", value: Fmt.opt(d["runner_up_strike"]))
                }
            }
            Card(title: "Strikes · \(metric.rawValue)") {
                ForEach(rows.indices, id: \.self) { i in
                    let r = rows[i]
                    heatRow(r, spot: d["spot"].d())
                }
            }
        }
    }

    private func heatRow(_ r: J, spot: Double) -> some View {
        let call = r["call_dominant"].bool
        let c = call ? Theme.bull : Theme.bear
        let strike = r["strike"].d()
        return HStack(spacing: 8) {
            Text(Fmt.num(strike, strike == strike.rounded() ? 0 : 1)).font(.system(.footnote, design: .monospaced).weight(.semibold))
                .frame(width: 52, alignment: .trailing)
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.gray.opacity(0.12))
                    Capsule().fill(c.opacity(0.3 + 0.7 * Double(r["intensity"].d())))
                        .frame(width: max(3, g.size.width * CGFloat(min(max(r["intensity"].d(), 0), 1))))
                }
            }.frame(height: 12)
            Text(Fmt.big(r["net"].d())).font(.caption2.monospacedDigit()).foregroundStyle(c).frame(width: 56, alignment: .trailing)
            if r["peak"].bool { Pill(text: "PEAK", color: .yellow) }
            else if r["runner_up"].bool { Pill(text: "2nd", color: .orange) }
            else if abs(strike - spot) / max(spot, 1) < 0.003 { Pill(text: "spot", color: Theme.accent) }
        }
    }
}

/// GEX — dealer gamma levels (call/put wall, flip, max pain, expected move) and net GEX by strike.
struct GEXView: View {
    @State private var weighting = "OI"

    var body: some View {
        ToolScreen(title: "GEX", method: "gex", autoRefresh: 90) { d in
            let spot = d["spot"].d()
            let rb = d["robust"]
            let isR = weighting == "ROBUST" && rb["valid"].bool
            let regime = isR ? rb["edge"].string : d["regime"].string
            Card {
                HStack {
                    Text(regime).font(.title3.weight(.bold))
                        .foregroundStyle(regime.contains("LONG") ? Theme.bull : Theme.bear)
                    Spacer()
                    Text("spot \(Fmt.price(spot))").foregroundStyle(.secondary)
                }
                Text(regime.contains("LONG")
                     ? "Dealers long gamma: moves tend to be dampened / mean-reverting."
                     : "Dealers short gamma: moves tend to be amplified.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Card(title: "15m price + key levels") {
                BarsCandles(bars: d["bars"], levels: keyLevels(d, robust: isR ? rb : nil), visible: 70, height: 280)
            }
            Card(title: "Net GEX by strike") {
                Picker("Weighting", selection: $weighting) { Text("Open interest").tag("OI"); Text("Volume").tag("VOL"); Text("Robust").tag("ROBUST") }
                    .pickerStyle(.segmented)
                let g = isR ? rb : (weighting == "OI" ? d["by_oi"] : d["by_volume"])
                GexBars(strikes: g["strikes"].doubles, values: g["net"].doubles, spot: spot)
                HStack {
                    StatTile(label: "Flip", value: Fmt.opt(g["flip"]))
                    StatTile(label: "Call wall", value: Fmt.opt(g["call_wall"]), color: Theme.bull)
                    StatTile(label: "Put wall", value: Fmt.opt(g["put_wall"]), color: Theme.bear)
                }
            }
            if rb["valid"].bool { robustCard(d, rb) }
            Card(title: "Levels") {
                ForEach(d["levels"].array.indices, id: \.self) { i in
                    let l = d["levels"][i]
                    HStack {
                        VStack(alignment: .leading, spacing: 1) {
                            Text(l["label"].string).font(.subheadline)
                            Text(l["zone"].string).font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 1) {
                            Text(Fmt.price(l["price"].d())).font(.subheadline.monospacedDigit().weight(.semibold))
                            if l["net_gex"].d() != 0 {
                                Text(Fmt.big(l["net_gex"].d())).font(.caption2.monospacedDigit())
                                    .foregroundStyle(l["net_gex"].d() >= 0 ? Theme.bull : Theme.bear)
                            }
                        }
                    }
                }
            }
        }
    }

    private func robustCard(_ d: J, _ rb: J) -> some View {
        let raw = d["by_oi"]["flip"], f = rb["flip"]
        let hasBand = rb["flip_lo"].exists && rb["flip_hi"].exists
        let st = rb["stability"].d()
        let shift = (raw.exists && f.exists) ? f.d() - raw.d() : Double.nan
        return Card(title: "Robust flip · anti-spoof filter") {
            HStack {
                StatTile(label: "Raw flip", value: Fmt.opt(raw))
                StatTile(label: "Robust flip", value: Fmt.opt(f), color: Theme.warn)
                StatTile(label: "Shift", value: shift.isFinite ? String(format: "%+.2f", shift) : "–")
            }
            HStack {
                StatTile(label: "Stability band", value: hasBand ? "\(Fmt.num(rb["flip_lo"].d(), 2))–\(Fmt.num(rb["flip_hi"].d(), 2))" : "–")
                StatTile(label: "Firmness", value: hasBand ? (st > 0.66 ? "firm" : st > 0.33 ? "moderate" : "fragile") : "–",
                         color: st > 0.66 ? Theme.bull : st > 0.33 ? Theme.warn : Theme.bear)
            }
            Text("Total dealer gamma if price moved to each level (zero crossing = flip)").font(.caption2).foregroundStyle(.secondary)
            GexBars(strikes: rb["sweep_spot"].doubles, values: rb["sweep_total"].doubles, spot: d["spot"].d())
            Text("Filtered \(rb["rows_in"].int) contracts: dropped \(rb["dropped_stale"].int) with no trades and no price, \(rb["dropped_iv"].int) with junk IV; capped \(rb["clipped"].int) outsized weights; open interest scaled by how much it actually traded (avg trust \(Fmt.num(rb["mean_conf"].d() * 100, 0))%).")
                .font(.caption2).foregroundStyle(.secondary)
            Text("What this does and does not do: Yahoo has no order book, so spoofed or flickering orders can't be seen or removed directly; they never show up in open interest or volume. This mode removes what distorts the number you can see: dead strikes, one-strike dominance and single-crossing noise, and shows how much the flip moves under random ±25% weight noise. A wide band means the flip is fragile whatever its value.")
                .font(.caption2).foregroundStyle(.secondary)
        }
    }

    private func keyLevels(_ d: J, robust: J?) -> [PriceLevel] {
        var out: [PriceLevel] = []
        for l in d["levels"].array {
            let name = l["label"].string
            if robust != nil && name.contains("Flip") { continue }
            let color: Color
            if name.contains("Call Wall") { color = Theme.bull }
            else if name.contains("Put Wall") { color = Theme.bear }
            else if name.contains("Flip") { color = .yellow }
            else if name.contains("Max Pain") { color = .purple }
            else if name.contains("Expected") { color = .cyan }
            else { continue }
            out.append(PriceLevel(label: name.replacingOccurrences(of: " (Zero Gamma)", with: ""), price: l["price"].d(), color: color))
        }
        if let r = robust, r["flip"].exists { out.append(PriceLevel(label: "Robust flip", price: r["flip"].d(), color: .yellow)) }
        return out
    }
}

struct GexBars: View {
    let strikes: [Double], values: [Double], spot: Double
    private struct P: Identifiable { let id: Int; let k: Double; let v: Double }
    private var pts: [P] {
        let n = min(strikes.count, values.count)
        return (0..<n).map { P(id: $0, k: strikes[$0], v: values[$0]) }
            .filter { abs($0.k - spot) <= spot * 0.08 }
    }
    var body: some View {
        Chart {
            ForEach(pts) { p in
                BarMark(x: .value("Strike", p.k), y: .value("GEX", p.v), width: .fixed(5))
                    .foregroundStyle(p.v >= 0 ? Theme.bull : Theme.bear)
            }
            RuleMark(x: .value("Spot", spot)).foregroundStyle(.yellow).lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 3]))
        }
        .chartXScale(domain: (spot * 0.92)...(spot * 1.08))
        .chartYAxis { AxisMarks(position: .leading) { v in AxisValueLabel { if let d = v.as(Double.self) { Text(Fmt.big(d)).font(.system(size: 9)) } } } }
        .frame(height: 200)
    }
}
