import SwiftUI
import Charts

/// Net Flow — call vs put premium by DTE bucket, plus cumulative premium since you opened the screen (polls every 20 s).
struct NetFlowView: View {
    var body: some View {
        ToolScreen(title: "Net Flow", method: "net_flow", autoRefresh: 20) { d in
            Card {
                HStack {
                    Text(d["bias"].string).font(.title3.weight(.bold)).foregroundStyle(Theme.bias(d["bias"].string))
                    Spacer()
                    Text("spot \(Fmt.price(d["spot"].d()))").foregroundStyle(.secondary)
                }
                HStack {
                    StatTile(label: "Call notional", value: "$" + Fmt.big(d["total_call"].d()), color: Theme.bull)
                    StatTile(label: "Put notional", value: "$" + Fmt.big(d["total_put"].d()), color: Theme.bear)
                    StatTile(label: "Net", value: "$" + Fmt.big(d["total_net"].d()), color: d["total_net"].d() >= 0 ? Theme.bull : Theme.bear)
                }
                let r = d["total_cp_ratio"].d(0.5)
                ProgressView(value: min(max(r, 0), 1)).tint(Theme.bull)
                Text("Call share of volume \(Fmt.num(r * 100, 0))%").font(.caption).foregroundStyle(.secondary)
            }
            Card(title: "By expiry bucket") {
                let b = d["buckets"].array
                Chart {
                    ForEach(b.indices, id: \.self) { i in
                        BarMark(x: .value("Bucket", b[i]["label"].string), y: .value("Call", b[i]["call_notional"].d()))
                            .foregroundStyle(Theme.bull).position(by: .value("Side", "Call"))
                        BarMark(x: .value("Bucket", b[i]["label"].string), y: .value("Put", b[i]["put_notional"].d()))
                            .foregroundStyle(Theme.bear).position(by: .value("Side", "Put"))
                    }
                }
                .chartYAxis { AxisMarks(position: .leading) { v in AxisValueLabel { if let x = v.as(Double.self) { Text(Fmt.big(x)).font(.system(size: 9)) } } } }
                .frame(height: 180)
                ForEach(b.indices, id: \.self) { i in
                    HStack {
                        Text(b[i]["label"].string).font(.subheadline.weight(.semibold))
                        Spacer()
                        Text("net $\(Fmt.big(b[i]["net"].d()))").font(.footnote.monospacedDigit())
                            .foregroundStyle(b[i]["net"].d() >= 0 ? Theme.bull : Theme.bear)
                        Text("C/P \(Fmt.num(b[i]["cp_ratio"].d() * 100, 0))%").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            Card(title: "Cumulative premium flow (this session)") {
                let h = d["history"].array
                if h.count < 2 {
                    Text("Collecting… flow is the change in volume between refreshes, so the first reading only sets the baseline. Keep this screen open.")
                        .font(.footnote).foregroundStyle(.secondary)
                } else {
                    Chart {
                        ForEach(h.indices, id: \.self) { i in
                            LineMark(x: .value("t", h[i]["t"].d()), y: .value("Call", h[i]["call"].d()), series: .value("s", "Call")).foregroundStyle(Theme.bull)
                            LineMark(x: .value("t", h[i]["t"].d()), y: .value("Put", h[i]["put"].d()), series: .value("s", "Put")).foregroundStyle(Theme.bear)
                            LineMark(x: .value("t", h[i]["t"].d()), y: .value("Net", h[i]["net"].d()), series: .value("s", "Net")).foregroundStyle(.white)
                        }
                    }
                    .chartYAxis { AxisMarks(position: .leading) { v in AxisValueLabel { if let x = v.as(Double.self) { Text(Fmt.big(x)).font(.system(size: 9)) } } } }
                    .frame(height: 180)
                }
            }
        }
    }
}

/// Net Flow+ — synthesized trade prints (volume deltas between refreshes) classified as sweep / block / aggressive / extreme.
struct NetFlowPlusView: View {
    @State private var filter = "All"

    var body: some View {
        ToolScreen(title: "Net Flow+", method: "net_flow_plus", args: ["limit": 300], autoRefresh: 20) { d in
            let events = d["events"].array
            Card {
                HStack {
                    StatTile(label: "Prints", value: "\(events.count)")
                    StatTile(label: "New this refresh", value: "\(d["new_events"].int)")
                    StatTile(label: "p99 premium", value: "$" + Fmt.big(d["p99"].d()))
                }
                Text("Prints are inferred from changes in per-contract volume between refreshes (Yahoo has no trade tape), so the first refresh only sets baselines.")
                    .font(.caption2).foregroundStyle(.tertiary)
            }
            Picker("Class", selection: $filter) {
                ForEach(["All", "SWEEP", "BLOCK", "EXTREME"], id: \.self) { Text($0.capitalized).tag($0) }
            }.pickerStyle(.segmented)
            let shown = events.filter { filter == "All" || $0["class"].string == filter }
            Card(title: "Prints (latest first)") {
                if shown.isEmpty {
                    Text(events.isEmpty ? "Waiting for the next refresh to detect volume changes…" : "No prints of that class yet.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                ForEach(shown.prefix(150).indices, id: \.self) { i in
                    let e = shown[i]
                    let call = e["call"].bool
                    HStack(alignment: .top) {
                        VStack(alignment: .leading, spacing: 2) {
                            HStack(spacing: 6) {
                                Text("\(Fmt.num(e["strike"].d(), 1)) \(call ? "C" : "P")").font(.subheadline.weight(.bold))
                                    .foregroundStyle(call ? Theme.bull : Theme.bear)
                                Text("\(e["exp"].string) · \(e["dte"].int)d").font(.caption).foregroundStyle(.secondary)
                            }
                            Text("\(Fmt.big(e["size"].d())) lots @ \(Fmt.num(e["price"].d(), 2)) · IV \(Fmt.num(e["iv"].d() * 100, 0))%")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("$" + Fmt.big(e["premium"].d())).font(.subheadline.monospacedDigit().weight(.semibold))
                            if e["class"].string != "NEUTRAL" { Pill(text: e["class"].string, color: classColor(e["class"].string)) }
                        }
                    }
                    Divider()
                }
            }
        }
    }

    private func classColor(_ c: String) -> Color {
        switch c {
        case "EXTREME": return .pink
        case "SWEEP": return .orange
        case "BLOCK": return .purple
        case "AGGRESSIVE CALL": return Theme.bull
        case "AGGRESSIVE PUT": return Theme.bear
        default: return .secondary
        }
    }
}
