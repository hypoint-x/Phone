import SwiftUI

/// Moving Average Ladder — 5/9/22/50/200 EMA stack across 5m/15m/1h with the confluence checklist.
struct MALadderView: View {
    @State private var anchor = 2
    private let names = ["5m", "15m", "1h"]

    var body: some View {
        ToolScreen(title: "MA Ladder", method: "ma_ladder", args: ["anchor": anchor], key: "\(anchor)", autoRefresh: 60) { d in
            let l = d["ladder"]
            Picker("Anchor", selection: $anchor) {
                ForEach(0..<3, id: \.self) { Text("Anchor \(names[$0])").tag($0) }
            }.pickerStyle(.segmented)
            LadderSummary(ladder: l, title: "Confluence — anchor \(l["anchor_tf"].string)")
            BullishCard()
            Card(title: "\(names[anchor]) candles + EMA ladder") {
                LadderSummary.chart(for: l, tfIndex: anchor)
                FlowLayout {
                    ForEach(LadderSummary.emaColors, id: \.0) { e in
                        HStack(spacing: 4) { Circle().fill(e.1).frame(width: 8, height: 8); Text(e.0.uppercased()).font(.caption2) }
                    }
                }
            }
            CodexBrowser()
        }
    }
}

/// Multi-timeframe bias (1m / 5m / 15m / 1h / 1d).
struct MTFView: View {
    var body: some View {
        ToolScreen(title: "MTF", method: "mtf", autoRefresh: 60) { d in
            let m = d["mtf"]
            Card(title: "Multi-timeframe") {
                HStack {
                    StatTile(label: "Signal", value: m["signal"].string, color: Theme.bias(m["signal"].string))
                    StatTile(label: "Confidence", value: "\(m["confidence"].int)")
                    StatTile(label: "Buy signal", value: m["buy_signal"].string, color: Theme.bias(m["buy_signal"].string))
                }
                ProgressView(value: Double(m["confidence"].int), total: 100).tint(Theme.bias(m["signal"].string))
                Text("Early: \(m["early_signal"].string)").font(.footnote).foregroundStyle(.secondary)
            }
            Card(title: "Timeframes") {
                ForEach(m["timeframes"].array.indices, id: \.self) { i in
                    let t = m["timeframes"][i]
                    HStack {
                        Text(t["tf"].string).font(.subheadline.weight(.semibold)).frame(width: 34, alignment: .leading)
                        Pill(text: t["bias"].string, color: Theme.bias(t["bias"].string))
                        Pill(text: "candle \(t["candle"].string)", color: Theme.bias(t["candle"].string))
                        Spacer()
                        Text(t["trend"].string).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
}

/// Dow Transports vs crude oil.
struct TransportsView: View {
    @EnvironmentObject var app: AppState
    @StateObject private var loader = Loader()
    @State private var anchor = 2

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Picker("Anchor", selection: $anchor) {
                    ForEach(0..<3, id: \.self) { Text(["5m", "15m", "1h"][$0]).tag($0) }
                }.pickerStyle(.segmented)
                if let e = loader.error { Card { Label(e, systemImage: "exclamationmark.triangle").foregroundStyle(Theme.warn) } }
                if let d = loader.data {
                    Card(title: "Relationship  ·  ^DJT vs CL=F") {
                        Text(d["relationship"].string).font(.headline)
                        HStack {
                            Pill(text: d["trade_direction"].string, color: Theme.bias(d["trade_direction"].string))
                            if d["trade_direction"].string != "FLAT" { Text("confidence \(d["confidence"].int)").font(.subheadline) }
                        }
                        Text(d["reasoning"].string).font(.footnote).foregroundStyle(.secondary)
                    }
                    LadderSummary(ladder: d["djt"], title: "Dow Transports (^DJT)")
                    Card(title: "^DJT chart") { LadderSummary.chart(for: d["djt"], tfIndex: anchor, height: 220) }
                    LadderSummary(ladder: d["oil"], title: "Crude oil (CL=F)")
                    Card(title: "CL=F chart") { LadderSummary.chart(for: d["oil"], tfIndex: anchor, height: 220) }
                } else if loader.loading { ProgressView("Loading…").padding(.top, 40) }
            }
            .padding(.horizontal, 16).padding(.bottom, 24)
        }
        .refreshable { await loader.load("transports", ["anchor": anchor]) }
        .navigationTitle("Transport Divergence").navigationBarTitleDisplayMode(.inline)
        .task(id: anchor) { await loader.load("transports", ["anchor": anchor], keepOld: false) }
    }
}
