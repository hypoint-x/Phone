import SwiftUI
import Charts

/// Chart+ — port of the desktop SpyEmaChart panel (candles, EMA 9/20/50, VWAP, Bollinger, RSI, MACD, setup score, trade plan).
struct ChartPlusView: View {
    @State private var tf = "5m"
    @State private var showEMA = true
    @State private var showVWAP = true
    @State private var showBB = false
    @State private var showSR = true

    private static let frames: [String: (period: String, interval: String)] = [
        "1m": ("1d", "1m"), "5m": ("5d", "5m"), "15m": ("5d", "15m"), "1h": ("1mo", "60m")
    ]

    var body: some View {
        let f = Self.frames[tf] ?? ("5d", "5m")
        ToolScreen(title: "Chart+", method: "chart", args: ["period": f.period, "interval": f.interval], key: tf, autoRefresh: 30) { d in
            let c = d["chart"]
            Picker("Timeframe", selection: $tf) {
                ForEach(["1m", "5m", "15m", "1h"], id: \.self) { Text($0).tag($0) }
            }.pickerStyle(.segmented)

            Card {
                HStack(alignment: .firstTextBaseline) {
                    Text(Fmt.price(c["last"].d())).font(.system(size: 32, weight: .bold, design: .rounded)).monospacedDigit()
                    Text("\(Fmt.num(c["change"].d(), 2))  (\(Fmt.pct(c["pct"].d())))")
                        .foregroundStyle(c["change"].d() >= 0 ? Theme.bull : Theme.bear).font(.subheadline.weight(.semibold))
                    Spacer()
                }
                HStack {
                    StatTile(label: "Session high", value: Fmt.price(c["session_high"].d()))
                    StatTile(label: "Session low", value: Fmt.price(c["session_low"].d()))
                    StatTile(label: "RSI", value: Fmt.num(c["rsi_last"].d(50), 1))
                }
            }

            Card {
                HStack(spacing: 14) {
                    Toggle("EMA", isOn: $showEMA); Toggle("VWAP", isOn: $showVWAP)
                    Toggle("BB", isOn: $showBB); Toggle("S/R", isOn: $showSR)
                }.toggleStyle(.button).font(.caption)
                CandleChart(o: c["o"].doubles, h: c["h"].doubles, l: c["l"].doubles, c: c["c"].doubles,
                            lines: overlays(c), levels: showSR ? srLevels(c) : [], visible: 80, height: 300)
                LineStrip(values: c["rsi"].doubles, title: "RSI 14", color: .purple, band: (30, 70), domain: 0...100)
                HistogramStrip(values: c["macd_hist"].doubles, title: "MACD histogram")
                LineStrip(values: c["adx"].doubles, title: "ADX", color: Theme.warn)
            }

            BullishCard(title: "Ladder EV · Bullish / Bearish")
            setupCard(c)
            planCard(c["trade_plan"])
            levelsCard(c)
            CodexBrowser()
        }
    }

    private func overlays(_ c: J) -> [ChartLine] {
        var l: [ChartLine] = []
        if showEMA {
            l.append(ChartLine(name: "EMA9", values: c["ema9"].doubles, color: .orange))
            l.append(ChartLine(name: "EMA20", values: c["ema20"].doubles, color: .blue))
            l.append(ChartLine(name: "EMA50", values: c["ema50"].doubles, color: .purple))
        }
        if showVWAP { l.append(ChartLine(name: "VWAP", values: c["vwap"].doubles, color: .yellow, width: 1.6)) }
        if showBB {
            l.append(ChartLine(name: "BBU", values: c["bb_upper"].doubles, color: .gray, dashed: true))
            l.append(ChartLine(name: "BBL", values: c["bb_lower"].doubles, color: .gray, dashed: true))
        }
        return l
    }

    private func srLevels(_ c: J) -> [PriceLevel] {
        var out: [PriceLevel] = []
        for s in c["sr"].array {
            out.append(PriceLevel(label: s["resistance"].bool ? "R" : "S", price: s["price"].d(),
                                  color: s["resistance"].bool ? Theme.bear : Theme.bull))
        }
        return out
    }

    private func setupCard(_ c: J) -> some View {
        Card(title: "Setup") {
            HStack {
                Text(c["setup_label"].string.isEmpty ? "No setup" : c["setup_label"].string)
                    .font(.headline).foregroundStyle(Theme.bias(c["setup_label"].string))
                Spacer()
                Text("score \(Fmt.num(c["setup_score"].d(), 1))").font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(c["setup_reasons"].strings, id: \.self) { r in
                Label(r, systemImage: "checkmark.circle").font(.footnote).foregroundStyle(.secondary)
            }
            if !c["patterns"].array.isEmpty {
                FlowLayout {
                    ForEach(c["patterns"].array.indices, id: \.self) { i in
                        let p = c["patterns"][i]
                        Pill(text: p["name"].string, color: p["bullish"].bool ? Theme.bull : Theme.bear)
                    }
                }
            }
        }
    }

    @ViewBuilder private func planCard(_ p: J) -> some View {
        if p["valid"].bool && p["direction"].string != "NONE" {
            Card(title: "Trade plan") {
                HStack {
                    Pill(text: p["direction"].string, color: Theme.bias(p["direction"].string))
                    Text(p["style"].string).font(.subheadline)
                    Spacer()
                    Text(p["entry_quality"].string).font(.caption).foregroundStyle(.secondary)
                }
                HStack {
                    StatTile(label: "Entry", value: Fmt.price(p["entry"].d()))
                    StatTile(label: "Stop", value: Fmt.price(p["stop"].d()), color: Theme.bear)
                    StatTile(label: "Target 1R", value: Fmt.price(p["target_1r"].d()), color: Theme.bull)
                    StatTile(label: "Target 2R", value: Fmt.price(p["target_2r"].d()), color: Theme.bull)
                }
                Text(p["entry_type"].string).font(.footnote).foregroundStyle(.secondary)
                ForEach(p["factors"].strings, id: \.self) { Text("• \($0)").font(.footnote) }
                if !p["invalidation"].string.isEmpty {
                    Text("Invalidation: \(p["invalidation"].string)").font(.footnote).foregroundStyle(Theme.warn)
                }
            }
        }
    }

    private func levelsCard(_ c: J) -> some View {
        Card(title: "Levels") {
            if c["pivots"]["valid"].bool {
                HStack {
                    StatTile(label: "S2", value: Fmt.price(c["pivots"]["s2"].d()))
                    StatTile(label: "S1", value: Fmt.price(c["pivots"]["s1"].d()))
                    StatTile(label: "Pivot", value: Fmt.price(c["pivots"]["pp"].d()))
                    StatTile(label: "R1", value: Fmt.price(c["pivots"]["r1"].d()))
                    StatTile(label: "R2", value: Fmt.price(c["pivots"]["r2"].d()))
                }
            }
            if c["volume_profile"]["valid"].bool {
                HStack {
                    StatTile(label: "VAL", value: Fmt.price(c["volume_profile"]["val"].d()))
                    StatTile(label: "POC", value: Fmt.price(c["volume_profile"]["poc"].d()))
                    StatTile(label: "VAH", value: Fmt.price(c["volume_profile"]["vah"].d()))
                }
            }
            if c["fib"]["valid"].bool {
                ForEach(c["fib"]["levels"].array.indices, id: \.self) { i in
                    let f = c["fib"]["levels"][i]
                    KeyValueRow(key: "Fib \(f["label"].string)", value: Fmt.price(f["price"].d()))
                }
            }
        }
    }
}
