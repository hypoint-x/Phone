import SwiftUI

/// Gamma Node Sequencer — WAIT, WAIT, ENTER. Strike × DTE net-GEX grid, king node, and the active 3-node sequence.
struct GammaNodeView: View {
    @State private var dte = 45
    @State private var band = 10.0
    @State private var minRR = 2.0

    var body: some View {
        ToolScreen(title: "Gamma Nodes", method: "gamma_node", args: ["dte": dte, "band_pct": band, "min_rr": minRR],
                   key: "\(dte)|\(band)|\(minRR)", autoRefresh: 90) { d in
            Card(title: "Parameters") {
                Picker("Max DTE", selection: $dte) { ForEach([7, 15, 30, 45], id: \.self) { Text("≤\($0)d").tag($0) } }.pickerStyle(.segmented)
                Picker("Band", selection: $band) { ForEach([5.0, 10.0, 15.0, 25.0], id: \.self) { Text("±\(Int($0))%").tag($0) } }.pickerStyle(.segmented)
                Picker("Min R:R", selection: $minRR) { ForEach([1.0, 1.5, 2.0, 3.0], id: \.self) { Text("R:R \(Fmt.num($0, 1))").tag($0) } }.pickerStyle(.segmented)
            }
            sequenceCard(d["sequence"], spot: d["spot"].d())
            Card(title: "Strike × DTE net GEX") {
                GammaGrid(cells: d["cells"], dteColumns: d["dte_columns"].ints, spot: d["spot"].d())
                HStack(spacing: 10) {
                    legend(Theme.bull, "net + (support)"); legend(Theme.bear, "net − (resistance)"); legend(.yellow, "king")
                }.font(.caption2)
            }
            kingCard(d)
        }
    }

    private func legend(_ c: Color, _ t: String) -> some View {
        HStack(spacing: 4) { RoundedRectangle(cornerRadius: 2).fill(c).frame(width: 10, height: 10); Text(t).foregroundStyle(.secondary) }
    }

    private func sequenceCard(_ s: J, spot: Double) -> some View {
        Card(title: "Active sequence") {
            HStack {
                Text(s["state"].string).font(.headline)
                Spacer()
                Pill(text: s["direction"].string, color: Theme.bias(s["direction"].string))
                Pill(text: s["type"].string, color: .secondary)
            }
            if s["entry"].d() > 0 {
                HStack {
                    StatTile(label: "Entry", value: Fmt.price(s["entry"].d()))
                    StatTile(label: "Invalidation", value: Fmt.price(s["invalidation"].d()), color: Theme.bear)
                    StatTile(label: "Target", value: Fmt.price(s["target"].d()), color: Theme.bull)
                    StatTile(label: "R:R", value: Fmt.num(s["rr"].d(), 2))
                }
                ProgressView(value: min(max(s["confidence"].d(), 0), 1)).tint(Theme.accent)
                Text("node confidence \(Fmt.num(s["confidence"].d() * 100, 0))%").font(.caption).foregroundStyle(.secondary)
            }
            ForEach([("first", "1st node"), ("second", "2nd node"), ("entry_node", "Entry node")], id: \.0) { k in
                if s[k.0].exists {
                    HStack {
                        Text(k.1).font(.subheadline).foregroundStyle(.secondary)
                        Spacer()
                        Text(Fmt.price(s[k.0]["strike"].d())).font(.subheadline.monospacedDigit().weight(.semibold))
                        Pill(text: s[k.0]["type"].string, color: s[k.0]["type"].string.hasPrefix("+") ? Theme.bull : Theme.bear)
                    }
                }
            }
            if !s["entry"].exists || s["entry"].d() <= 0 {
                Text("No qualifying 3-node path in this band right now. WAIT.").font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    private func kingCard(_ d: J) -> some View {
        Card(title: "King node") {
            KeyValueRow(key: "King strike", value: Fmt.opt(d["king_strike"]), color: .yellow)
            KeyValueRow(key: "King DTE column", value: d["king_dte_col"].exists ? "\(d["king_dte_col"].int)" : "–")
            if d["king"].exists {
                KeyValueRow(key: "King cell", value: "\(Fmt.price(d["king"]["strike"].d())) · \(d["king"]["exp"].string)")
                KeyValueRow(key: "Net GEX", value: Fmt.big(d["king"]["net_gex"].d()), color: d["king"]["net_gex"].d() >= 0 ? Theme.bull : Theme.bear)
                KeyValueRow(key: "Persistence", value: Fmt.num(d["king"]["persistence"].d() * 100, 0) + "%")
            }
            KeyValueRow(key: "ATR (5m)", value: Fmt.num(d["atr"].d(), 3))
        }
    }
}

/// Canvas heatmap: rows = strikes (high on top), columns = DTE; colour = signed net GEX; ● marks nodes, ★ the king.
struct GammaGrid: View {
    let cells: J
    let dteColumns: [Int]
    let spot: Double

    private struct Cell { let strike: Double; let col: Int; let net: Double; let node: String; let king: Bool }

    var body: some View {
        let all: [Cell] = cells.array.map {
            Cell(strike: $0["strike"].d(), col: $0["col"].int, net: $0["net_gex"].d(), node: $0["type"].string, king: $0["king"].bool)
        }
        let strikes = Array(Set(all.map { $0.strike })).sorted(by: >)
        let cols = max(dteColumns.count, 1)
        let maxAbs = max(all.map { abs($0.net) }.max() ?? 1, 1)
        let rowH: CGFloat = 16
        let height = CGFloat(strikes.count) * rowH
        let index = Dictionary(uniqueKeysWithValues: strikes.enumerated().map { ($0.element, $0.offset) })
        let nearest = strikes.min { abs($0 - spot) < abs($1 - spot) }

        return Canvas { ctx, size in
            let labelW: CGFloat = 44
            let colW = (size.width - labelW) / CGFloat(cols)
            for (k, s) in strikes.enumerated() {
                let y = CGFloat(k) * rowH
                let isSpot = s == nearest
                ctx.draw(Text(Fmt.num(s, s == s.rounded() ? 0 : 1)).font(.system(size: 9, design: .monospaced))
                            .foregroundColor(isSpot ? .yellow : .secondary), at: CGPoint(x: labelW - 4, y: y + rowH / 2), anchor: .trailing)
                if isSpot {
                    ctx.stroke(Path(CGRect(x: labelW, y: y, width: size.width - labelW, height: rowH)), with: .color(.yellow.opacity(0.7)), lineWidth: 1)
                }
            }
            for c in all {
                guard let r = index[c.strike], c.col >= 0, c.col < cols else { continue }
                let rect = CGRect(x: labelW + CGFloat(c.col) * colW + 1, y: CGFloat(r) * rowH + 1, width: colW - 2, height: rowH - 2)
                let a = min(abs(c.net) / maxAbs, 1)
                ctx.fill(Path(roundedRect: rect, cornerRadius: 2), with: .color((c.net >= 0 ? Theme.bull : Theme.bear).opacity(0.12 + 0.88 * pow(a, 0.6))))
                if c.king {
                    ctx.draw(Text("★").font(.system(size: 11)).foregroundColor(.yellow), at: CGPoint(x: rect.midX, y: rect.midY))
                } else if c.node.contains("NODE") {
                    ctx.fill(Path(ellipseIn: CGRect(x: rect.midX - 2.5, y: rect.midY - 2.5, width: 5, height: 5)), with: .color(.white.opacity(0.9)))
                }
            }
            for (ci, dte) in dteColumns.enumerated() {
                ctx.draw(Text("\(dte)d").font(.system(size: 9)).foregroundColor(.secondary),
                         at: CGPoint(x: labelW + (CGFloat(ci) + 0.5) * colW, y: CGFloat(strikes.count) * rowH + 8))
            }
        }
        .frame(height: height + 18)
    }
}
