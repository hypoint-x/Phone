import SwiftUI
import SceneKit

/// 3D Option Surface — strike (x) × DTE (depth) × metric (height). Drag to orbit, pinch to zoom.
struct Surface3DView: View {
    private enum M: String, CaseIterable, Identifiable {
        case volume = "Volume", oi = "OI", notional = "Notional", gamma = "Gamma", gex = "GEX"
        var id: String { rawValue }
        var key: String { switch self { case .volume: return "volume"; case .oi: return "oi"; case .notional: return "notional"; case .gamma: return "gamma"; case .gex: return "gex" } }
    }
    @State private var metric = M.volume
    @State private var dte = 30
    @State private var hs = "boost"

    var body: some View {
        ToolScreen(title: "3D Options", method: "surface", args: ["metric": metric.key, "dte": dte, "res": 60], key: "\(metric.key)|\(dte)") { d in
            Picker("Metric", selection: $metric) { ForEach(M.allCases) { Text($0.rawValue).tag($0) } }.pickerStyle(.segmented)
            Picker("Max DTE", selection: $dte) { ForEach([7, 15, 30, 45, 60], id: \.self) { Text("≤\($0)d").tag($0) } }.pickerStyle(.segmented)
            Picker("Height", selection: $hs) { Text("Height: Linear").tag("lin"); Text("Boost").tag("boost"); Text("Log").tag("log") }.pickerStyle(.segmented)
            Card(title: "\(metric.rawValue) surface") {
                SurfaceScene(z: d["z"].doubles, res: d["res"].int, strikes: d["x"].doubles, spot: d["spot"].d(), scale: hs)
                    .frame(height: 360)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                HStack {
                    Text("spot \(Fmt.price(d["spot"].d()))").font(.caption2).foregroundStyle(.yellow)
                    Spacer()
                    Text("Strike \(Fmt.price(d["x"][0].d())) → \(Fmt.price(d["x"][max(d["x"].count - 1, 0)].d()))").font(.caption2)
                    Spacer()
                    Text("DTE \(Fmt.num(d["y"][0].d(), 0)) → \(Fmt.num(d["y"][max(d["y"].count - 1, 0)].d(), 0))").font(.caption2)
                }.foregroundStyle(.secondary)
            }
            Card(title: "Peaks") {
                marker("Max call", d["markers"]["max_call"], Theme.bull)
                marker("Max call OI", d["markers"]["oi_call"], Theme.bull)
                marker("Max put", d["markers"]["max_put"], Theme.bear)
                marker("Max put OI", d["markers"]["oi_put"], Theme.bear)
            }
        }
    }

    @ViewBuilder private func marker(_ name: String, _ m: J, _ c: Color) -> some View {
        if m["valid"].bool {
            HStack {
                Text(name).foregroundStyle(.secondary)
                Spacer()
                Text("strike \(m["strike"].int) · \(Fmt.num(m["y"].d(), 0))d").monospacedDigit().foregroundStyle(c)
                Text("vol \(Fmt.big(m["volume"].d())) · OI \(Fmt.big(m["oi"].d()))").font(.caption).foregroundStyle(.secondary)
            }.font(.subheadline)
        }
    }
}

struct SurfaceScene: UIViewRepresentable {
    let z: [Double]
    let res: Int
    let strikes: [Double]
    let spot: Double
    var scale: String = "boost"

    func makeUIView(context: Context) -> SCNView {
        let v = SCNView()
        v.backgroundColor = UIColor.secondarySystemBackground
        v.allowsCameraControl = true
        v.antialiasingMode = .multisampling4X
        v.autoenablesDefaultLighting = true
        return v
    }

    func updateUIView(_ view: SCNView, context: Context) {
        let scene = SCNScene()
        if let g = Self.mesh(z: z, res: res, scale: scale) {
            let node = SCNNode(geometry: g)
            node.position = SCNVector3(-0.5, 0, -0.5)
            scene.rootNode.addChildNode(node)
            if let lo = strikes.first, let hi = strikes.last, hi > lo, spot > lo, spot < hi {
                let x = Float((spot - lo) / (hi - lo)) - 0.5
                let plane = SCNPlane(width: 1.0, height: 0.6)
                plane.firstMaterial?.diffuse.contents = UIColor.yellow.withAlphaComponent(0.18)
                plane.firstMaterial?.isDoubleSided = true
                let pn = SCNNode(geometry: plane)
                pn.eulerAngles = SCNVector3(0, Float.pi / 2, 0)
                pn.position = SCNVector3(x, 0.3, 0)
                scene.rootNode.addChildNode(pn)
            }
        }
        let floor = SCNFloor(); floor.reflectivity = 0
        floor.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.25)
        scene.rootNode.addChildNode(SCNNode(geometry: floor))
        let cam = SCNNode(); cam.camera = SCNCamera(); cam.camera?.zNear = 0.01
        cam.position = SCNVector3(0.0, 0.9, 1.7); cam.look(at: SCNVector3(0, 0.2, 0))
        scene.rootNode.addChildNode(cam)
        view.scene = scene
        view.pointOfView = cam
    }

    /// Triangle mesh over the res×res grid; height = normalised z; colour ramps blue → green → yellow → red with height.
    /// Height scaling: linear keeps true proportions (a 0-day spike flattens the rest); boost (power 0.4) and log compress the spike so later expiries show.
    static func fwd(_ t: Double, _ scale: String) -> Double {
        let x = min(max(t, 0), 1)
        switch scale {
        case "lin": return x
        case "log": return log1p(x * 400) / log1p(400)
        default: return pow(x, 0.4)
        }
    }

    static func mesh(z: [Double], res: Int, scale: String = "boost") -> SCNGeometry? {
        guard res >= 2, z.count == res * res else { return nil }
        let zmax = max(z.filter { $0.isFinite }.max() ?? 1, 1e-12)
        var verts: [SCNVector3] = [], cols: [SIMD4<Float>] = [], norms: [SCNVector3] = []
        verts.reserveCapacity(res * res)
        for iy in 0..<res {
            for ix in 0..<res {
                let h = Float(fwd(max(0, z[iy * res + ix].isFinite ? z[iy * res + ix] : 0) / zmax, scale))
                verts.append(SCNVector3(Float(ix) / Float(res - 1), h * 0.6, Float(iy) / Float(res - 1)))
                norms.append(SCNVector3(0, 1, 0))
                cols.append(ramp(h))
            }
        }
        var idx: [UInt32] = []
        for iy in 0..<(res - 1) {
            for ix in 0..<(res - 1) {
                let a = UInt32(iy * res + ix), b = a + 1, c = a + UInt32(res), d = c + 1
                idx += [a, c, b, b, c, d]
            }
        }
        let vSrc = SCNGeometrySource(vertices: verts)
        let nSrc = SCNGeometrySource(normals: norms)
        let cData = cols.withUnsafeBufferPointer { Data(buffer: $0) }
        let cSrc = SCNGeometrySource(data: cData, semantic: .color, vectorCount: cols.count, usesFloatComponents: true,
                                     componentsPerVector: 4, bytesPerComponent: MemoryLayout<Float>.size, dataOffset: 0,
                                     dataStride: MemoryLayout<SIMD4<Float>>.stride)
        let el = SCNGeometryElement(indices: idx, primitiveType: .triangles)
        let g = SCNGeometry(sources: [vSrc, nSrc, cSrc], elements: [el])
        let m = SCNMaterial(); m.isDoubleSided = true; m.lightingModel = .blinn
        g.materials = [m]
        return g
    }

    private static func ramp(_ t: Float) -> SIMD4<Float> {
        let x = min(max(t, 0), 1)
        if x < 0.33 { let k = x / 0.33; return SIMD4(0.1, 0.3 + 0.5 * k, 0.9 - 0.5 * k, 1) }
        if x < 0.66 { let k = (x - 0.33) / 0.33; return SIMD4(0.1 + 0.9 * k, 0.8, 0.4 - 0.3 * k, 1) }
        let k = (x - 0.66) / 0.34; return SIMD4(1, 0.8 - 0.65 * k, 0.1, 1)
    }
}
