import Foundation

/// Forgiving dynamic JSON view. The C++ bridge returns JSON; a missing/typed-wrong field yields a
/// neutral default instead of crashing the UI.
struct J: @unchecked Sendable {
    let raw: Any?
    init(_ raw: Any?) { self.raw = raw is NSNull ? nil : raw }

    subscript(_ key: String) -> J { J((raw as? [String: Any])?[key]) }
    subscript(_ index: Int) -> J {
        guard let a = raw as? [Any], index >= 0, index < a.count else { return J(nil) }
        return J(a[index])
    }

    var exists: Bool { raw != nil }
    var array: [J] { (raw as? [Any])?.map { J($0) } ?? [] }
    var count: Int { (raw as? [Any])?.count ?? 0 }
    var string: String { (raw as? String) ?? (raw.map { "\($0)" } ?? "") }
    var bool: Bool { (raw as? Bool) ?? ((raw as? NSNumber)?.boolValue ?? false) }
    var int: Int { (raw as? NSNumber)?.intValue ?? 0 }
    var double: Double { (raw as? NSNumber)?.doubleValue ?? .nan }
    /// Number with NaN replaced.
    func d(_ fallback: Double = 0) -> Double { let v = double; return v.isNaN ? fallback : v }
    var doubles: [Double] { (raw as? [Any])?.map { ($0 as? NSNumber)?.doubleValue ?? .nan } ?? [] }
    var ints: [Int] { (raw as? [Any])?.map { ($0 as? NSNumber)?.intValue ?? 0 } ?? [] }
    var strings: [String] { (raw as? [Any])?.map { "\($0)" } ?? [] }
}
