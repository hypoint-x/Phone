import Foundation

/// Swift face of the shared C++ core (Core/ios/qe_ios.h).
/// All engine maths runs in C++; this type only moves JSON across the boundary.
final class Engine: @unchecked Sendable {
    static let shared = Engine()

    /// Keeps Yahoo's cookie + crumb handshake on one cookie jar, like the desktop libcurl engine did.
    private static let session: URLSession = {
        let cfg = URLSessionConfiguration.default
        cfg.httpCookieStorage = HTTPCookieStorage.shared
        cfg.httpCookieAcceptPolicy = .always
        cfg.httpShouldSetCookies = true
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        cfg.timeoutIntervalForRequest = 15
        cfg.timeoutIntervalForResource = 30
        cfg.httpMaximumConnectionsPerHost = 8
        return URLSession(configuration: cfg)
    }()

    private static let userAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private let queue = DispatchQueue(label: "qe.engine", qos: .userInitiated, attributes: .concurrent)

    private init() {
        qe_set_http_transport { urlC, headersC, bodyOut in
            guard let urlC = urlC, let bodyOut = bodyOut, let url = URL(string: String(cString: urlC)) else {
                bodyOut?.pointee = strdup("bad url")
                return -1
            }
            var req = URLRequest(url: url)
            req.setValue(Engine.userAgent, forHTTPHeaderField: "User-Agent")
            req.setValue("application/json, text/plain, */*", forHTTPHeaderField: "Accept")
            if let h = headersC {
                let line = String(cString: h)
                if let colon = line.firstIndex(of: ":") {
                    let name = String(line[..<colon]).trimmingCharacters(in: .whitespaces)
                    let value = String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)
                    if !name.isEmpty { req.setValue(value, forHTTPHeaderField: name) }
                }
            }
            let sem = DispatchSemaphore(value: 0)
            var status: Int32 = -1
            var text = ""
            Engine.session.dataTask(with: req) { data, resp, error in
                if let http = resp as? HTTPURLResponse {
                    status = Int32(http.statusCode)
                    text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                } else {
                    status = -1
                    text = error?.localizedDescription ?? "network error"
                }
                sem.signal()
            }.resume()
            sem.wait()
            bodyOut.pointee = strdup(text)
            return status
        }
        if let dir = Bundle.main.resourcePath {
            qe_set_asset_dir(dir)
        }
    }

    /// Runs one engine call off the main thread (it blocks on network I/O inside C++).
    func call(_ method: String, _ args: [String: Any] = [:]) async -> J {
        await withCheckedContinuation { (cont: CheckedContinuation<J, Never>) in
            queue.async {
                let data = (try? JSONSerialization.data(withJSONObject: args)) ?? Data("{}".utf8)
                let argStr = String(data: data, encoding: .utf8) ?? "{}"
                guard let out = qe_call(method, argStr) else {
                    cont.resume(returning: J(["ok": false, "error": "engine returned nothing"]))
                    return
                }
                let s = String(cString: out)
                qe_free(out)
                let obj = (try? JSONSerialization.jsonObject(with: Data(s.utf8))) ?? ["ok": false, "error": "bad engine JSON"]
                cont.resume(returning: J(obj))
            }
        }
    }
}
