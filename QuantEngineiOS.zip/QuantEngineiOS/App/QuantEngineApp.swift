import SwiftUI

@main
struct QuantEngineApp: App {
    @StateObject private var state = AppState()
    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(state)
                .preferredColorScheme(.dark)
        }
    }
}

struct HomeView: View {
    @EnvironmentObject var app: AppState

    private struct Tool: Identifiable {
        let id: String, title: String, subtitle: String, icon: String
        let destination: AnyView
    }
    private struct ToolGroup: Identifiable { let id: String; let tools: [Tool] }

    private var groups: [ToolGroup] {
        [
            ToolGroup(id: "Scanner", tools: [
                Tool(id: "desk", title: "Quant Desk", subtitle: "S&P 500 scan · price, MA ladder, MTF, RSI", icon: "list.number", destination: AnyView(DeskView())),
            ]),
            ToolGroup(id: "Quant", tools: [
                Tool(id: "qe", title: "Quant Engine", subtitle: "Settlement forecast + VWAP breakout, any stock", icon: "function", destination: AnyView(QuantEngineView())),
                Tool(id: "qt", title: "Quant Tool", subtitle: "Leading intensity cloud", icon: "cloud.fill", destination: AnyView(QuantToolView())),
                Tool(id: "gn", title: "Gamma Node Sequencer", subtitle: "WAIT · WAIT · ENTER", icon: "square.grid.3x3.fill", destination: AnyView(GammaNodeView())),
                Tool(id: "hm", title: "Strike Heatmap", subtitle: "Per-strike intensity, peak & runner-up", icon: "flame.fill", destination: AnyView(StrikeHeatmapView())),
                Tool(id: "gex", title: "GEX", subtitle: "Dealer gamma levels, walls, flip", icon: "waveform.path.ecg", destination: AnyView(GEXView())),
                Tool(id: "td", title: "Transport Divergence", subtitle: "Dow Transports vs crude oil", icon: "truck.box.fill", destination: AnyView(TransportsView())),
            ]),
            ToolGroup(id: "Charts", tools: [
                Tool(id: "cp", title: "Chart+", subtitle: "Candles, EMA/VWAP/BB, RSI, MACD, trade plan", icon: "chart.xyaxis.line", destination: AnyView(ChartPlusView())),
                Tool(id: "ma", title: "MA Ladder", subtitle: "5/9/22/50/200 EMA stack confluence", icon: "chart.line.uptrend.xyaxis", destination: AnyView(MALadderView())),
                Tool(id: "mtf", title: "MTF", subtitle: "1m · 5m · 15m · 1h · 1d bias", icon: "clock.arrow.2.circlepath", destination: AnyView(MTFView())),
            ]),
            ToolGroup(id: "Options flow", tools: [
                Tool(id: "nf", title: "Net Flow", subtitle: "Call vs put premium by expiry", icon: "arrow.left.arrow.right", destination: AnyView(NetFlowView())),
                Tool(id: "nfp", title: "Net Flow+", subtitle: "Sweeps, blocks and extreme prints", icon: "bolt.fill", destination: AnyView(NetFlowPlusView())),
                Tool(id: "3d", title: "3D Options", subtitle: "Strike × DTE × metric surface", icon: "cube.transparent.fill", destination: AnyView(Surface3DView())),
            ]),
        ]
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(groups) { g in
                    Section(g.id) {
                        ForEach(g.tools) { t in
                            NavigationLink(destination: t.destination) {
                                HStack(spacing: 12) {
                                    Image(systemName: t.icon).font(.title3).foregroundStyle(Theme.accent).frame(width: 30)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(t.title).font(.headline)
                                        Text(t.subtitle).font(.caption).foregroundStyle(.secondary)
                                    }
                                }.padding(.vertical, 2)
                            }
                        }
                    }
                }
                Section {
                    Text("Market data comes from Yahoo Finance's unofficial endpoints and can be delayed, rate-limited or change without notice. For information only — not investment advice.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Quant Engine")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Text(app.symbol).font(.system(.subheadline, design: .monospaced).weight(.bold))
                        .padding(.horizontal, 10).padding(.vertical, 4)
                        .background(Theme.accent.opacity(0.2), in: Capsule())
                }
            }
        }
    }
}
