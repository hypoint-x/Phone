import SwiftUI

/// One engine call + its UI state.
@MainActor
final class Loader: ObservableObject {
    @Published var data: J? = nil
    @Published var loading = false
    @Published var error: String? = nil
    @Published var updated: Date? = nil
    private var generation = 0

    /// Runs `method`; stale responses (older request finishing late) are dropped.
    func load(_ method: String, _ args: [String: Any] = [:], keepOld: Bool = true) async {
        generation += 1
        let mine = generation
        loading = true
        if !keepOld { data = nil }
        let r = await Engine.shared.call(method, args)
        guard mine == generation else { return }
        loading = false
        if r["ok"].bool {
            data = r; error = nil; updated = Date()
        } else {
            error = r["error"].exists ? r["error"].string : "No data returned (Yahoo may be rate-limiting — try again in a minute)."
            if !keepOld { data = nil }
        }
    }
}

/// App-wide selected ticker.
@MainActor
final class AppState: ObservableObject {
    @Published var symbol: String { didSet { UserDefaults.standard.set(symbol, forKey: "qe.symbol") } }
    @Published var recents: [String] { didSet { UserDefaults.standard.set(recents, forKey: "qe.recents") } }

    init() {
        symbol = UserDefaults.standard.string(forKey: "qe.symbol") ?? "SPY"
        recents = UserDefaults.standard.stringArray(forKey: "qe.recents") ?? ["SPY", "QQQ", "AAPL", "NVDA", "TSLA"]
    }

    func set(_ s: String) {
        let u = s.trimmingCharacters(in: .whitespaces).uppercased()
        guard !u.isEmpty else { return }
        symbol = u
        recents = ([u] + recents.filter { $0 != u }).prefix(8).map { $0 }
    }
}

/// Header strip used by every symbol-driven tool: ticker field, recents, refresh, status.
struct SymbolBar: View {
    @EnvironmentObject var app: AppState
    @ObservedObject var loader: Loader
    var onRefresh: () -> Void
    @State private var text = ""

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Ticker", text: $text)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .submitLabel(.go)
                    .onSubmit { app.set(text); text = "" }
                    .font(.system(.body, design: .monospaced))
                if loader.loading { ProgressView() }
                else { Button(action: onRefresh) { Image(systemName: "arrow.clockwise") } }
            }
            .padding(10)
            .background(Theme.card, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(app.recents, id: \.self) { s in
                        Button { app.set(s) } label: {
                            Text(s).font(.caption.weight(.semibold))
                                .padding(.horizontal, 10).padding(.vertical, 5)
                                .background(s == app.symbol ? Theme.accent : Theme.card, in: Capsule())
                                .foregroundStyle(s == app.symbol ? Color.white : Color.primary)
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

/// Wraps a tool screen: symbol bar, error/empty states, auto-reload on symbol/params change.
struct ToolScreen<Content: View>: View {
    let title: String
    let method: String
    var args: [String: Any] = [:]
    /// Changes whenever the request should re-run (symbol + any picker values).
    var key: String = ""
    var autoRefresh: TimeInterval? = nil
    @ViewBuilder var content: (J) -> Content

    @EnvironmentObject var app: AppState
    @StateObject private var loader = Loader()

    private var fullArgs: [String: Any] {
        var a = args
        a["symbol"] = app.symbol
        return a
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                SymbolBar(loader: loader) { Task { await loader.load(method, fullArgs) } }
                if let e = loader.error {
                    Card { Label(e, systemImage: "exclamationmark.triangle").foregroundStyle(Theme.warn).font(.subheadline) }
                }
                if let d = loader.data {
                    content(d)
                } else if loader.loading {
                    ProgressView("Loading \(app.symbol)…").padding(.top, 40)
                }
                if let u = loader.updated {
                    Text("Updated \(u.formatted(date: .omitted, time: .standard))").font(.caption2).foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, 16).padding(.bottom, 24)
        }
        .refreshable { await loader.load(method, fullArgs) }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .task(id: "\(app.symbol)|\(key)") { await loader.load(method, fullArgs, keepOld: false) }
        .task(id: "\(app.symbol)|\(key)|auto") {
            guard let every = autoRefresh else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: UInt64(every * 1_000_000_000))
                if Task.isCancelled { break }
                await loader.load(method, fullArgs)
            }
        }
    }
}
