import SwiftUI

enum Theme {
    static let bull = Color(red: 0.20, green: 0.78, blue: 0.45)
    static let bear = Color(red: 0.93, green: 0.30, blue: 0.33)
    static let warn = Color(red: 0.96, green: 0.70, blue: 0.20)
    static let accent = Color(red: 0.30, green: 0.58, blue: 1.0)
    static let card = Color(.secondarySystemBackground)

    static func bias(_ s: String) -> Color {
        let u = s.uppercased()
        if u.contains("BULL") || u.contains("LONG") || u == "UP" || u.contains("BUY") || u.contains("CALL") { return bull }
        if u.contains("BEAR") || u.contains("SHORT") || u == "DOWN" || u.contains("SELL") || u.contains("PUT") { return bear }
        return .secondary
    }
}

enum Fmt {
    static func price(_ v: Double) -> String {
        guard v.isFinite else { return "–" }
        return String(format: "%.2f", v)
    }
    static func pct(_ v: Double, digits: Int = 2) -> String {
        guard v.isFinite else { return "–" }
        return String(format: "%+.\(digits)f%%", v)
    }
    /// 1.2K / 3.4M / 5.6B with sign.
    static func big(_ v: Double) -> String {
        guard v.isFinite else { return "–" }
        let a = abs(v), s = v < 0 ? "-" : ""
        switch a {
        case 1e12...: return s + String(format: "%.2fT", a / 1e12)
        case 1e9...: return s + String(format: "%.2fB", a / 1e9)
        case 1e6...: return s + String(format: "%.2fM", a / 1e6)
        case 1e3...: return s + String(format: "%.1fK", a / 1e3)
        default: return s + String(format: "%.0f", a)
        }
    }
    static func num(_ v: Double, _ digits: Int = 2) -> String {
        v.isFinite ? String(format: "%.\(digits)f", v) : "–"
    }
    static func opt(_ j: J, _ digits: Int = 2) -> String { j.exists ? num(j.double, digits) : "–" }
}

struct Card<Content: View>: View {
    var title: String? = nil
    @ViewBuilder var content: () -> Content
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let title { Text(title).font(.caption.weight(.semibold)).foregroundStyle(.secondary).textCase(.uppercase) }
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Theme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

struct StatTile: View {
    let label: String
    let value: String
    var color: Color = .primary
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.caption2).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.7)
            Text(value).font(.system(.callout, design: .rounded).weight(.semibold)).foregroundStyle(color)
                .lineLimit(1).minimumScaleFactor(0.6)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct Pill: View {
    let text: String
    var color: Color = .secondary
    var body: some View {
        Text(text).font(.caption2.weight(.bold))
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(color.opacity(0.18), in: Capsule())
            .foregroundStyle(color)
    }
}

struct KeyValueRow: View {
    let key: String
    let value: String
    var color: Color = .primary
    var body: some View {
        HStack { Text(key).foregroundStyle(.secondary); Spacer(); Text(value).monospacedDigit().foregroundStyle(color) }
            .font(.subheadline)
    }
}
