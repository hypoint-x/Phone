import SwiftUI
import Charts

struct ChartLine: Identifiable {
    let id = UUID()
    let name: String
    let values: [Double]
    let color: Color
    var width: CGFloat = 1.3
    var dashed = false
}

struct PriceLevel: Identifiable {
    let id = UUID()
    let label: String
    let price: Double
    let color: Color
}

/// Candlesticks + optional overlay lines + horizontal level markers. X is the bar index, so overnight/weekend gaps don't stretch the axis.
struct CandleChart: View {
    let o: [Double], h: [Double], l: [Double], c: [Double]
    var lines: [ChartLine] = []
    var levels: [PriceLevel] = []
    var visible = 80
    var height: CGFloat = 280

    private var start: Int { max(0, c.count - visible) }
    private var indices: [Int] {
        let n = min(c.count, min(o.count, min(h.count, l.count)))
        return n > start ? Array(start..<n) : []
    }
    private var yDomain: ClosedRange<Double> {
        var lo = Double.infinity, hi = -Double.infinity
        for i in indices { lo = min(lo, l[i]); hi = max(hi, h[i]) }
        for ln in lines { for i in indices where i < ln.values.count && ln.values[i].isFinite {
            lo = min(lo, ln.values[i]); hi = max(hi, ln.values[i]) } }
        for lv in levels where lv.price >= lo * 0.93 && lv.price <= hi * 1.07 { lo = min(lo, lv.price); hi = max(hi, lv.price) }
        guard lo.isFinite, hi.isFinite, hi > lo else { return 0...1 }
        let pad = (hi - lo) * 0.04
        return (lo - pad)...(hi + pad)
    }

    var body: some View {
        let dom = yDomain
        Chart {
            ForEach(indices, id: \.self) { i in
                RuleMark(x: .value("Bar", i), yStart: .value("Low", l[i]), yEnd: .value("High", h[i]))
                    .foregroundStyle(c[i] >= o[i] ? Theme.bull : Theme.bear)
                    .lineStyle(StrokeStyle(lineWidth: 1))
                BarMark(x: .value("Bar", i), yStart: .value("Open", o[i]), yEnd: .value("Close", c[i]), width: .fixed(3.2))
                    .foregroundStyle(c[i] >= o[i] ? Theme.bull : Theme.bear)
            }
            ForEach(lines) { ln in
                ForEach(indices, id: \.self) { i in
                    if i < ln.values.count, ln.values[i].isFinite {
                        LineMark(x: .value("Bar", i), y: .value(ln.name, ln.values[i]), series: .value("S", ln.name))
                            .foregroundStyle(ln.color)
                            .lineStyle(StrokeStyle(lineWidth: ln.width, dash: ln.dashed ? [4, 3] : []))
                    }
                }
            }
            ForEach(levels.filter { dom.contains($0.price) }) { lv in
                RuleMark(y: .value(lv.label, lv.price))
                    .foregroundStyle(lv.color.opacity(0.8))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 4]))
                    .annotation(position: .top, alignment: .leading) {
                        Text("\(lv.label) \(Fmt.price(lv.price))").font(.system(size: 9)).foregroundStyle(lv.color)
                    }
            }
        }
        .chartYScale(domain: dom)
        .chartXAxis(.hidden)
        .chartYAxis { AxisMarks(position: .trailing) }
        .chartLegend(.hidden)
        .frame(height: height)
    }
}

/// Generic line sub-chart (RSI, MACD hist, equity curves…).
struct LineStrip: View {
    let values: [Double]
    var title: String
    var color: Color = Theme.accent
    var band: (Double, Double)? = nil
    var visible = 80
    var height: CGFloat = 90
    var domain: ClosedRange<Double>? = nil

    private var idx: [Int] {
        let start = max(0, values.count - visible)
        return start < values.count ? Array(start..<values.count) : []
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption2).foregroundStyle(.secondary)
            Chart {
                if let b = band {
                    RuleMark(y: .value("hi", b.1)).foregroundStyle(.gray.opacity(0.5)).lineStyle(StrokeStyle(lineWidth: 0.6, dash: [3, 3]))
                    RuleMark(y: .value("lo", b.0)).foregroundStyle(.gray.opacity(0.5)).lineStyle(StrokeStyle(lineWidth: 0.6, dash: [3, 3]))
                }
                ForEach(idx, id: \.self) { i in
                    if values[i].isFinite {
                        LineMark(x: .value("Bar", i), y: .value(title, values[i])).foregroundStyle(color)
                    }
                }
            }
            .chartXAxis(.hidden)
            .chartYAxis { AxisMarks(position: .trailing) }
            .modifier(OptionalDomain(domain: domain))
            .frame(height: height)
        }
    }
}

private struct OptionalDomain: ViewModifier {
    let domain: ClosedRange<Double>?
    func body(content: Content) -> some View {
        if let d = domain { content.chartYScale(domain: d) } else { content }
    }
}

struct HistogramStrip: View {
    let values: [Double]
    var title: String
    var visible = 80
    var height: CGFloat = 70
    private var idx: [Int] {
        let start = max(0, values.count - visible)
        return start < values.count ? Array(start..<values.count) : []
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.caption2).foregroundStyle(.secondary)
            Chart {
                ForEach(idx, id: \.self) { i in
                    if values[i].isFinite {
                        BarMark(x: .value("Bar", i), y: .value(title, values[i])).foregroundStyle(values[i] >= 0 ? Theme.bull : Theme.bear)
                    }
                }
            }
            .chartXAxis(.hidden)
            .chartYAxis { AxisMarks(position: .trailing) }
            .frame(height: height)
        }
    }
}

/// Today's candles from a `{t,o,h,l,c,v}` bars object returned by the bridge.
struct BarsCandles: View {
    let bars: J
    var levels: [PriceLevel] = []
    var visible = 78
    var height: CGFloat = 220
    var body: some View {
        CandleChart(o: bars["o"].doubles, h: bars["h"].doubles, l: bars["l"].doubles, c: bars["c"].doubles,
                    levels: levels, visible: visible, height: height)
    }
}

/// Compact summary of one MaLadderConfluence JSON object (shared by MA Ladder and Transports Divergence).
struct LadderSummary: View {
    let ladder: J
    var title: String? = nil

    private var checks: [(String, Bool)] {
        [("Pullback zone", ladder["pullback_zone"].bool), ("Structural support", ladder["structural_support"].bool),
         ("VWAP floor", ladder["vwap_floor"].bool), ("OBV confirm", ladder["obv_confirm"].bool),
         ("StochRSI confirm", ladder["stochrsi_confirm"].bool), ("Keltner expansion", ladder["keltner_expansion"].bool),
         ("Soft alignment", ladder["soft_alignment"].bool)]
    }

    var body: some View {
        Card(title: title) {
            HStack(spacing: 8) {
                StatTile(label: "Macro bias", value: ladder["macro_bias"].string, color: Theme.bias(ladder["macro_bias"].string))
                StatTile(label: "Confidence", value: "\(ladder["confidence"].int)")
                StatTile(label: "Alignment", value: ladder["hard_alignment"].string)
                StatTile(label: "Long trigger", value: ladder["long_trigger"].bool ? "YES" : "no",
                         color: ladder["long_trigger"].bool ? Theme.bull : .secondary)
            }
            ProgressView(value: Double(ladder["confidence"].int), total: 100).tint(Theme.bias(ladder["macro_bias"].string))
            FlowLayout(spacing: 6) {
                ForEach(checks, id: \.0) { c in
                    Pill(text: c.0, color: c.1 ? Theme.bull : .secondary.opacity(0.7))
                }
            }
            ForEach(ladder["timeframes"].array.indices, id: \.self) { i in
                let t = ladder["timeframes"][i]
                if t["valid"].bool {
                    HStack {
                        Text(t["tf"].string).font(.subheadline.weight(.semibold)).frame(width: 36, alignment: .leading)
                        Text(Fmt.price(t["price"].d())).monospacedDigit().font(.subheadline)
                        Spacer()
                        if t["bull_stack"].bool { Pill(text: "5>9>22>50>200", color: Theme.bull) }
                        else if t["bear_stack"].bool { Pill(text: "5<9<22<50<200", color: Theme.bear) }
                        else { Pill(text: "mixed", color: .secondary) }
                    }
                }
            }
        }
    }

    /// Colour-coded EMA stack for the chart legend.
    static let emaColors: [(String, Color)] = [
        ("ema5", .yellow), ("ema9", .orange), ("ema22", .green), ("ema50", .blue), ("ema200", .purple)
    ]

    /// Anchor timeframe's candle series with the five EMAs.
    static func chart(for ladder: J, tfIndex: Int, height: CGFloat = 260) -> some View {
        let s = ladder["timeframes"][tfIndex]["series"]
        let lines = emaColors.map { ChartLine(name: $0.0, values: s[$0.0].doubles, color: $0.1) }
        return CandleChart(o: s["o"].doubles, h: s["h"].doubles, l: s["l"].doubles, c: s["c"].doubles,
                           lines: lines, visible: 90, height: height)
    }
}

/// Wrapping row layout (iOS 16+).
struct FlowLayout: Layout {
    var spacing: CGFloat = 6
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxW = proposal.width ?? 320
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0, w: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x + sz.width > maxW && x > 0 { x = 0; y += rowH + spacing; rowH = 0 }
            x += sz.width + spacing; rowH = max(rowH, sz.height); w = max(w, x)
        }
        return CGSize(width: min(maxW, w), height: y + rowH)
    }
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowH: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x + sz.width > bounds.maxX && x > bounds.minX { x = bounds.minX; y += rowH + spacing; rowH = 0 }
            s.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(sz))
            x += sz.width + spacing; rowH = max(rowH, sz.height)
        }
    }
}
