// Host smoke test: drives every bridge method end-to-end against a *synthetic* Yahoo (deterministic
// random-walk bars + a generated option chain). It proves the engines + bridge + JSON compile and run;
// it does NOT validate live Yahoo behaviour — that needs a device with internet.
#include "qe_ios.h"
#include <nlohmann/json.hpp>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <ctime>
#include <iostream>
#include <thread>
using json = nlohmann::json;

static unsigned hashStr(const std::string& s) { unsigned h = 2166136261u; for (unsigned char c : s) { h ^= c; h *= 16777619u; } return h; }
static std::string between(const std::string& s, const std::string& a, const std::string& b) {
    size_t i = s.find(a); if (i == std::string::npos) return ""; i += a.size();
    size_t j = b.empty() ? s.size() : s.find(b, i); if (j == std::string::npos) j = s.size();
    return s.substr(i, j - i);
}
static double spotFor(const std::string& sym) { return 50.0 + (hashStr(sym) % 45000) / 100.0; }

static std::string fakeChart(const std::string& symEnc, const std::string& interval) {
    std::string sym = symEnc; unsigned seed = hashStr(sym); srand(seed);
    long step = interval == "1m" ? 60 : interval == "5m" ? 300 : interval == "15m" ? 900 : interval == "60m" || interval == "1h" ? 3600 : 86400;
    int n = 320; double p = spotFor(sym) * 0.9; long long now = std::time(nullptr) - n * step;
    json t = json::array(), o = t, h = t, l = t, c = t, v = t;
    for (int i = 0; i < n; ++i) {
        double drift = 0.0004 + 0.012 * (((rand() % 2001) - 1000) / 1000.0);
        double op = p, cl = p * (1 + drift); double hi = std::max(op, cl) * 1.003, lo = std::min(op, cl) * 0.997;
        t.push_back(now + i * step); o.push_back(op); h.push_back(hi); l.push_back(lo); c.push_back(cl); v.push_back(1e5 + rand() % 900000);
        p = cl;
    }
    json j = {{"chart", {{"result", json::array({ {{"timestamp", t}, {"indicators", {{"quote", json::array({ {{"open", o}, {"high", h}, {"low", l}, {"close", c}, {"volume", v}} })}}}} })}}}};
    return j.dump();
}

static std::vector<long long> expirations() {
    std::vector<long long> e; long long base = std::time(nullptr);
    for (int d : {1, 2, 3, 5, 8, 12, 20, 33}) e.push_back(base + d * 86400LL + 3600);
    return e;
}
static int g_tick = 0;  // bumps each time a fresh chain is requested so volumes grow between polls
static std::string fakeOptions(const std::string& sym, const std::string& query) {
    double spot = spotFor(sym);
    json base_q = {{"regularMarketPrice", spot}};
    std::string dateStr = between(query, "date=", "");
    if (dateStr.empty()) {
        ++g_tick;
        json j = {{"optionChain", {{"result", json::array({ {{"quote", base_q}, {"expirationDates", expirations()}} })}}}};
        return j.dump();
    }
    unsigned s = hashStr(sym + dateStr); srand(s);
    json calls = json::array(), puts = json::array();
    double stepK = spot > 200 ? 5 : spot > 80 ? 2.5 : 1;
    for (int k = -25; k <= 25; ++k) {
        double K = std::round(spot / stepK) * stepK + k * stepK; if (K <= 0) continue;
        double dist = std::fabs(K - spot) / spot;
        double oi = (3000 + rand() % 9000) * std::exp(-dist * 12), vol = ((rand() % 4000) + g_tick * (200 + rand() % 3000)) * std::exp(-dist * 15);
        double px = std::max(0.05, spot * 0.02 * std::exp(-dist * 8));
        calls.push_back({{"strike", K}, {"lastPrice", px}, {"impliedVolatility", 0.22 + dist}, {"openInterest", std::floor(oi)}, {"volume", std::floor(vol)}});
        puts.push_back({{"strike", K}, {"lastPrice", px}, {"impliedVolatility", 0.24 + dist}, {"openInterest", std::floor(oi * (K < spot ? 1.4 : 0.8))}, {"volume", std::floor(vol * 1.1)}});
    }
    json j = {{"optionChain", {{"result", json::array({ {{"quote", base_q}, {"options", json::array({ {{"calls", calls}, {"puts", puts}} })}} })}}}};
    return j.dump();
}

static int fakeTransport(const char* url_c, const char*, char** out) {
    std::string url = url_c, body; int code = 200;
    if (url.find("fc.yahoo.com") != std::string::npos) { body = "";  code = 404; }
    else if (url.find("getcrumb") != std::string::npos) body = "FAKECRUMB";
    else if (url.find("/v8/finance/chart/") != std::string::npos) {
        std::string sym = between(url, "/chart/", "?"); 
        for (size_t i; (i = sym.find("%5E")) != std::string::npos;) sym.replace(i, 3, "^");
        for (size_t i; (i = sym.find("%3D")) != std::string::npos;) sym.replace(i, 3, "=");
        body = fakeChart(sym, between(url, "interval=", "&"));
    } else if (url.find("/v7/finance/options/") != std::string::npos) {
        std::string sym = between(url, "/options/", "?");
        std::string q = url.find('?') == std::string::npos ? "" : url.substr(url.find('?'));
        body = fakeOptions(sym, q);
    } else { body = "{}"; code = 404; }
    *out = (char*)std::malloc(body.size() + 1); std::memcpy(*out, body.c_str(), body.size() + 1);
    return code;
}

static int fails = 0;
static json call(const char* m, const json& a) {
    char* r = qe_call(m, a.dump().c_str()); json j = json::parse(r); qe_free(r);
    bool ok = j.value("ok", false);
    if (const char* dir = std::getenv("QE_DUMP_DIR")) { std::ofstream(std::string(dir) + "/" + m + ".json") << j.dump(); }
    std::cout << (ok ? "PASS " : "FAIL ") << m << (ok ? "" : "  -> " + j.value("error", std::string("?"))) << "\n";
    if (!ok) ++fails;
    return j;
}
#define CHECK(c) do { if (!(c)) { std::cout << "  CHECK FAILED: " #c "\n"; ++fails; } } while (0)

int main(int argc, char** argv) {
    qe_set_http_transport(fakeTransport);
    qe_set_asset_dir(argc > 1 ? argv[1] : ".");
    json a = {{"symbol", "AAPL"}};
    call("ping", json::object());
    auto ch = call("chart", {{"symbol", "AAPL"}, {"period", "5d"}, {"interval", "5m"}});
    std::cout << "   chart bars=" << ch["chart"]["c"].size() << "\n"; CHECK(ch["chart"]["c"].size() > 50); CHECK(ch["chart"]["rsi"].size() == ch["chart"]["c"].size());
    auto ml = call("ma_ladder", a);   CHECK(ml["ladder"]["timeframes"].size() == 3);
    auto bu = call("bullish", a);     CHECK(bu["tf"].size() == 3); CHECK(bu["index"].is_number());
    auto mt = call("mtf", a);         CHECK(mt["mtf"]["timeframes"].size() == 5);
    auto qe = call("quant_engine", a);
    auto ic = call("intensity_cloud", {{"symbol", "AAPL"}, {"metric", "notional"}}); CHECK(ic["rows"].size() > 3);
    auto hm = call("strike_heatmap", {{"symbol", "AAPL"}, {"metric", "oi"}});        CHECK(hm["rows"].size() > 3);
    auto gx = call("gex", a);         CHECK(gx["levels"].size() >= 3);
    CHECK(gx["robust"]["valid"] == true);
    auto gn = call("gamma_node", a);  CHECK(gn["cells"].size() > 10);
    auto n1 = call("net_flow", a);    CHECK(n1["buckets"].size() == 3);
    auto n2 = call("net_flow_plus", a); n2 = call("net_flow_plus", a); std::cout << "   flow+ events=" << n2["events"].size() << "\n"; CHECK(n2["events"].size() > 0);
    n1 = call("net_flow", a); CHECK(n1["history"].size() >= 1);
    auto su = call("surface", {{"symbol", "AAPL"}, {"metric", "gex"}, {"res", 30}}); CHECK(su["z"].size() == 900);
    auto tr = call("transports", json::object());
    auto un = call("desk_universe", json::object());  CHECK(un["symbols"].size() > 400);
    // desk scan on a small slice
    auto st = call("desk_start", {{"symbols", {"AAPL", "MSFT", "NVDA", "BRK-B", "JPM", "XOM"}}, {"workers", 3}, {"pause_ms", 0}});
    for (int i = 0; i < 100; ++i) { std::this_thread::sleep_for(std::chrono::milliseconds(100)); auto s = json::parse(std::string(qe_call("desk_state", "{}"))); if (!s["running"].get<bool>()) break; }
    auto ds = json::parse(std::string(qe_call("desk_state", "{}")));
    CHECK(ds["completed"] == 6); CHECK(ds["entries"].size() == 6);
    if (const char* dir = std::getenv("QE_DUMP_DIR")) { std::ofstream(std::string(dir) + "/desk_state.json") << ds.dump(); }
    for (auto& e : ds["entries"]) std::cout << "   " << e["symbol"].get<std::string>() << " px=" << e["price"] << " rsi=" << (int)e["rsi"].get<double>() << " ma=" << e["ma_bias"].get<std::string>() << " mtf=" << e["mtf_signal"].get<std::string>() << "\n";
    // error path
    char* r = qe_call("nope", "{}"); CHECK(json::parse(r)["ok"] == false); qe_free(r);
    std::cout << (fails ? "SMOKE FAILED\n" : "SMOKE OK\n");
    return fails ? 1 : 0;
}
